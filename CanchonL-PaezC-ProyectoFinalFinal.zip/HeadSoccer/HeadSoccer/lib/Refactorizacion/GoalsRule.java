package domain;

/** Partido por goles: gana el primero que llegue a la meta de goles. */
public class GoalsRule extends MatchRule {

    private static final long serialVersionUID = 1L;

    private final int goalTarget;

    public GoalsRule(int goalTarget) {
        this.goalTarget = goalTarget;
    }

    @Override
    public MatchType getType() { return MatchType.GOALS; }

    @Override
    public void onGoal(HeadSoccer match, int scorer, int goalOwner) {
        if (match.getScore(scorer) >= goalTarget) {
            match.finish(scorer);
        }
    }

    @Override
    public int getGoalTarget() { return goalTarget; }
}
