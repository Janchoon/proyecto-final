package domain;

/**
 * Reglas del partido. Guarda lo común a todo partido (marcador, estado y
 * ganador) y delega en una {@link MatchRule} lo que depende del tipo de partido
 * (cuándo termina, tiempo restante, balones, meta de goles).
 */
public class HeadSoccer implements java.io.Serializable {

    private static final long serialVersionUID = 1L;

    public static final int MATCH_SECONDS = 60;
    public static final int SURVIVAL_BALLS = 3;
    public static final int MAX_MINUTES = 60;
    public static final int MAX_GOALS = 99;

    private final GameMode mode;
    private final MatchRule rule;

    private int scorePlayer1;
    private int scorePlayer2;
    private MatchState state;
    private int winner;

    private HeadSoccer(GameMode mode, MatchRule rule) {
        this.mode = mode;
        this.rule = rule;
        this.scorePlayer1 = 0;
        this.scorePlayer2 = 0;
        this.state = MatchState.NOT_STARTED;
        this.winner = 0;
    }

    /** Partido por tiempo de 1 minuto (MATCH_SECONDS). */
    public static HeadSoccer byTime(GameMode mode) {
        return new HeadSoccer(mode, new TimeRule(MATCH_SECONDS / 60));
    }

    /** Partido por tiempo de la duración elegida (1 a 60 minutos). */
    public static HeadSoccer byTime(GameMode mode, int minutes) throws POOBSoccerException {
        if (minutes < 1 || minutes > MAX_MINUTES) {
            throw new POOBSoccerException(POOBSoccerException.INVALID_MINUTES);
        }
        return new HeadSoccer(mode, new TimeRule(minutes));
    }

    public static HeadSoccer byGoals(GameMode mode, int target) throws POOBSoccerException {
        if (target < 1 || target > MAX_GOALS) {
            throw new POOBSoccerException(POOBSoccerException.INVALID_GOAL_TARGET);
        }
        return new HeadSoccer(mode, new GoalsRule(target));
    }

    public static HeadSoccer survival(GameMode mode) throws POOBSoccerException {
        if (mode != GameMode.PVM) {
            throw new POOBSoccerException(POOBSoccerException.SURVIVAL_ONLY_PVM);
        }
        return new HeadSoccer(mode, new SurvivalRule());
    }

    // Control del partido

    public void start() throws POOBSoccerException {
        if (state != MatchState.NOT_STARTED) {
            throw new POOBSoccerException(POOBSoccerException.INVALID_STATE);
        }
        state = MatchState.RUNNING;
    }

    public void pause() throws POOBSoccerException {
        if (state != MatchState.RUNNING) {
            throw new POOBSoccerException(POOBSoccerException.INVALID_STATE);
        }
        state = MatchState.PAUSED;
    }

    public void resume() throws POOBSoccerException {
        if (state != MatchState.PAUSED) {
            throw new POOBSoccerException(POOBSoccerException.INVALID_STATE);
        }
        state = MatchState.RUNNING;
    }

    public void tick(long elapsedMillis) {
        if (state != MatchState.RUNNING) {
            return;
        }
        rule.onTick(this, elapsedMillis);
    }

    public void ballEnteredGoal(int goalOwner) throws POOBSoccerException {
        if (goalOwner != 1 && goalOwner != 2) {
            throw new POOBSoccerException(POOBSoccerException.INVALID_PLAYER);
        }
        if (state != MatchState.RUNNING) {
            return;
        }
        int scorer = (goalOwner == 1) ? 2 : 1;
        if (scorer == 1) {
            scorePlayer1++;
        } else {
            scorePlayer2++;
        }
        rule.onGoal(this, scorer, goalOwner);
    }

    // Internos (los usan las reglas del mismo paquete)

    void finish(int winningPlayer) {
        winner = winningPlayer;
        state = MatchState.FINISHED;
    }

    // Consultas

    public int getScore(int player) {
        return (player == 1) ? scorePlayer1 : scorePlayer2;
    }

    public int getBalls(int player) { return rule.getBalls(player); }
    public int getRemainingSeconds() { return rule.getRemainingSeconds(); }
    public int getGoalTarget() { return rule.getGoalTarget(); }
    public int getMinutes() { return rule.getMinutes(); }
    public boolean isGoldenGoal() { return rule.isGoldenGoal(); }
    public MatchType getType() { return rule.getType(); }

    public GameMode getMode() { return mode; }
    public MatchState getState() { return state; }
    public boolean isFinished() { return state == MatchState.FINISHED; }
    public int getWinner() { return winner; }
}
