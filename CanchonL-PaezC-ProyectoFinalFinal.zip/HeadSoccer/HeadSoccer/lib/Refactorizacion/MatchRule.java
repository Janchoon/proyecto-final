package domain;

import java.io.Serializable;

/**
 * Regla de un partido (patrón Strategy). Cada tipo de partido (por tiempo, por
 * goles, supervivencia) es una subclase que decide cuándo termina el partido y
 * guarda únicamente los datos que le importan.
 *
 * Los métodos de consulta tienen un valor neutro por defecto: la subclase solo
 * sobrescribe los que aplican a su tipo de partido.
 */
public abstract class MatchRule implements Serializable {

    private static final long serialVersionUID = 1L;

    /** Tipo de partido que representa esta regla. */
    public abstract MatchType getType();

    /**
     * Se ejecuta después de sumar el punto al anotador.
     * @param match      partido al que se le aplica la regla
     * @param scorer     jugador que anotó (1 o 2)
     * @param goalOwner  dueño del arco donde entró el balón (1 o 2)
     */
    public abstract void onGoal(HeadSoccer match, int scorer, int goalOwner);

    /** Se ejecuta en cada cuadro mientras el partido corre. Por defecto no hace nada. */
    public void onTick(HeadSoccer match, long elapsedMillis) { }

    public int getGoalTarget() { return 0; }
    public int getMinutes() { return 0; }
    public int getBalls(int player) { return 0; }
    public int getRemainingSeconds() { return 0; }
    public boolean isGoldenGoal() { return false; }
}
