package domain;

/** Supervivencia: cada jugador tiene balones; al recibir un gol pierde uno y con 0 pierde. */
public class SurvivalRule extends MatchRule {

    private static final long serialVersionUID = 1L;

    private int ballsPlayer1 = HeadSoccer.SURVIVAL_BALLS;
    private int ballsPlayer2 = HeadSoccer.SURVIVAL_BALLS;

    @Override
    public MatchType getType() { return MatchType.SURVIVAL; }

    @Override
    public void onGoal(HeadSoccer match, int scorer, int goalOwner) {
        loseBall(goalOwner);
        if (getBalls(goalOwner) == 0) {
            match.finish(scorer);
        }
    }

    private void loseBall(int player) {
        if (player == 1) {
            ballsPlayer1--;
        } else {
            ballsPlayer2--;
        }
    }

    @Override
    public int getBalls(int player) {
        return (player == 1) ? ballsPlayer1 : ballsPlayer2;
    }
}
