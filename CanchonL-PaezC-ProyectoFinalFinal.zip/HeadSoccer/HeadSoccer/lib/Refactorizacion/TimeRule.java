package domain;

/** Partido por tiempo: gana quien tenga más goles al acabar; si empatan, gol de oro. */
public class TimeRule extends MatchRule {

    private static final long serialVersionUID = 1L;

    private final int minutes;
    private long remainingMillis;
    private boolean goldenGoal;

    public TimeRule(int minutes) {
        this.minutes = minutes;
        this.remainingMillis = minutes * 60000L;
        this.goldenGoal = false;
    }

    @Override
    public MatchType getType() { return MatchType.TIME; }

    @Override
    public void onTick(HeadSoccer match, long elapsedMillis) {
        if (goldenGoal) {
            return;
        }
        remainingMillis -= elapsedMillis;
        if (remainingMillis <= 0) {
            remainingMillis = 0;
            int s1 = match.getScore(1);
            int s2 = match.getScore(2);
            if (s1 == s2) {
                goldenGoal = true; // el primero que anote gana
            } else {
                match.finish(s1 > s2 ? 1 : 2);
            }
        }
    }

    @Override
    public void onGoal(HeadSoccer match, int scorer, int goalOwner) {
        if (goldenGoal) {
            match.finish(scorer);
        }
    }

    @Override
    public int getMinutes() { return minutes; }

    @Override
    public int getRemainingSeconds() { return (int) Math.ceil(remainingMillis / 1000.0); }

    @Override
    public boolean isGoldenGoal() { return goldenGoal; }
}
