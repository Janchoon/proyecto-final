package domain;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Random;

/**
 * Base extensible para controladores de maquina.
 * Trabaja exclusivamente sobre una MatchSnapshot sin depender de Player
 * Para crear un nuevo estilo de maquina basta con extender
 * esta clase e implementar decide(MatchSnapshot) y forLevel(int).
 */
public abstract class AIController implements Controller {

    private static final long serialVersionUID = 1L;

    public static final int DEFAULT_LEVEL = 3;

    protected static final double BALANCED_GUARD = 330;
    protected static final double OFFENSIVE_GUARD = 1e9;
    protected static final double DEFENSIVE_GUARD = 230;
    protected static final double DEFENSIVE_HOME_SHIFT = 90;

    private final String name;
    private final int level;
    protected final Random random = new Random();
    protected PlayerInput last = PlayerInput.NONE;

    protected AIController(String name, int level) {
        this.name = (name == null || name.trim().isEmpty()) ? "Máquina" : name.trim();
        this.level = Math.max(1, Math.min(5, level));
    }

    /** Máquinas disponibles por defecto para el menú. */
    public static List<AIController> defaults() {
        return Collections.unmodifiableList(Arrays.asList(
                new ClumsyAIController(),
                new OffensiveAIController(),
                new DefensiveAIController(),
                new ExpertAIController()));
    }

    /** Máquina por defecto cuando no se especifica una. */
    public static AIController defaultMachine() {
        return new ExpertAIController();
    }

    /** Crea una instancia independiente de esta misma máquina con el nivel indicado. */
    public abstract AIController forLevel(int level);

    public String getName() { return name; }
    public int getLevel() { return level; }

    @Override
    public String toString() { return name; }

    @Override
    public PlayerInput read(MatchSnapshot snapshot) {
        if (!shouldReact()) {
            return last;
        }
        last = decide(snapshot);
        return last;
    }

    /** Probabilidad de reaccionar en este cuadro segun el nivel (1 a 5). */
    protected boolean shouldReact() {
        return random.nextDouble() <= 0.45 + 0.11 * level;
    }

    /** Decide la accion de este cuadro a partir de la instantanea del partido. */
    protected abstract PlayerInput decide(MatchSnapshot snapshot);

    /**
     * Comportamiento reutilizable para subclases: persigue el balon, vuelve a
     * guardia si esta mas lejos de guardDistance o si hay un tiro hacia
     * su arco retreat es true).
     */
    protected PlayerInput chase(MatchSnapshot s, double guardDistance, boolean retreat, double homeShift) {
        double dx = s.getBallX() - s.getSelfX();
        double ahead = (s.getBallX() - s.getSelfStartX()) * s.getSelfFacing();
        boolean ballFar = ahead > guardDistance;
        boolean incoming = retreat && s.getBallVelX() * s.getSelfFacing() < -3 && ahead > 0;
        if (ballFar || incoming) {
            dx = (s.getSelfStartX() - s.getSelfFacing() * homeShift) - s.getSelfX();
        }
        boolean left = Math.abs(dx) > 12 && dx < 0;
        boolean right = Math.abs(dx) > 12 && dx > 0;

        boolean ballAbove = s.getBallY() < s.getSelfY() - 5;
        boolean ballBehind = dx * s.getSelfFacing() < 0;
        boolean jump = !ballFar && ((ballAbove && Math.abs(dx) < 80) || (ballBehind && Math.abs(dx) < 90));

        return new PlayerInput(left, right, jump, true, s.isSelfPowerReady());
    }
}
