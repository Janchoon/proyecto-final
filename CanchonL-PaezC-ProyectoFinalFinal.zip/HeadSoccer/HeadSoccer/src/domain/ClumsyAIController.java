package domain;

/** Máquina torpe: elige acciones al azar y las mantiene varios cuadros. */
public class ClumsyAIController extends AIController {

    private static final long serialVersionUID = 1L;
    private static final int HOLD_FRAMES = 18;

    private int holdFrames;

    public ClumsyAIController() {
        this(DEFAULT_LEVEL);
    }

    public ClumsyAIController(int level) {
        super("TORPE", level);
    }

    @Override
    public AIController forLevel(int level) {
        return new ClumsyAIController(level);
    }

    @Override
    protected boolean shouldReact() {
        if (holdFrames > 0) {
            holdFrames--;
            return false;
        }
        return true;
    }

    @Override
    protected PlayerInput decide(MatchSnapshot s) {
        holdFrames = HOLD_FRAMES;
        int dir = random.nextInt(3);
        boolean left = dir == 1;
        boolean right = dir == 2;
        boolean jump = random.nextInt(5) == 0;
        boolean kick = random.nextBoolean();
        boolean power = s.isSelfPowerReady() && random.nextInt(4) == 0;
        return new PlayerInput(left, right, jump, kick, power);
    }
}
