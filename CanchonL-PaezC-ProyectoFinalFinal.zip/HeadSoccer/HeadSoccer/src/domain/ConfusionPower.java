package domain;

/** Poder Confusión: invierte los controles horizontales del rival. */
public class ConfusionPower extends PowerType {

    private static final long serialVersionUID = 1L;

    public ConfusionPower() {
        super("CONFUSION", "Confusión", "Confundido", 5000, 0, 14, "invierte los controles de movimiento del oponente");
    }

    @Override
    public int adjustMoveDirection(int dir) { return -dir; }
}
