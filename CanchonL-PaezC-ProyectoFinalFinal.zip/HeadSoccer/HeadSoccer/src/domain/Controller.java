package domain;

import java.io.Serializable;

/**
 * Contrato común para controlar a un jugador (humano o máquina).
 * Solo recibe una instantánea de solo lectura del partido y devuelve las
 * acciones solicitadas para ese cuadro.
 */
public interface Controller extends Serializable {
    PlayerInput read(MatchSnapshot snapshot);
}
