package domain;

/** Máquina defensiva: protege su arco y solo sale si el balón entra en su zona. */
public class DefensiveAIController extends AIController {

    private static final long serialVersionUID = 1L;

    public DefensiveAIController() {
        this(DEFAULT_LEVEL);
    }

    public DefensiveAIController(int level) {
        super("DEFENSIVA", level);
    }

    @Override
    public AIController forLevel(int level) {
        return new DefensiveAIController(level);
    }

    @Override
    protected PlayerInput decide(MatchSnapshot snapshot) {
        return chase(snapshot, DEFENSIVE_GUARD, true, DEFENSIVE_HOME_SHIFT);
    }
}
