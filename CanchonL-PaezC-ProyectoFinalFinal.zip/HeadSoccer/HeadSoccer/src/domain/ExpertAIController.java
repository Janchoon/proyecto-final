package domain;

/** Máquina experta: alterna entre atacar, defender o equilibrar según marcador y tiempo. */
public class ExpertAIController extends AIController {

    private static final long serialVersionUID = 1L;

    public ExpertAIController() {
        this(DEFAULT_LEVEL);
    }

    public ExpertAIController(int level) {
        super("EXPERTA", level);
    }

    @Override
    public AIController forLevel(int level) {
        return new ExpertAIController(level);
    }

    @Override
    protected PlayerInput decide(MatchSnapshot s) {
        double guard = BALANCED_GUARD;
        boolean retreat = true;
        double homeShift = 0;

        int mine = s.getMyScore();
        int theirs = s.getOpponentScore();
        boolean lastSeconds = s.isTimedMatch() && !s.isGoldenGoal() && s.getRemainingSeconds() <= 15;

        if (s.isGoldenGoal() || mine < theirs) {
            guard = OFFENSIVE_GUARD;
            retreat = false;
        } else if (mine > theirs && (lastSeconds || mine - theirs >= 2)) {
            guard = DEFENSIVE_GUARD;
            homeShift = DEFENSIVE_HOME_SHIFT;
        } else if (lastSeconds && mine == theirs) {
            guard = OFFENSIVE_GUARD;
            retreat = false;
        }
        return chase(s, guard, retreat, homeShift);
    }
}
