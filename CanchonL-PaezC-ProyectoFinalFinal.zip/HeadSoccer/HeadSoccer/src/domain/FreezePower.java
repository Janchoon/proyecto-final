package domain;

/** Poder Congelación: inmoviliza y aturde al rival en hielo. */
public class FreezePower extends PowerType {

    private static final long serialVersionUID = 1L;

    public FreezePower() {
        super("FREEZE", "Congelación", "Congelado", 3000, 0, 14,
                "congela al oponente en un bloque de hielo");
    }

    @Override
    public void onEffectApplied(Player victim) {
        victim.stopMoving();
    }

    @Override
    public boolean stunsTarget() { return true; }

    @Override
    public boolean blocksMovement() { return true; }
}
