package domain;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

/**
 * Motor del partido: junta las reglas (HeadSoccer) con la física (Ball, Player,
 * Goal) y los controladores (humano o máquina). La GUI solo llama a update()
 * en cada cuadro y dibuja lo que el motor expone.
 *
 * En supervivencia se juega una serie de partidos seguidos contra la máquina:
 * si el jugador 1 gana, empieza otro partido contra un rival más difícil; la
 * serie termina cuando pierde.
 */
public class GameEngine implements java.io.Serializable, PowerContext {

    private static final long serialVersionUID = 1L;

    public static final int FIELD_WIDTH = 900;
    public static final int FIELD_HEIGHT = 500;
    public static final int FLOOR_Y = 440;
    public static final int GOAL_WIDTH = 60;
    public static final int GOAL_HEIGHT = 150;
    public static final int BALL_RADIUS = 16;

    private static final int PLAYER_MARGIN = 200;
    private static final long EVENT_MILLIS = 1500;
    private static final long SHOT_MAX_MILLIS = 2500;

    private final GameMode mode;
    private final MatchType type;
    private final int goalTarget;
    private final int minutes;

    private final CharacterProfile[] profiles = new CharacterProfile[2];
    private final PlayerStats[] stats = new PlayerStats[2];
    private final AIController[] aiTemplates = new AIController[2];
    private final HumanController[] humans = new HumanController[2];
    private final Player[] players = new Player[2];
    private final Goal[] goals = new Goal[2];
    private final Controller[] controllers = new Controller[2];

    private HeadSoccer match;
    private Ball ball;

    private int survivalRound = 1;
    private boolean seriesOver;

    private String eventText = "";
    private long eventMillis;
    private int lastKicker;
    private long sinceKick = Long.MAX_VALUE / 2;

    // tiro de poder en vuelo (solo hace efecto si golpea al rival)
    private int shotOwner; // 0 = ninguno, 1 o 2
    private PowerType shotType;
    private long shotMillis;

    // balones falsos activos mientras dure el efecto que los generó
    private final List<Ball> fakeBalls = new ArrayList<>();
    private int fakeBallsVictim;
    private PowerType fakeBallsEffect;
    private final Random random = new Random();

    public GameEngine(GameMode mode, MatchType type, int goalTarget, CharacterProfile profile1, CharacterProfile profile2) throws POOBSoccerException {
        this(mode, type, goalTarget, 1, profile1, profile2, null, null, AIController.defaultMachine(), AIController.defaultMachine());
    }

    /**
     * Partido completo. goalTarget se usa en partidos por goles y minutes en los
     * de tiempo. stats1/stats2 son las mejoras de cada usuario (null = todas en 1);
     * ai1/ai2 sirven de plantilla polimórfica para crear las máquinas de cada ronda.
     */
    public GameEngine(GameMode mode, MatchType type, int goalTarget, int minutes,
                      CharacterProfile profile1, CharacterProfile profile2,
                      PlayerStats stats1, PlayerStats stats2,
                      AIController ai1, AIController ai2)
            throws POOBSoccerException {
        if (mode == null || type == null || profile1 == null || profile2 == null) {
            throw new POOBSoccerException(POOBSoccerException.INVALID_SETUP);
        }
        this.mode = mode;
        this.type = type;
        this.goalTarget = goalTarget;
        this.minutes = minutes;
        this.profiles[0] = profile1;
        this.profiles[1] = profile2;
        this.stats[0] = (stats1 == null) ? new PlayerStats() : new PlayerStats(stats1);
        this.stats[1] = (stats2 == null) ? new PlayerStats() : new PlayerStats(stats2);
        this.aiTemplates[0] = (ai1 == null) ? AIController.defaultMachine() : ai1;
        this.aiTemplates[1] = (ai2 == null) ? AIController.defaultMachine() : ai2;
        this.match = newMatch();
        this.humans[0] = (mode == GameMode.MVM) ? null : new HumanController();
        this.humans[1] = (mode == GameMode.PVP) ? new HumanController() : null;
        buildRound();
    }

    // Construcción de cada ronda

    private HeadSoccer newMatch() throws POOBSoccerException {
        switch (type) {
            case TIME:  return HeadSoccer.byTime(mode, minutes);
            case GOALS: return HeadSoccer.byGoals(mode, goalTarget);
            default:    return HeadSoccer.survival(mode);
        }
    }

    private void buildRound() throws POOBSoccerException {
        ball = new Ball(FIELD_WIDTH / 2, 120, BALL_RADIUS, FIELD_WIDTH, FLOOR_Y);
        for (int i = 0; i < 2; i++) {
            int number = i + 1;
            int goalX = (i == 0) ? 0 : FIELD_WIDTH - GOAL_WIDTH;
            players[i] = createPlayer(number, profiles[i], stats[i]);
            goals[i] = new Goal(number, goalX, FLOOR_Y - GOAL_HEIGHT, GOAL_WIDTH, GOAL_HEIGHT);
            controllers[i] = createController(number, humans[i], aiTemplates[i]);
        }
        lastKicker = 0;
        endShot();
    }

    /** Hook de extensión para crear jugadores personalizados en subclases. */
    protected Player createPlayer(int number, CharacterProfile profile, PlayerStats playerStats)
            throws POOBSoccerException {
        int startX = (number == 1) ? PLAYER_MARGIN : FIELD_WIDTH - PLAYER_MARGIN;
        int facing = (number == 1) ? 1 : -1;
        return profile.createPlayer(startX, FIELD_WIDTH, FLOOR_Y, facing, playerStats);
    }

    /** Hook de extensión para conectar máquinas o controladores personalizados. */
    protected Controller createController(int number, HumanController human, AIController template) {
        return (human != null) ? human : template.forLevel(aiLevel());
    }

    protected int aiLevel() {
        return (type == MatchType.SURVIVAL) ? Math.min(5, 1 + survivalRound) : 3;
    }

    // Control del partido

    public void start() throws POOBSoccerException { match.start(); }

    public void pause() {
        if (match.getState() == MatchState.RUNNING) {
            try { match.pause(); } catch (POOBSoccerException e) { /* estado ya validado */ }
        }
    }

    public void resume() {
        if (match.getState() == MatchState.PAUSED) {
            try { match.resume(); } catch (POOBSoccerException e) { /* estado ya validado */ }
        }
    }

    public void togglePause() {
        if (isPaused()) resume(); else pause();
    }

    /** Avanza un cuadro de juego. No hace nada si el partido no está corriendo. */
    public void update(long elapsedMillis) throws POOBSoccerException {
        if (match.getState() != MatchState.RUNNING) {
            return;
        }
        if (eventMillis > 0) {
            eventMillis = Math.max(0, eventMillis - elapsedMillis);
        }
        if (sinceKick < Long.MAX_VALUE / 4) {
            sinceKick += elapsedMillis;
        }

        act(1, players[0], players[1], controllers[0]);
        act(2, players[1], players[0], controllers[1]);

        for (Player p : players) {
            p.update(elapsedMillis);
        }
        ball.update();
        updateShot(elapsedMillis);
        updateFakeBalls();

        for (int i = 0; i < 2; i++) {
            bounceOnCrossbar(goals[i]);
            collide(i + 1, players[i]);
        }

        checkGoals();
        match.tick(elapsedMillis);
        checkSeries();
    }

    // Pasos de cada cuadro

    private void act(int index, Player self, Player opponent, Controller controller) {
        PlayerInput in = controller.read(snapshotFor(index, self));
        self.applyInput(in);
        if (self.consumeInstantPowerFired()) {
            activateInstantPower(self, opponent);
        }
        if (in.isKick()) {
            handleKick(index, self, opponent);
        }
    }

    private MatchSnapshot snapshotFor(int index, Player self) {
        int other = (index == 1) ? 2 : 1;
        return new MatchSnapshot(
                self.getPosX(), self.getPosY(), self.getStartX(), self.getFacing(),
                self.isPowerReady(), ball.getPosX(), ball.getPosY(), ball.getVelociX(),
                match.getScore(index), match.getScore(other),
                match.getRemainingSeconds(), type == MatchType.TIME, match.isGoldenGoal());
    }

    private void handleKick(int index, Player self, Player opponent) {
        if (self.kick(ball)) {
            lastKicker = index;
            sinceKick = 0;
            if (self.consumePowerFired()) {
                shotOwner = index;
                shotType = self.getPower();
                shotMillis = 0;
                setEvent("¡" + shotType.getLabel() + "!");
            } else {
                endShot();
            }
            return;
        }
        boolean wasUp = !opponent.isKnockedOut();
        if (self.kickPlayer(opponent) && wasUp && opponent.isKnockedOut()) {
            setEvent("¡" + opponent.getName() + " aturdido!");
        }
    }

    private void activateInstantPower(Player owner, Player victim) {
        PowerType power = owner.getPower();
        if (power != null) {
            power.onActivateInstant(owner, victim, this);
        }
    }

    private void powerShotHit(Player victim, Player owner) {
        shotType.onHit(owner, victim, this);
        endShot();
    }

    private void updateShot(long elapsedMillis) {
        if (shotOwner != 0) {
            shotMillis += elapsedMillis;
            if (shotMillis >= SHOT_MAX_MILLIS) {
                endShot();
            }
        }
    }

    private void endShot() {
        shotOwner = 0;
        shotType = null;
        shotMillis = 0;
        if (ball != null) {
            ball.setStraight(false);
        }
    }

    @Override
    public void spawnFakeBalls(Player victim, PowerType sourceEffect, int count) {
        fakeBalls.clear();
        fakeBallsVictim = (victim == players[0]) ? 1 : 2;
        fakeBallsEffect = sourceEffect;
        for (int i = 0; i < count; i++) {
            Ball fake = new Ball((int) ball.getPosX(), (int) ball.getPosY(), BALL_RADIUS,
                    FIELD_WIDTH, FLOOR_Y);
            fake.setVelocity((random.nextDouble() - 0.5) * 16, -2 - random.nextDouble() * 9);
            fakeBalls.add(fake);
        }
    }

    @Override
    public void announcePower(PowerType power, Player victim, double damage, boolean knockedOut) {
        String text = "¡" + power.getLabel() + "! " + victim.getName() + " queda "
                + power.getEffectLabel().toLowerCase();
        if (damage > 0) {
            text += " (-" + Math.round(damage) + ")";
        }
        if (knockedOut) {
            text += " y aturdido";
        }
        setEvent(text);
    }

    private void updateFakeBalls() {
        if (fakeBalls.isEmpty()) {
            return;
        }
        if (fakeBallsEffect == null || !fakeBallsEffect.equals(getPlayer(fakeBallsVictim).getEffect())) {
            fakeBalls.clear();
            fakeBallsEffect = null;
            return;
        }
        for (Ball fake : fakeBalls) {
            fake.update();
        }
    }

    private void bounceOnCrossbar(Goal goal) {
        double r = ball.getRadius();
        double top = goal.getPosY();
        boolean overGoal = ball.getPosX() + r > goal.getPosX()
                && ball.getPosX() - r < goal.getPosX() + goal.getWidth();
        double vy = ball.getVelociY();
        boolean cameFromAbove = ball.getPosY() - vy + r <= top + 1;
        if (overGoal && vy > 0 && ball.getPosY() + r >= top && cameFromAbove) {
            double newVy = -vy * Ball.BOUNCE_DAMPING;
            double vx = ball.getVelociX();
            if (Math.abs(newVy) < Ball.REST_THRESHOLD) {
                newVy = 0;
                vx += (goal.getOwner() == 1) ? 1.5 : -1.5;
            }
            ball.setPosition(ball.getPosX(), top - r);
            ball.setVelocity(vx, newVy);
        }
    }

    private void collide(int index, Player pl) {
        if (lastKicker == index && sinceKick < 200) {
            return;
        }
        double w = pl.getWidth();
        double h = pl.getHeight();
        double left = pl.getPosX() - w / 2.0;
        double top = pl.getPosY();
        double bx = ball.getPosX();
        double by = ball.getPosY();
        double r = ball.getRadius();
        double nx = Math.max(left, Math.min(bx, left + w));
        double ny = Math.max(top, Math.min(by, top + h));
        double dx = bx - nx;
        double dy = by - ny;
        double dist = Math.hypot(dx, dy);
        if (dist >= r) {
            return;
        }
        double ux;
        double uy;
        if (dist == 0) {
            ux = 0;
            uy = -1;
            ball.setPosition(bx, top - r);
        } else {
            ux = dx / dist;
            uy = dy / dist;
            ball.setPosition(nx + ux * r, ny + uy * r);
        }
        double vx = ball.getVelociX();
        double vy = ball.getVelociY();
        double vn = vx * ux + vy * uy;
        if (vn < 0) {
            vx -= 1.6 * vn * ux;
            vy -= 1.6 * vn * uy;
        }
        vx += pl.getVeloX() * 0.5;
        ball.setVelocity(vx, vy);

        int other = (index == 1) ? 2 : 1;
        if (shotOwner == other) {
            powerShotHit(pl, getPlayer(other));
        }
    }

    private void checkGoals() throws POOBSoccerException {
        int owner = 0;
        if (goals[0].isGoal(ball)) {
            owner = 1;
        } else if (goals[1].isGoal(ball)) {
            owner = 2;
        }
        if (owner == 0) {
            return;
        }
        int scorer = (owner == 1) ? 2 : 1;
        boolean ownGoal = (lastKicker == owner);
        match.ballEnteredGoal(owner);
        Player scorerPlayer = getPlayer(scorer);
        getPlayer(owner).addPowerCharge(Player.POWER_MAX / 4);
        setEvent(ownGoal ? "¡Autogol! Punto para " + scorerPlayer.getName()
                         : "¡GOL de " + scorerPlayer.getName() + "!");
        if (!match.isFinished()) {
            restartPositions();
        }
    }

    private void restartPositions() {
        for (Player p : players) {
            p.resetPosition();
        }
        ball.reset();
        lastKicker = 0;
        endShot();
        fakeBalls.clear();
        fakeBallsEffect = null;
    }

    private void checkSeries() throws POOBSoccerException {
        if (type != MatchType.SURVIVAL || !match.isFinished() || seriesOver) {
            return;
        }
        if (match.getWinner() != 1) {
            seriesOver = true;
            return;
        }
        List<CharacterProfile> all = CharacterCatalog.all();
        int next = (all.indexOf(profiles[1]) + 1) % all.size();
        profiles[1] = all.get(next);
        survivalRound++;
        match = newMatch();
        match.start();
        buildRound();
        setEvent("Ronda " + survivalRound + ": " + profiles[1].getName() + " (" + profiles[1].getCountry() + ")");
    }

    private void setEvent(String text) {
        eventText = text;
        eventMillis = EVENT_MILLIS;
    }

    // Consultas GUI

    public boolean isOver() {
        return match.isFinished() && (type != MatchType.SURVIVAL || seriesOver);
    }

    public boolean isPaused() { return match.getState() == MatchState.PAUSED; }
    public String getEventText() { return eventMillis > 0 ? eventText : ""; }

    public Player getPlayer(int number) { return players[number - 1]; }
    public Goal getGoal(int number) { return goals[number - 1]; }
    public Ball getBall() { return ball; }
    public List<Ball> getFakeBalls() { return java.util.Collections.unmodifiableList(fakeBalls); }
    public PowerType getShotType() { return shotType; }

    public String getMachineName(int number) {
        Controller c = controllers[number - 1];
        if (c instanceof AIController) {
            return ((AIController) c).getName();
        }
        return (c != null) ? c.toString() : "";
    }

    public PlayerStats getStats(int number) { return stats[number - 1]; }
    public int getMinutes() { return minutes; }

    public int getPointsEarned(int number) {
        if (!isOver() || getHumanController(number) == null) {
            return 0;
        }
        if (type == MatchType.SURVIVAL) {
            return PlayerProgress.WIN_POINTS * (survivalRound - 1) + PlayerProgress.LOSS_POINTS;
        }
        return (match.getWinner() == number) ? PlayerProgress.WIN_POINTS : PlayerProgress.LOSS_POINTS;
    }

    public HeadSoccer getMatch() { return match; }
    public GameMode getMode() { return mode; }
    public MatchType getType() { return type; }
    public int getSurvivalRound() { return survivalRound; }
    public int getWinner() { return match.getWinner(); }

    public HumanController getHumanController(int number) {
        return humans[number - 1];
    }
}
