package domain;

/**
 * Controlador que traduce el estado del teclado (actualizado desde la GUI)
 * en un {@link PlayerInput}. No depende de Player, Ball ni HeadSoccer.
 */
public class HumanController implements Controller {

    private static final long serialVersionUID = 1L;

    private boolean left;
    private boolean right;
    private boolean jump;
    private boolean kick;
    private boolean powerRequested;

    public void setLeft(boolean pressed) { left = pressed; }
    public void setRight(boolean pressed) { right = pressed; }
    public void setJump(boolean pressed) { jump = pressed; }
    public void setKick(boolean pressed) { kick = pressed; }
    public void requestPower() { powerRequested = true; }

    /** Limpia todas las teclas activas (útil al pausar o reiniciar). */
    public void reset() {
        left = false;
        right = false;
        jump = false;
        kick = false;
        powerRequested = false;
    }

    @Override
    public PlayerInput read(MatchSnapshot snapshot) {
        boolean power = powerRequested;
        powerRequested = false;
        return new PlayerInput(left, right, jump, kick, power);
    }
}
