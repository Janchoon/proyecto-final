package domain;

/** Poder Ilusión: se activa al presionar la tecla y divide el balón en 8 idénticos. */
public class IllusionPower extends PowerType {

    private static final long serialVersionUID = 1L;
    private static final int FAKE_BALLS = 7; // 7 falsos + el real = 8 balones

    public IllusionPower() {
        super("ILLUSION", "Ilusión", "Confundido", 2500, 0, 0, "el balón se divide en 8 idénticos al activar el poder");
    }

    @Override
    public boolean isInstant() { return true; }

    @Override
    public void onActivateInstant(Player owner, Player victim, PowerContext context) {
        victim.applyEffect(this);
        context.spawnFakeBalls(victim, this, FAKE_BALLS);
        context.announcePower(this, victim, 0, false);
    }
}
