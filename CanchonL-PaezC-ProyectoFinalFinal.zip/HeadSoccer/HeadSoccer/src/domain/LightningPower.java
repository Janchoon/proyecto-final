package domain;

/** Poder Rayo: impide saltar al rival y reduce su velocidad al 50 %. */
public class LightningPower extends PowerType {

    private static final long serialVersionUID = 1L;
    private static final double FACTOR = 0.5;

    public LightningPower() {
        super("LIGHTNING", "Rayo", "Electrocutado", 3000, 60, 17, "tiro recto con electricidad: el rival no salta y se mueve al 50 %");
    }

    @Override
    public boolean blocksJump() { return true; }

    @Override
    public double speedMultiplier() { return FACTOR; }
}
