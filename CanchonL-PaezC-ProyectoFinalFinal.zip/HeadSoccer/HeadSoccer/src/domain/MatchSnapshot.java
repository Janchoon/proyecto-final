package domain;

import java.io.Serializable;

/**
 * Instantánea de solo lectura del estado del partido necesaria para que un
 * controlador (p. ej. una máquina) tome decisiones
 */
public final class MatchSnapshot implements Serializable {

    private static final long serialVersionUID = 1L;

    private final double selfX;
    private final double selfY;
    private final double selfStartX;
    private final int selfFacing;
    private final boolean selfPowerReady;

    private final double ballX;
    private final double ballY;
    private final double ballVelX;

    private final int myScore;
    private final int opponentScore;
    private final int remainingSeconds;
    private final boolean timedMatch;
    private final boolean goldenGoal;

    public MatchSnapshot(double selfX, double selfY, double selfStartX, int selfFacing, boolean selfPowerReady, double ballX, double ballY, double ballVelX,
                         int myScore, int opponentScore, int remainingSeconds,
                         boolean timedMatch, boolean goldenGoal) {
        this.selfX = selfX;
        this.selfY = selfY;
        this.selfStartX = selfStartX;
        this.selfFacing = selfFacing;
        this.selfPowerReady = selfPowerReady;
        this.ballX = ballX;
        this.ballY = ballY;
        this.ballVelX = ballVelX;
        this.myScore = myScore;
        this.opponentScore = opponentScore;
        this.remainingSeconds = remainingSeconds;
        this.timedMatch = timedMatch;
        this.goldenGoal = goldenGoal;
    }

    public double getSelfX() { return selfX; }
    public double getSelfY() { return selfY; }
    public double getSelfStartX() { return selfStartX; }
    public int getSelfFacing() { return selfFacing; }
    public boolean isSelfPowerReady() { return selfPowerReady; }

    public double getBallX() { return ballX; }
    public double getBallY() { return ballY; }
    public double getBallVelX() { return ballVelX; }

    public int getMyScore() { return myScore; }
    public int getOpponentScore() { return opponentScore; }
    public int getRemainingSeconds() { return remainingSeconds; }
    public boolean isTimedMatch() { return timedMatch; }
    public boolean isGoldenGoal() { return goldenGoal; }
}
