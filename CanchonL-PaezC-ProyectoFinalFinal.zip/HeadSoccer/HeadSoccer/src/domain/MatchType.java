package domain;

public enum MatchType {
    TIME,
    GOALS,
    SURVIVAL
}