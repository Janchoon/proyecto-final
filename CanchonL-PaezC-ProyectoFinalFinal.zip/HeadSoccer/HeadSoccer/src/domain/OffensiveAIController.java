package domain;

/** Máquina ofensiva: siempre va por el balón y nunca retrocede a guardia. */
public class OffensiveAIController extends AIController {

    private static final long serialVersionUID = 1L;

    public OffensiveAIController() {
        this(DEFAULT_LEVEL);
    }

    public OffensiveAIController(int level) {
        super("OFENSIVA", level);
    }

    @Override
    public AIController forLevel(int level) {
        return new OffensiveAIController(level);
    }

    @Override
    protected PlayerInput decide(MatchSnapshot snapshot) {
        return chase(snapshot, OFFENSIVE_GUARD, false, 0);
    }
}
