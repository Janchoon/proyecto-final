package domain;

/**
 * Personaje extensible controlado por un jugador (humano o máquina).
 * Es un rectángulo: posX es el centro horizontal y posY el borde superior del
 * cuerpo. Coordenadas de pantalla: Y crece hacia abajo.
 *
 * Las subclases pueden sobrescribir los métodos {@code protected} para
 * personalizar movimiento, salto, patada o reacción a poderes.
 */
public class Player implements java.io.Serializable {

    private static final long serialVersionUID = 1L;

    public static final int WIDTH = 40;
    public static final int HEIGHT = 70;
    public static final double GRAVITY = 0.6;
    public static final double POWER_MAX = 100;
    public static final long POWER_FULL_MILLIS = 10000;
    public static final long STUN_MILLIS = 3000;
    public static final long KICK_COOLDOWN_MILLIS = 300;
    public static final int KICK_REACH = 15;
    public static final double KICK_DAMAGE = 10;
    public static final long PLAYER_KICK_COOLDOWN_MILLIS = 600;

    private final String name;
    private final String country;
    private final int speed;
    private final int jump;
    private final int strength;
    private final PowerType power;
    private final int facing; // +1 mira a la derecha, -1 a la izquierda
    private final PlayerStats stats;
    private final double maxLife;
    private double life;

    private final int fieldWidth;
    private final int floorY;
    private final double startX;

    private double posX;
    private double posY;
    private double veloY;
    private int moveDir;

    private double powerCharge;
    private boolean powerArmed;
    private boolean powerFired;
    private boolean instantPowerFired;
    private long stunMillis;
    private long kickCooldown;

    private PowerType effect;
    private long effectMillis;

    public Player(String name, String country, int speed, int jump, int strength,
                  PowerType power, int startX, int fieldWidth, int floorY, int facing,
                  PlayerStats stats) throws POOBSoccerException {
        validateStat(speed);
        validateStat(jump);
        validateStat(strength);
        this.name = name;
        this.country = country;
        this.speed = speed;
        this.jump = jump;
        this.strength = strength;
        this.power = power;
        this.stats = new PlayerStats(stats == null ? new PlayerStats() : stats);
        this.maxLife = this.stats.getMaxLife();
        this.life = maxLife;
        this.facing = (facing >= 0) ? 1 : -1;
        this.fieldWidth = fieldWidth;
        this.floorY = floorY;
        this.startX = startX;
        resetPosition();
        this.powerCharge = 0;
    }

    private static void validateStat(int value) throws POOBSoccerException {
        if (value < 1 || value > 5) {
            throw new POOBSoccerException(POOBSoccerException.INVALID_STAT);
        }
    }

    // Acciones del jugador

    /** Traduce un {@link PlayerInput} en movimiento, salto y activación de poder. */
    public void applyInput(PlayerInput input) {
        if (input == null) {
            stopMoving();
            return;
        }
        move(input.horizontalDirection());
        if (input.isJump()) {
            jump();
        }
        if (input.isPower()) {
            usePower();
        }
    }

    public void moveLeft() { move(-1); }

    public void moveRight() { move(1); }

    public void stopMoving() { moveDir = 0; }

    private void move(int rawDir) {
        if (rawDir == 0) {
            stopMoving();
            return;
        }
        if (!isStunned() && (effect == null || !effect.blocksMovement())) {
            moveDir = (effect != null) ? effect.adjustMoveDirection(rawDir) : rawDir;
        }
    }

    public void jump() {
        boolean jumpBlocked = effect != null && effect.blocksJump();
        if (!isStunned() && !jumpBlocked && isOnGround()) {
            veloY = -computeJumpVelocity();
        }
    }

    /**
     * Patea el balón si está al alcance. Devuelve true si lo golpeó.
     * Si el poder estaba armado, dispara el tiro de poder recto.
     */
    public boolean kick(Ball ball) {
        if (isStunned() || kickCooldown > 0 || ball == null || !isTouching(ball)) {
            return false;
        }
        kickCooldown = KICK_COOLDOWN_MILLIS;
        if (powerArmed) {
            powerArmed = false;
            powerFired = true;
            power.onBallKick(this, ball, floorY);
        } else {
            double force = computeKickForce();
            ball.setStraight(false);
            ball.setVelocity(facing * force, -force * 0.8);
        }
        return true;
    }

    /** Patada al rival: solo hace daño si está delante dentro del alcance. */
    public boolean kickPlayer(Player rival) {
        if (isStunned() || kickCooldown > 0 || rival == null || rival.isKnockedOut() || !canReach(rival)) {
            return false;
        }
        kickCooldown = PLAYER_KICK_COOLDOWN_MILLIS;
        rival.takeDamage(KICK_DAMAGE * getKickMultiplier());
        return true;
    }

    protected boolean canReach(Player r) {
        double myLeft = posX - getWidth() / 2.0;
        double myRight = myLeft + getWidth();
        double rLeft = r.posX - r.getWidth() / 2.0;
        double rRight = rLeft + r.getWidth();
        boolean inFront = (facing > 0)
                ? (rLeft <= myRight + KICK_REACH && rRight >= myLeft)
                : (rRight >= myLeft - KICK_REACH && rLeft <= myRight);
        boolean sameHeight = r.posY < posY + getHeight() && r.posY + r.getHeight() > posY;
        return inFront && sameHeight;
    }

    /** Resta vida (nunca baja de 0). Al llegar a 0 el jugador queda aturdido. */
    public void takeDamage(double amount) {
        if (amount <= 0 || life <= 0) {
            return;
        }
        life = Math.max(0, life - amount);
        if (life == 0) {
            stun();
        }
    }

    /**
     * Activa o arma el poder cuando la barra está llena.
     * Los poderes instantáneos (como Ilusión) se disparan de inmediato; los
     * demás quedan armados hasta golpear el balón.
     */
    public boolean usePower() {
        if (power == null || !isPowerReady() || powerArmed || isStunned()) {
            return false;
        }
        powerCharge = 0;
        if (power.isInstant()) {
            instantPowerFired = true;
        } else {
            powerArmed = true;
        }
        onPowerTriggered(power);
        return true;
    }

    /** Aturde al jugador durante 3 segundos. */
    public void stun() {
        stunMillis = STUN_MILLIS;
        moveDir = 0;
    }

    public void applyEffect(PowerType type) {
        if (type == null) {
            return;
        }
        boolean grounded = isOnGround();
        effect = type;
        effectMillis = type.getDurationMillis();
        snapToFloor(grounded);
        type.onEffectApplied(this);
        onEffectApplied(type);
    }

    /** Desplaza al jugador horizontalmente respetando los límites de la cancha. */
    public void shiftHorizontal(double deltaX) {
        posX += deltaX;
        double half = getWidth() / 2.0;
        posX = Math.max(half, Math.min(fieldWidth - half, posX));
    }

    /** Cambia la velocidad vertical del jugador (usado por efectos como Tornado). */
    public void setVelocityY(double veloY) {
        this.veloY = veloY;
    }

    /** Suma carga a la barra de poder. */
    public void addPowerCharge(double amount) {
        powerCharge = Math.max(0, Math.min(POWER_MAX, powerCharge + amount));
    }

    // Actualización por cuadro

    public void update(long elapsedMillis) {
        if (stunMillis > 0) {
            stunMillis = Math.max(0, stunMillis - elapsedMillis);
            if (stunMillis == 0 && life <= 0) {
                life = maxLife;
            }
        }
        if (kickCooldown > 0) {
            kickCooldown = Math.max(0, kickCooldown - elapsedMillis);
        }
        if (effect != null) {
            effectMillis -= elapsedMillis;
            if (effectMillis <= 0) {
                boolean grounded = isOnGround();
                effect = null;
                effectMillis = 0;
                snapToFloor(grounded);
            }
        }
        if (isStunned()) {
            moveDir = 0;
        }
        powerCharge = Math.min(POWER_MAX, powerCharge + POWER_MAX * elapsedMillis / POWER_FULL_MILLIS);

        posX += moveDir * computeMoveSpeed();
        if (effect != null) {
            effect.onEffectTick(this, elapsedMillis);
        }
        double half = getWidth() / 2.0;
        posX = Math.max(half, Math.min(fieldWidth - half, posX));

        veloY += GRAVITY;
        posY += veloY;
        if (posY + getHeight() >= floorY) {
            posY = floorY - getHeight();
            veloY = 0;
        }
        onUpdate(elapsedMillis);
    }

    /** Vuelve a su posición inicial (después de un gol). */
    public void resetPosition() {
        effect = null;
        effectMillis = 0;
        posX = startX;
        posY = floorY - getHeight();
        veloY = 0;
        moveDir = 0;
        stunMillis = 0;
        if (life <= 0) {
            life = maxLife;
        }
        kickCooldown = 0;
        powerArmed = false;
        powerFired = false;
        instantPowerFired = false;
    }

    // Hooks de extensión para subclases

    protected double computeMoveSpeed() {
        double s = (2 + speed) * stats.getSpeedMultiplier();
        return (effect != null) ? s * effect.speedMultiplier() : s;
    }

    protected double computeJumpVelocity() {
        return (10 + 1.5 * jump) * stats.getJumpMultiplier();
    }

    protected double computeKickForce() {
        return 3 + 1.5 * strength;
    }

    protected void onPowerTriggered(PowerType power) { }
    protected void onEffectApplied(PowerType type) { }
    protected void onUpdate(long elapsedMillis) { }

    private void snapToFloor(boolean wasGrounded) {
        if (wasGrounded) {
            posY = floorY - getHeight();
            veloY = 0;
        }
    }

    protected boolean isOnGround() {
        return posY + getHeight() >= floorY;
    }

    protected boolean isTouching(Ball ball) {
        double left = posX - getWidth() / 2.0;
        double nearX = Math.max(left, Math.min(ball.getPosX(), left + getWidth()));
        double nearY = Math.max(posY, Math.min(ball.getPosY(), posY + getHeight()));
        double dist = Math.hypot(ball.getPosX() - nearX, ball.getPosY() - nearY);
        return dist <= ball.getRadius() + KICK_REACH;
    }

    /** Devuelve true una sola vez si un tiro de poder salió en la última patada. */
    public boolean consumePowerFired() {
        boolean fired = powerFired;
        powerFired = false;
        return fired;
    }

    /** Devuelve true una sola vez si un poder instantáneo fue activado al pulsar la tecla. */
    public boolean consumeInstantPowerFired() {
        boolean fired = instantPowerFired;
        instantPowerFired = false;
        return fired;
    }

    public boolean isPowerReady() { return powerCharge >= POWER_MAX; }
    public boolean isPowerArmed() { return powerArmed; }
    public boolean isStunned() { return stunMillis > 0 || (effect != null && effect.stunsTarget()); }
    public boolean isKnockedOut() { return life <= 0; }

    public PowerType getPower() { return power; }
    public PowerType getEffect() { return effect; }
    public long getEffectMillisLeft() { return effectMillis; }

    public int getWidth() {
        double scale = (effect != null) ? effect.sizeScale() : 1.0;
        return (int) (WIDTH * scale);
    }

    public int getHeight() {
        double scale = (effect != null) ? effect.sizeScale() : 1.0;
        return (int) (HEIGHT * scale);
    }

    public double getVeloX() { return isStunned() ? 0 : moveDir * computeMoveSpeed(); }
    public String getName() { return name; }
    public String getCountry() { return country; }
    public int getSpeed() { return speed; }
    public int getJump() { return jump; }
    public int getStrength() { return strength; }
    public int getFacing() { return facing; }
    public double getPosX() { return posX; }
    public double getPosY() { return posY; }
    public double getPowerCharge() { return powerCharge; }
    public double getLife() { return life; }
    public double getMaxLife() { return maxLife; }
    public PlayerStats getStats() { return stats; }
    public double getKickMultiplier() { return stats.getKickMultiplier(); }
    public double getStartX() { return startX; }

    /** Poder que tiene armado esperando salir con la patada; null si ninguno. */
    public PowerType getActivePower() { return powerArmed ? power : null; }
}
