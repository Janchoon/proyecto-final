package domain;

import java.io.Serializable;

/**
 * Acciones que un controlador solicita para un cuadro de juego.
 * Es inmutable y no depende de ninguna otra clase del dominio.
 */
public final class PlayerInput implements Serializable {

    private static final long serialVersionUID = 1L;

    public static final PlayerInput NONE = new PlayerInput(false, false, false, false, false);

    private final boolean left;
    private final boolean right;
    private final boolean jump;
    private final boolean kick;
    private final boolean power;

    public PlayerInput() {
        this(false, false, false, false, false);
    }

    public PlayerInput(boolean left, boolean right, boolean jump, boolean kick, boolean power) {
        this.left = left;
        this.right = right;
        this.jump = jump;
        this.kick = kick;
        this.power = power;
    }

    /** Dirección horizontal neta: -1 izquierda, 0 quieto, +1 derecha. */
    public int horizontalDirection() {
        if (left && !right) {
            return -1;
        }
        if (right && !left) {
            return 1;
        }
        return 0;
    }

    public boolean isLeft() { return left; }
    public boolean isRight() { return right; }
    public boolean isJump() { return jump; }
    public boolean isKick() { return kick; }
    public boolean isPower() { return power; }
}
