package domain;

/**
 * Contexto mínimo que un poder puede usar al activarse o impactar (por ejemplo,
 * generar balones ilusorios o anunciar un evento en pantalla) sin acoplar las
 * clases de poder a todo {@link GameEngine}.
 */
public interface PowerContext {
    void spawnFakeBalls(Player victim, PowerType sourceEffect, int count);
    void announcePower(PowerType power, Player victim, double damage, boolean knockedOut);
}
