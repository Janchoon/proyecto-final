package domain;

import java.io.Serializable;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.Map;

/**
 * Clase base abstracta y extensible para los poderes especiales.
 * Cada poder implementa su propio comportamiento en una subclase (activación,
 * tiro de poder, impacto y efecto sobre el rival)
 */
public abstract class PowerType implements Serializable {

    private static final long serialVersionUID = 1L;

    public static final PowerType FREEZE = new FreezePower();
    public static final PowerType SHRINK = new ShrinkPower();
    public static final PowerType CONFUSION = new ConfusionPower();
    public static final PowerType SLOW = new SlowPower();
    public static final PowerType PUSH = new PushPower();
    public static final PowerType LIGHTNING = new LightningPower();
    public static final PowerType TORNADO = new TornadoPower();
    public static final PowerType ILLUSION = new IllusionPower();

    private static final Map<String, PowerType> BUILT_INS;

    static {
        Map<String, PowerType> map = new LinkedHashMap<>();
        for (PowerType p : new PowerType[] {
                FREEZE, SHRINK, CONFUSION, SLOW, PUSH, LIGHTNING, TORNADO, ILLUSION }) {
            map.put(p.id, p);
        }
        BUILT_INS = Collections.unmodifiableMap(map);
    }

    private final String id;
    private final String label;
    private final String effectLabel;
    private final long durationMillis;
    private final int damage;
    private final double shotSpeed;
    private final String description;

    protected PowerType(String id, String label, String effectLabel, long durationMillis,
                        int damage, double shotSpeed, String description) {
        this.id = id;
        this.label = label;
        this.effectLabel = effectLabel;
        this.durationMillis = durationMillis;
        this.damage = damage;
        this.shotSpeed = shotSpeed;
        this.description = description;
    }

    public static PowerType[] values() {
        return BUILT_INS.values().toArray(new PowerType[0]);
    }

    public static PowerType byId(String id) {
        return BUILT_INS.get(id);
    }

    /** Identificador interno usado para sprites y serialización (ej. "FREEZE"). */
    public String name() { return id; }
    public String getLabel() { return label; }
    public String getEffectLabel() { return effectLabel; }
    public long getDurationMillis() { return durationMillis; }
    public int getDamage() { return damage; }
    public double getShotSpeed() { return shotSpeed; }
    public String getDescription() { return description; }

    // Comportamiento extensible del poder

    /** true si el poder se activa al presionar la tecla; false si sale al patear. */
    public boolean isInstant() { return false; }

    /** Ejecuta la activación inmediata cuando {@link #isInstant()} es true. */
    public void onActivateInstant(Player owner, Player victim, PowerContext context) { }

    /** Configura el balón cuando el jugador patea con este poder armado. */
    public void onBallKick(Player kicker, Ball ball, int floorY) {
        ball.setStraight(true);
        ball.setVelocity(kicker.getFacing() * shotSpeed, 0);
    }

    /** Ejecuta el impacto del tiro de poder al golpear al rival. */
    public void onHit(Player owner, Player victim, PowerContext context) {
        double finalDamage = damage * owner.getKickMultiplier();
        boolean wasUp = !victim.isKnockedOut();
        victim.takeDamage(finalDamage);
        victim.applyEffect(this);
        context.announcePower(this, victim, finalDamage, wasUp && victim.isKnockedOut());
    }

    /** Se ejecuta una vez cuando este efecto se aplica sobre la víctima. */
    public void onEffectApplied(Player victim) { }

    /** Se ejecuta en cada cuadro mientras este efecto siga activo sobre la víctima. */
    public void onEffectTick(Player victim, long elapsedMillis) { }

    public boolean stunsTarget() { return false; }
    public boolean blocksMovement() { return false; }
    public boolean blocksJump() { return false; }
    public int adjustMoveDirection(int dir) { return dir; }
    public double speedMultiplier() { return 1.0; }
    public double sizeScale() { return 1.0; }

    protected Object readResolve() {
        PowerType builtIn = BUILT_INS.get(id);
        return (builtIn != null) ? builtIn : this;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (!(o instanceof PowerType)) {
            return false;
        }
        PowerType other = (PowerType) o;
        return id != null && id.equals(other.id);
    }

    @Override
    public int hashCode() {
        return (id == null) ? 0 : id.hashCode();
    }

    @Override
    public String toString() { return label; }
}
