package domain;

/** Poder Aura Azul: lanza al rival hacia su propio arco e impide su movimiento. */
public class PushPower extends PowerType {

    private static final long serialVersionUID = 1L;
    private static final double PUSH_SPEED = 9;

    public PushPower() {
        super("PUSH", "Aura Azul", "Empujado", 1500, 40, 20, "tiro recto a alta velocidad: el rival es lanzado hacia su propio arco");
    }

    @Override
    public void onEffectApplied(Player victim) {
        victim.stopMoving();
    }

    @Override
    public void onEffectTick(Player victim, long elapsedMillis) {
        victim.shiftHorizontal(-victim.getFacing() * PUSH_SPEED);
    }

    @Override
    public boolean blocksMovement() { return true; }
}
