package domain;

/** Poder Reducción: encoge al rival a la mitad de su tamaño. */
public class ShrinkPower extends PowerType {

    private static final long serialVersionUID = 1L;
    private static final double SCALE = 0.5;

    public ShrinkPower() {
        super("SHRINK", "Reducción", "Reducido", 5000, 0, 14, "encoge al oponente a un tamaño diminuto");
    }

    @Override
    public double sizeScale() { return SCALE; }
}
