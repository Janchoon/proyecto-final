package domain;

/** Poder Lentitud: reduce a la mitad la velocidad de movimiento del rival. */
public class SlowPower extends PowerType {

    private static final long serialVersionUID = 1L;
    private static final double FACTOR = 0.5;

    public SlowPower() {
        super("SLOW", "Lentitud", "Ralentizado", 5000, 0, 14, "reduce a la mitad la velocidad del oponente");
    }

    @Override
    public double speedMultiplier() { return FACTOR; }
}
