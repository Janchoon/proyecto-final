package domain;

/** Poder Tornado: tiro a ras de suelo que eleva y deja inconsciente al rival. */
public class TornadoPower extends PowerType {

    private static final long serialVersionUID = 1L;
    private static final double LAUNCH_SPEED = 16;

    public TornadoPower() {
        super("TORNADO", "Tornado", "Inconsciente", 3000, 40, 15, "remolino a ras de suelo: el rival sale volando y no puede moverse, saltar ni patear");
    }

    @Override
    public void onBallKick(Player kicker, Ball ball, int floorY) {
        super.onBallKick(kicker, ball, floorY);
        ball.setPosition(ball.getPosX(), floorY - ball.getRadius());
    }

    @Override
    public void onEffectApplied(Player victim) {
        victim.stopMoving();
        victim.setVelocityY(-LAUNCH_SPEED);
    }

    @Override
    public boolean stunsTarget() { return true; }

    @Override
    public boolean blocksMovement() { return true; }
}
