package persistence;

import domain.GameEngine;
import domain.POOBSoccerException;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InvalidClassException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

/** Guardar y abrir el estado de un partido. */
public final class GameStorage {

    public static final String EXTENSION = "doposoccer";

    private GameStorage() { }

    /** Guarda el partido (y los usuarios que juegan; null para una máquina). */
    public static void save(GameEngine engine, String user1, String user2, File file)
            throws POOBSoccerException {
        if (engine == null || file == null) {
            throw new POOBSoccerException(SAVE_NOTHING);
        }
        try (ObjectOutputStream out = new ObjectOutputStream(new FileOutputStream(file))) {
            out.writeObject(new SavedGame(engine, user1, user2));
        } catch (IOException e) {
            throw new POOBSoccerException("No se pudo guardar la partida en '" + file.getName() + "': " + e.getMessage(), e);
        }
    }

    public static SavedGame open(File file) throws POOBSoccerException {
        if (file == null || !file.isFile()) {
            throw new POOBSoccerException("No existe el archivo de partida" + (file == null ? "." : " '" + file.getName() + "'."));
        }
        try (FileInputStream fis = new FileInputStream(file);
             ObjectInputStream in = new ObjectInputStream(fis)) {
            Object read = in.readObject();
            if (!(read instanceof SavedGame) || !((SavedGame) read).isValid()) {
                throw new POOBSoccerException("El archivo '" + file.getName() + "' no es una partida válida de DOPOSoccer.");
            }
            return (SavedGame) read;
        } catch (InvalidClassException e) {
            throw new POOBSoccerException("La partida '" + file.getName() + "' se guardó con otra versión del juego y no se puede abrir.", e);
        } catch (IOException | ClassNotFoundException | ClassCastException e) {
            throw new POOBSoccerException("No se pudo abrir la partida '" + file.getName() + "'; el archivo está dañado o no es de DOPOSoccer.", e);
        }
    }

    private static final String SAVE_NOTHING = "No hay partida o archivo para guardar.";
}
