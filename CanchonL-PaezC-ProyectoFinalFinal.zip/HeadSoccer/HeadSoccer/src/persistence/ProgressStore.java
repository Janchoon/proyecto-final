package persistence;

import domain.ErrorLog;
import domain.POOBSoccerException;
import domain.PlayerProgress;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.LinkedHashMap;
import java.util.Map;

/**
 * Progreso de los usuarios (puntos y estadísticas), guardado entre ejecuciones
 * en un archivo. El nombre de usuario no distingue mayúsculas.
 */
public class ProgressStore {

    public static final String DEFAULT_FILE = "doposoccer-progress.dat";

    private final File file;
    private final Map<String, PlayerProgress> users = new LinkedHashMap<>();
    private String loadWarning;

    public ProgressStore() {
        this(new File(DEFAULT_FILE));
    }

    public ProgressStore(File file) {
        this.file = file;
        load();
    }

    @SuppressWarnings("unchecked")
    private void load() {
        if (!file.isFile()) {
            return;
        }
        try (FileInputStream fis = new FileInputStream(file);
             ObjectInputStream in = new ObjectInputStream(fis)) {
            Object read = in.readObject();
            users.putAll((Map<String, PlayerProgress>) read);
        } catch (IOException | ClassNotFoundException | ClassCastException e) {
            File backup = new File(file.getPath() + ".bak");
            boolean moved = file.renameTo(backup);
            users.clear();
            loadWarning = "No se pudo leer el progreso guardado (" + e.getMessage() + "). "
                    + (moved ? "Se conservó una copia en " + backup.getName() + " y " : "")
                    + "se empieza con progreso vacío.";
            ErrorLog.log(loadWarning, e);
        }
    }

    /** Mensaje si el archivo de progreso estaba dañado (null si todo bien). */
    public String getLoadWarning() { return loadWarning; }

    /** Devuelve el progreso existente sin crear uno nuevo (null si no existe). */
    public PlayerProgress find(String name) {
        if (name == null || name.trim().isEmpty()) {
            return null;
        }
        return users.get(name.trim().toLowerCase());
    }

    /** Devuelve el progreso del usuario; si no existe, lo crea (puntos 0, estadísticas en 1). */
    public PlayerProgress get(String name) throws POOBSoccerException {
        if (name == null || name.trim().isEmpty()) {
            throw new POOBSoccerException(POOBSoccerException.INVALID_USER_NAME);
        }
        String key = name.trim().toLowerCase();
        PlayerProgress p = users.get(key);
        if (p == null) {
            p = new PlayerProgress(name);
            users.put(key, p);
        }
        return p;
    }

    public void save() throws POOBSoccerException {
        try (ObjectOutputStream out = new ObjectOutputStream(new FileOutputStream(file))) {
            out.writeObject(new LinkedHashMap<>(users));
        } catch (IOException e) {
            throw new POOBSoccerException("No se pudo guardar el progreso de los jugadores en '"
                    + file.getName() + "': " + e.getMessage(), e);
        }
    }
}
