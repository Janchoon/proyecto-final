package presentation;

import domain.GameEngine;
import domain.HeadSoccer;
import domain.MatchState;
import domain.MatchType;
import domain.PlayerProgress;
import domain.PlayerStats;
import domain.Player;
import domain.PowerType;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import javax.swing.JPanel;

/**
 * Marcador. Por cada jugador muestra: nombre y país, goles, barra de poder,
 * poder activo y efecto que sufre. Al centro: tiempo, meta o ronda.
 */
public class ScoreBoardPanel extends JPanel {

    public static final int HEIGHT = 160;
    private static final int BAR_WIDTH = 220;

    private GameEngine engine;
    private double scale = 1.0;
    private PlayerProgress progress1;     // null = máquina
    private PlayerProgress progress2;

    public ScoreBoardPanel() {
        setPreferredSize(new Dimension(GameEngine.FIELD_WIDTH, HEIGHT));
        setBackground(new Color(18, 18, 20));
    }

    /** Misma resolución que la cancha (solo escala el dibujo). */
    public void setScale(double scale) {
        this.scale = scale;
        setPreferredSize(new Dimension((int) Math.round(GameEngine.FIELD_WIDTH * scale),
                (int) Math.round(HEIGHT * scale)));
        revalidate();
        repaint();
    }

    /** Usuarios con su progreso (null = máquina). */
    public void setUsers(PlayerProgress p1, PlayerProgress p2) {
        this.progress1 = p1;
        this.progress2 = p2;
    }

    public void setEngine(GameEngine engine) {
        this.engine = engine;
        repaint();
    }

    public void updateView() {
        repaint();
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        if (engine == null) {
            return;
        }
        Graphics2D g2 = (Graphics2D) g.create();
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        g2.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);

        g2.scale(scale, scale);
        int w = GameEngine.FIELD_WIDTH;
        g2.setColor(new Color(60, 60, 66));
        g2.setStroke(new BasicStroke(2f));
        g2.drawLine(380, 14, 380, HEIGHT - 14);
        g2.drawLine(w - 380, 14, w - 380, HEIGHT - 14);

        drawPlayer(g2, engine.getPlayer(1), 1, 20, false);
        drawPlayer(g2, engine.getPlayer(2), 2, w - 20, true);
        drawCenter(g2, w);
        g2.dispose();
    }

    private void drawCenter(Graphics2D g2, int w) {
        HeadSoccer match = engine.getMatch();
        String top;
        String big;
        if (match.getType() == MatchType.TIME) {
            top = match.isGoldenGoal() ? "GOL DE ORO" : "Tiempo";
            int s = match.getRemainingSeconds();
            big = match.isGoldenGoal() ? "0:00" : String.format("%d:%02d", s / 60, s % 60);
        } else if (match.getType() == MatchType.GOALS) {
            top = "Primero en llegar a";
            big = match.getGoalTarget() + " goles";
        } else {
            top = "Supervivencia";
            big = "Ronda " + engine.getSurvivalRound();
        }
        g2.setColor(Color.LIGHT_GRAY);
        g2.setFont(new Font("SansSerif", Font.PLAIN, 13));
        centered(g2, top, w / 2, 36);
        g2.setColor(match.isGoldenGoal() ? new Color(255, 200, 0) : Color.WHITE);
        g2.setFont(new Font("SansSerif", Font.BOLD, 32));
        centered(g2, big, w / 2, 76);
        if (match.getState() == MatchState.PAUSED) {
            g2.setColor(new Color(255, 200, 0));
            g2.setFont(new Font("SansSerif", Font.BOLD, 13));
            centered(g2, "PAUSA", w / 2, 100);
        }
    }

    /** Bloque de un jugador. anchorX es el borde donde se alinea (izq. para J1, der. para J2). */
    private void drawPlayer(Graphics2D g2, Player p, int number, int anchorX, boolean right) {
        HeadSoccer match = engine.getMatch();
        PlayerProgress prog = (number == 1) ? progress1 : progress2;

        // identificación: personaje (país) y usuario / perfil de la máquina
        g2.setColor(Color.WHITE);
        g2.setFont(new Font("SansSerif", Font.BOLD, 16));
        aligned(g2, p.getName() + " (" + p.getCountry() + ")", anchorX, 22, right);
        g2.setFont(new Font("SansSerif", Font.PLAIN, 12));
        g2.setColor(new Color(120, 200, 255));
        String who = (prog != null)
                ? prog.getName() + " · " + prog.getPoints() + " puntos"
                : (engine.getHumanController(number) != null ? "Jugador"
                        : "Máquina " + engine.getMachineName(number));
        aligned(g2, who, anchorX, 38, right);

        // goles
        String goals = String.format("%02d", match.getScore(number));
        g2.setColor(Color.WHITE);
        g2.setFont(new Font("SansSerif", Font.BOLD, 30));
        aligned(g2, goals, anchorX, 70, right);
        g2.setFont(new Font("SansSerif", Font.PLAIN, 12));
        g2.setColor(Color.LIGHT_GRAY);
        String label = "goles";
        if (match.getType() == MatchType.SURVIVAL) {
            label += "  ·  balones: " + match.getBalls(number);
        }
        int goalsW = g2.getFontMetrics(new Font("SansSerif", Font.BOLD, 30)).stringWidth(goals);
        aligned(g2, label, right ? anchorX - goalsW - 8 : anchorX + goalsW + 8, 70, right);

        int barX = right ? anchorX - BAR_WIDTH : anchorX;

        // vida
        double lifeFrac = p.getMaxLife() <= 0 ? 0 : p.getLife() / p.getMaxLife();
        int lifeY = 80;
        Color lifeColor = lifeFrac > 0.5 ? new Color(80, 200, 90)
                : lifeFrac > 0.25 ? new Color(240, 190, 40) : new Color(225, 70, 60);
        drawBar(g2, barX, lifeY, lifeFrac, lifeColor);
        g2.setFont(new Font("SansSerif", Font.BOLD, 10));
        g2.setColor(Color.WHITE);
        String lifeText = "Vida " + (int) Math.ceil(p.getLife()) + " / " + (int) Math.round(p.getMaxLife());
        g2.drawString(lifeText, barX + (BAR_WIDTH - g2.getFontMetrics().stringWidth(lifeText)) / 2,
                lifeY + 10);

        // barra de poder
        double frac = p.getPowerCharge() / Player.POWER_MAX;
        drawBar(g2, barX, 96, frac, p.isPowerReady() ? new Color(80, 220, 120) : new Color(255, 160, 40));

        // poder activo / estado
        PowerType own = p.getPower();
        String state;
        Color stateColor = Color.LIGHT_GRAY;
        if (own == null) {
            state = "Sin poder";
        } else if (p.getActivePower() != null) {
            state = "ACTIVO: " + own.getLabel() + " (sale al patear)";
            stateColor = new Color(255, 200, 0);
        } else if (p.isPowerReady()) {
            state = own.getLabel() + " LISTO";
            stateColor = new Color(80, 220, 120);
        } else {
            state = own.getLabel() + " " + (int) (frac * 100) + "%";
        }
        g2.setFont(new Font("SansSerif", Font.PLAIN, 12));
        g2.setColor(stateColor);
        aligned(g2, "Poder: " + state, anchorX, 124, right);

        if (p.getEffect() != null) {
            g2.setColor(new Color(120, 200, 255));
            aligned(g2, p.getEffect().getEffectLabel() + " (" + (p.getEffectMillisLeft() / 1000 + 1) + " s)",
                    anchorX, 139, right);
        } else if (p.isStunned()) {
            g2.setColor(new Color(255, 120, 120));
            aligned(g2, "Aturdido", anchorX, 139, right);
        }

        // estadísticas del jugador
        PlayerStats st = p.getStats();
        g2.setFont(new Font("SansSerif", Font.PLAIN, 11));
        g2.setColor(Color.GRAY);
        aligned(g2, "Vel " + st.getSpeed() + " · Patada " + st.getKick() + " · Salto " + st.getJump()
                + " · Superv. " + st.getSurvival(), anchorX, 153, right);
    }

    private static void drawBar(Graphics2D g2, int x, int y, double frac, Color fill) {
        double clamped = Math.max(0, Math.min(1, frac));
        g2.setColor(new Color(50, 50, 56));
        g2.fillRoundRect(x, y, BAR_WIDTH, 12, 8, 8);
        g2.setColor(fill);
        g2.fillRoundRect(x, y, (int) (BAR_WIDTH * clamped), 12, 8, 8);
        g2.setColor(new Color(120, 120, 130));
        g2.drawRoundRect(x, y, BAR_WIDTH, 12, 8, 8);
    }

    private static void centered(Graphics2D g2, String s, int cx, int y) {
        FontMetrics fm = g2.getFontMetrics();
        g2.drawString(s, cx - fm.stringWidth(s) / 2, y);
    }

    private static void aligned(Graphics2D g2, String s, int x, int y, boolean right) {
        FontMetrics fm = g2.getFontMetrics();
        g2.drawString(s, right ? x - fm.stringWidth(s) : x, y);
    }
}