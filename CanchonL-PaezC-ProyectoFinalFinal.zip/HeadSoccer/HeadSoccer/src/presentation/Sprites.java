package presentation;

import java.awt.Image;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.text.Normalizer;
import java.util.HashMap;
import java.util.Map;
import javax.imageio.ImageIO;

/**
 * Cargador de sprites.
 * Busca "sprites/<nombre>.png" en la carpeta del proyecto o en el classpath.
 * Si el archivo no existe devuelve null y quien dibuja usa el dibujo vectorial
 * original, así el juego nunca se rompe por una imagen faltante.
 */
public final class Sprites {

    private static final String DIR = "sprites/";
    private static final Map<String, BufferedImage> CACHE = new HashMap<>();

    private Sprites() {}

    /** @param name nombre sin extensión, p. ej. "ball" o "players/logan". */
    public static BufferedImage get(String name) {
        if (CACHE.containsKey(name)) {
            return CACHE.get(name);
        }
        BufferedImage img = load(name);
        CACHE.put(name, img); // se guarda también el null para no reintentar cada cuadro
        return img;
    }

    /** Normaliza un nombre para usarlo como clave de sprite (sin tildes, minúsculas y '_'). */
    public static String key(String name) {
        return Normalizer.normalize(name, Normalizer.Form.NFD)
                .replaceAll("\\p{M}", "").toLowerCase().replace(' ', '_');
    }

    /** Versión reducida (iconos del menú). */
    public static Image scaled(String name, int w, int h) {
        BufferedImage img = get(name);
        return img == null ? null : img.getScaledInstance(w, h, Image.SCALE_SMOOTH);
    }

    private static BufferedImage load(String name) {
        String file = DIR + name + ".png";
        try {
            File f = new File(file);
            if (f.isFile()) {
                return ImageIO.read(f);
            }
            URL url = Sprites.class.getResource("/" + file);
            if (url != null) {
                return ImageIO.read(url);
            }
        } catch (IOException e) {
            System.err.println("No se pudo leer el sprite " + file + ": " + e.getMessage());
        }
        return null;
    }
}
