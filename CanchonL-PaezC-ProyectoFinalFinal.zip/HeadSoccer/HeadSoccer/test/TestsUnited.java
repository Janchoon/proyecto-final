import domain.*;
import persistence.*;

import java.io.File;
import java.io.FileOutputStream;
import java.io.ObjectOutputStream;
import java.nio.file.Files;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * Suite de 7 pruebas borde pesadas sobre las clases principales del dominio y persistencia.
 */
public class TestsUnited {

    private static int passed = 0;

    public static void main(String[] args) throws Exception {
        test1_HeadSoccerTimeGoldenGoalAndInvalidTransitions();
        test2_PlayerSimultaneousEffectsKnockoutAndBoundaries();
        test3_BallGoalPrecisionCrossbarAntiStickAnd2000FrameStability();
        test4_GameEngineSurvival10RoundsWrapAroundAndPoints();
        test5_GameEngineMvmIllusionShotTimeoutAndPauseFreeze();
        test6_ProgressStoreStatsExponentialCostAndCorruptionRecovery();
        test7_GameStorageDeepRoundTripReadResolveAndBadFiles();

        System.out.println("TODAS LAS PRUEBAS BORDE PASARON (" + passed + "/7)");
    }

    private static void check(boolean condition, String message) {
        if (!condition) {
            throw new AssertionError("FALLO EN PRUEBA: " + message);
        }
    }

    private static void checkNear(double actual, double expected, double eps, String message) {
        if (Math.abs(actual - expected) > eps) {
            throw new AssertionError("FALLO EN PRUEBA: " + message
                    + " (esperado=" + expected + ", real=" + actual + ")");
        }
    }

    private static void expectException(ThrowingAction action, String expectedPart, String message) {
        try {
            action.run();
        } catch (POOBSoccerException ex) {
            if (expectedPart != null && !ex.getMessage().contains(expectedPart)) {
                throw new AssertionError("Excepción inesperada en '" + message + "': " + ex.getMessage());
            }
            return;
        } catch (Exception ex) {
            throw new AssertionError("Tipo de excepción inesperado en '" + message + "': " + ex);
        }
        throw new AssertionError("Se esperaba POOBSoccerException en: " + message);
    }

    @FunctionalInterface
    private interface ThrowingAction {
        void run() throws Exception;
    }

    /**
     * PRUEBA 1 (HeadSoccer):
     * - Límites de configuración inválidos (0 min, 61 min, 0 goles, 100 goles, survival PVP/MVM).
     * - Límite exacto al milisegundo (59_999 ms vs +1 ms) entrando en Gol de Oro empatados 2-2.
     * - Inmunidad del reloj en Gol de Oro, definición instantánea al primer gol e inmutabilidad post-fin.
     */
    private static void test1_HeadSoccerTimeGoldenGoalAndInvalidTransitions() throws Exception {
        expectException(() -> HeadSoccer.byTime(GameMode.PVP, 0), "1 y 60", "0 minutos");
        expectException(() -> HeadSoccer.byTime(GameMode.PVP, 61), "1 y 60", "61 minutos");
        expectException(() -> HeadSoccer.byGoals(GameMode.PVP, 0), "1 y 99", "0 goles");
        expectException(() -> HeadSoccer.byGoals(GameMode.PVP, 100), "1 y 99", "100 goles");
        expectException(() -> HeadSoccer.survival(GameMode.PVP), "Jugador vs Máquina", "survival PVP");
        expectException(() -> HeadSoccer.survival(GameMode.MVM), "Jugador vs Máquina", "survival MVM");

        HeadSoccer match = HeadSoccer.byTime(GameMode.PVP, 1);
        expectException(match::pause, "actual del partido", "pausar antes de iniciar");
        expectException(match::resume, "actual del partido", "reanudar antes de iniciar");

        match.start();
        expectException(match::start, "actual del partido", "iniciar dos veces");

        // Empate 2-2 antes de agotar el minuto
        match.ballEnteredGoal(2); // gol de J1
        match.ballEnteredGoal(2); // gol de J1
        match.ballEnteredGoal(1); // gol de J2
        match.ballEnteredGoal(1); // gol de J2
        check(match.getScore(1) == 2 && match.getScore(2) == 2, "marcador debe ser 2-2");

        // Faltando 1 ms todavía no termina ni entra en gol de oro
        match.tick(59_999);
        check(match.getState() == MatchState.RUNNING, "debe seguir corriendo en 1 ms restante");
        check(match.getRemainingSeconds() == 1, "ceil(1ms) debe ser 1s");
        check(!match.isGoldenGoal(), "no debe activar gol de oro antes de 0");

        // Exactamente en 0 ms empatados -> Gol de Oro
        match.tick(1);
        check(match.getRemainingSeconds() == 0, "segundos restantes deben ser 0");
        check(match.isGoldenGoal(), "debe entrar a gol de oro al empatar en 0");
        check(match.getState() == MatchState.RUNNING, "partido debe seguir corriendo en gol de oro");

        // Tiempo adicional en gol de oro no termina el partido
        match.tick(300_000);
        check(!match.isFinished() && match.getWinner() == 0, "gol de oro no acaba por reloj");

        // Primer gol en gol de oro define al instante
        match.ballEnteredGoal(2); // anota J1
        check(match.isFinished(), "primer gol en gol de oro debe finalizar");
        check(match.getWinner() == 1, "ganador debe ser J1");
        check(match.getScore(1) == 3 && match.getScore(2) == 2, "marcador final 3-2");

        // Goles y transiciones después de terminado no mutan estado ni marcador
        match.ballEnteredGoal(1);
        match.ballEnteredGoal(1);
        match.tick(10_000);
        check(match.getScore(2) == 2 && match.getWinner() == 1, "no debe sumar goles tras finalizar");
        expectException(match::pause, "actual del partido", "no pausar partido terminado");
        expectException(match::resume, "actual del partido", "no reanudar partido terminado");
        expectException(() -> match.ballEnteredGoal(3), "1 o 2", "jugador inválido");

        passed++;
        System.out.println("[OK] Prueba 1: HeadSoccer (límites, milisegundo exacto, gol de oro, post-fin)");
    }

    /**
     * PRUEBA 2 (Player + PowerType):
     * - Shrink en el aire -> aterrizaje -> expiración en suelo sin hundirse (snapToFloor).
     * - Tornado + aturdimiento + daño letal masivo (overkill): vida clamp a 0, bloqueo total de acciones,
     *   imposibilidad de volver a patear al KO y recuperación total de vida al terminar el stun.
     * - Confusión con entrada izquierda+derecha simultánea (0 neto) y empuje contra borde de cancha.
     */
    private static void test2_PlayerSimultaneousEffectsKnockoutAndBoundaries() throws Exception {
        PlayerStats maxStats = new PlayerStats(5, 5, 5, 1); // maxLife = 100
        Player p1 = new Player("Test", "Colombia", 5, 5, 5, PowerType.FREEZE,
                200, GameEngine.FIELD_WIDTH, GameEngine.FLOOR_Y, 1, maxStats);
        Player attacker = new Player("Rival", "Brasil", 3, 3, 3, PowerType.TORNADO,
                220, GameEngine.FIELD_WIDTH, GameEngine.FLOOR_Y, -1, new PlayerStats());
        Ball ball = new Ball(210, GameEngine.FLOOR_Y - 16, 16, GameEngine.FIELD_WIDTH, GameEngine.FLOOR_Y);

        // Shrink aplicado mientras salta (en el aire)
        p1.jump();
        p1.update(16);
        check(p1.getPosY() < GameEngine.FLOOR_Y - Player.HEIGHT, "debe estar en el aire");
        p1.applyEffect(PowerType.SHRINK);
        check(p1.getHeight() == Player.HEIGHT / 2 && p1.getWidth() == Player.WIDTH / 2, "tamaño reducido a la mitad");

        // Simular hasta caer al suelo mientras sigue reducido
        for (int i = 0; i < 120; i++) {
            p1.update(16);
        }
        checkNear(p1.getPosY() + p1.getHeight(), GameEngine.FLOOR_Y, 0.001, "pies reducidos apoyados exactamente en el suelo");

        // Al expirar exactamente los 5000 ms, vuelve al tamaño normal sin hundirse bajo el piso
        p1.update(5000);
        check(p1.getEffect() == null, "efecto Shrink debe expirar");
        check(p1.getHeight() == Player.HEIGHT, "altura restaurada");
        checkNear(p1.getPosY() + p1.getHeight(), GameEngine.FLOOR_Y, 0.001, "snapToFloor al expirar Shrink");

        // Tornado eleva e inhabilita
        p1.addPowerCharge(100);
        p1.applyEffect(PowerType.TORNADO);
        p1.update(16);
        check(p1.isStunned(), "Tornado debe aturdir");
        check(p1.getPosY() < GameEngine.FLOOR_Y - Player.HEIGHT, "Tornado debe lanzar hacia arriba");
        p1.applyInput(new PlayerInput(false, true, true, true, true));
        check(!p1.usePower(), "no debe activar poder estando aturdido");
        check(!p1.kick(ball), "no debe patear balón estando aturdido");
        check(!p1.kickPlayer(attacker), "no debe patear rival estando aturdido");

        // Esperar a que termine Tornado y aplicar daño overkill masivo
        p1.update(3500);
        p1.takeDamage(9999.0);
        check(p1.getLife() == 0.0, "vida nunca debe ser negativa");
        check(p1.isKnockedOut() && p1.isStunned(), "vida 0 debe dejar KO y aturdido");
        // Colocar al atacante al lado: no puede volver a patear al que ya está KO
        for (int i = 0; i < 60; i++) {
            p1.update(16);
        }
        check(!attacker.kickPlayer(p1), "no se debe poder patear a un jugador ya KO");
        // Terminar el stun (3000 ms desde el KO)
        p1.update(2500);
        check(!p1.isStunned() && !p1.isKnockedOut(), "debe despertar al pasar los 3000 ms");
        checkNear(p1.getLife(), p1.getMaxLife(), 0.001, "al despertar debe recuperar vida máxima");

        // Confusión + teclas opuestas simultáneas + estrés contra borde derecho
        p1.applyEffect(PowerType.CONFUSION);
        double xBefore = p1.getPosX();
        p1.applyInput(new PlayerInput(true, true, false, false, false));
        p1.update(16);
        checkNear(p1.getPosX(), xBefore, 0.001, "izquierda+derecha simultáneas debe anular movimiento");

        // Presionar izquierda estando confundido mueve hacia la DERECHA hasta chocar con la pared
        for (int i = 0; i < 250; i++) {
            p1.applyInput(new PlayerInput(true, false, false, false, false));
            p1.update(16);
        }
        checkNear(p1.getPosX(), GameEngine.FIELD_WIDTH - p1.getWidth() / 2.0, 0.001,
                "Confusión empuja hacia la derecha sin salirse del límite de la cancha");

        passed++;
        System.out.println("[OK] Prueba 2: Player + PowerType (Shrink aéreo, Tornado, Overkill KO, Confusión en bordes)");
    }

    /**
     * PRUEBA 3 (Ball + Goal + GameEngine crossbar):
     * - Precisión exacta de Goal.isGoal() en los 4 bordes (1 px fuera = no gol; exacto dentro = gol).
     * - Tiro recto sin gravedad + rebote amortiguado contra pared.
     * - Caída lenta sobre travesaño en GameEngine: empuje lateral anti-atasco.
     * - Estrés de 2000 cuadros verificando ausencia de NaN/Infinity y respeto absoluto de límites.
     */
    private static void test3_BallGoalPrecisionCrossbarAntiStickAnd2000FrameStability() throws Exception {
        int r = GameEngine.BALL_RADIUS; // 16
        Goal rightGoal = new Goal(2, GameEngine.FIELD_WIDTH - GameEngine.GOAL_WIDTH,
                GameEngine.FLOOR_Y - GameEngine.GOAL_HEIGHT, GameEngine.GOAL_WIDTH, GameEngine.GOAL_HEIGHT);

        Ball b = new Ball(GameEngine.FIELD_WIDTH / 2, 120, r, GameEngine.FIELD_WIDTH, GameEngine.FLOOR_Y);
        // Casi entra por línea de gol (sobresale 0.01 px) -> NO es gol
        b.setPosition(rightGoal.getPosX() + r - 0.01, rightGoal.getPosY() + r + 10);
        check(!rightGoal.isGoal(b), "balón sobresaliendo 0.01 px en línea de gol no debe ser gol");
        // Casi entra por debajo del travesaño (sobresale 0.01 px arriba) -> NO es gol
        b.setPosition(rightGoal.getPosX() + r + 5, rightGoal.getPosY() + r - 0.01);
        check(!rightGoal.isGoal(b), "balón rozando travesaño por arriba no debe ser gol");
        // Completamente dentro en el límite exacto -> SÍ es gol
        b.setPosition(rightGoal.getPosX() + r, rightGoal.getPosY() + r);
        check(rightGoal.isGoal(b), "balón completamente dentro en borde exacto sí debe ser gol");

        // Tiro recto sin gravedad y rebote en pared
        b.reset();
        b.setStraight(true);
        b.setVelocity(20, 0);
        double yStart = b.getPosY();
        for (int i = 0; i < 10; i++) {
            b.update();
            checkNear(b.getPosY(), yStart, 0.0001, "tiro recto no debe caer por gravedad");
        }
        // Lanzar contra pared derecha
        b.setPosition(GameEngine.FIELD_WIDTH - r - 5, 200);
        b.setVelocity(20, 0);
        b.update();
        checkNear(b.getPosX(), GameEngine.FIELD_WIDTH - r, 0.0001, "balón se detiene en pared derecha");
        checkNear(b.getVelociX(), -20 * Ball.BOUNCE_DAMPING, 0.0001, "rebote en pared aplica BOUNCE_DAMPING");

        // Anti-atasco sobre el travesaño dentro de GameEngine
        List<CharacterProfile> chars = CharacterCatalog.all();
        GameEngine engine = new GameEngine(GameMode.PVP, MatchType.GOALS, 5, 1,
                chars.get(0), chars.get(1), null, null, null, null);
        engine.start();
        Ball gb = engine.getBall();
        Goal g1 = engine.getGoal(1); // dueño 1 (izquierdo), empuja hacia +X (+1.5)
        // Posicionar balón justo encima del travesaño izquierdo cayendo lento (|newVy| < REST_THRESHOLD)
        gb.setPosition(g1.getPosX() + g1.getWidth() / 2.0, g1.getPosY() - r - 0.1);
        gb.setVelocity(0, 0.2); // tras ball.update(): vy = 0.8 -> | -0.8 * 0.75 | = 0.6 < 1.0
        engine.update(16);
        check(gb.getVelociX() > 1.0, "travesaño izquierdo debe empujar balón lento hacia la cancha (+vx)");
        checkNear(gb.getVelociY(), 0.0, 0.0001, "velocidad vertical debe quedar en 0 al quedar sobre el umbral");

        // Estrés de 2000 cuadros con caída y rodamiento
        gb.setPosition(450, 50);
        gb.setVelocity(25, -18);
        for (int i = 0; i < 2000; i++) {
            gb.update();
            check(!Double.isNaN(gb.getPosX()) && !Double.isNaN(gb.getPosY()), "sin NaN en 2000 cuadros");
            check(gb.getPosX() >= r && gb.getPosX() <= GameEngine.FIELD_WIDTH - r, "balón dentro en X");
            check(gb.getPosY() >= r && gb.getPosY() <= GameEngine.FLOOR_Y - r, "balón dentro en Y");
        }
        checkNear(gb.getPosY(), GameEngine.FLOOR_Y - r, 0.001, "balón reposa en el suelo tras 2000 cuadros");
        check(Math.abs(gb.getVelociX()) < 0.01, "fricción del suelo debe frenar casi por completo");

        passed++;
        System.out.println("[OK] Prueba 3: Ball + Goal + Crossbar (precisión 0.01px, tiro recto, anti-atasco, 2000 cuadros)");
    }

    /**
     * PRUEBA 4 (GameEngine — Supervivencia completa de 10 rondas):
     * - Juega 9 rondas ganando 3-0 en cada una para superar el tamaño del catálogo (8 personajes)
     *   y validar el wrap-around cíclico del rival y el tope de nivel de IA (máx 5).
     * - Pierde en la ronda 10 (recibiendo 3 goles), validando fin de serie y puntaje exacto.
     */
    private static void test4_GameEngineSurvival10RoundsWrapAroundAndPoints() throws Exception {
        List<CharacterProfile> chars = CharacterCatalog.all();
        GameEngine engine = new GameEngine(
                GameMode.PVM, MatchType.SURVIVAL, 1, 1,
                chars.get(0), chars.get(1),
                new PlayerStats(5, 5, 5, 5), null,
                new ClumsyAIController(), new ClumsyAIController());
        engine.start();

        Set<String> rivalsSeen = new HashSet<>();
        for (int round = 1; round <= 9; round++) {
            check(engine.getSurvivalRound() == round, "debe estar en ronda " + round);
            check(!engine.isOver(), "serie no debe haber terminado en ronda " + round);
            rivalsSeen.add(engine.getPlayer(2).getName());

            // Anotar 3 goles en el arco derecho (arco de jugador 2) -> gana J1 la ronda
            for (int g = 0; g < HeadSoccer.SURVIVAL_BALLS; g++) {
                engine.getBall().setPosition(GameEngine.FIELD_WIDTH - GameEngine.GOAL_WIDTH + 30,
                        GameEngine.FLOOR_Y - 40);
                engine.getBall().setVelocity(0, 0);
                engine.update(16);
            }
            check(engine.getSurvivalRound() == round + 1, "debe avanzar inmediatamente a ronda " + (round + 1));
        }

        // Tras 9 rondas ganadas (> 8 personajes), debe haber rotado por todo el catálogo y hecho wrap-around
        check(rivalsSeen.size() == chars.size(), "debe recorrer los " + chars.size() + " rivales distintos del catálogo");
        // En ronda 10, rival índice (1 + 9) % 8 == 2
        check(engine.getPlayer(2).getName().equals(chars.get((1 + 9) % chars.size()).getName()),
                "en ronda 10 debe hacer wrap-around circular correcto al personaje esperado");

        // Perder ronda 10 recibiendo 3 goles en el arco izquierdo (arco de J1)
        for (int g = 0; g < HeadSoccer.SURVIVAL_BALLS; g++) {
            engine.getBall().setPosition(30, GameEngine.FLOOR_Y - 40);
            engine.getBall().setVelocity(0, 0);
            engine.update(16);
        }

        check(engine.isOver(), "serie de supervivencia debe terminar cuando J1 pierde una ronda");
        check(engine.getWinner() == 2, "ganador del último partido debe ser 2 (máquina)");
        int expectedPoints = PlayerProgress.WIN_POINTS * 9 + PlayerProgress.LOSS_POINTS; // 9*100 + 25 = 925
        check(engine.getPointsEarned(1) == expectedPoints, "puntaje supervivencia J1 debe ser " + expectedPoints);
        check(engine.getPointsEarned(2) == 0, "la máquina no debe ganar puntos");

        passed++;
        System.out.println("[OK] Prueba 4: GameEngine Supervivencia (10 rondas, wrap-around de rivales, puntos exactos)");
    }

    /**
     * PRUEBA 5 (GameEngine MVM + IllusionPower + Timeout de tiro de poder + Pausa congelada):
     * - Activación instantánea de Ilusión -> 7 balones falsos y limpieza exacta al vencer los 2500 ms.
     * - Timeout de tiro de poder (Push) tras 2500 ms sin impactar al rival -> vuelve a balón normal y no aplica efecto.
     * - Simulación MVM de 1500 cuadros y prueba de inmunidad absoluta durante PAUSED.
     */
    private static void test5_GameEngineMvmIllusionShotTimeoutAndPauseFreeze() throws Exception {
        CharacterProfile illusionChar = CharacterCatalog.byCountry("Estados Unidos"); // Jake - ILLUSION
        CharacterProfile pushChar = CharacterCatalog.byCountry("Corea del Sur");      // Minjun - PUSH

        // 1) Activar Ilusión end-to-end vía HumanController -> GameEngine.update()
        GameEngine illusionEngine = new GameEngine(
                GameMode.PVM, MatchType.TIME, 1, 2,
                illusionChar, pushChar, null, null,
                new OffensiveAIController(), new ExpertAIController());
        illusionEngine.start();
        Player j1 = illusionEngine.getPlayer(1);
        Player j2 = illusionEngine.getPlayer(2);
        j1.addPowerCharge(Player.POWER_MAX);
        illusionEngine.getHumanController(1).requestPower();
        illusionEngine.update(16);
        check(illusionEngine.getFakeBalls().size() == 7, "Ilusión debe generar exactamente 7 balones falsos");
        check(j2.getEffect() == PowerType.ILLUSION, "víctima debe quedar bajo efecto ILLUSION");

        // Avanzar hasta casi 2500 ms (todavía activo) y luego completar > 2500 ms -> desaparecen los falsos
        for (int i = 0; i < 154; i++) { // 154 * 16 + 16 = 2480 ms
            illusionEngine.update(16);
        }
        check(j2.getEffect() == PowerType.ILLUSION, "en 2480 ms Ilusión debe seguir activa");
        check(illusionEngine.getFakeBalls().size() == 7, "mientras dure Ilusión deben seguir los 7 balones falsos");
        illusionEngine.update(64); // supera 2500 ms
        check(j2.getEffect() != PowerType.ILLUSION, "efecto Ilusión debe expirar tras 2500 ms");
        check(illusionEngine.getFakeBalls().isEmpty(), "balones falsos deben limpiarse al expirar Ilusión");

        // 2) Estrés MVM de 1500 cuadros (24s simulados) sin NaN ni término anticipado
        GameEngine engine = new GameEngine(
                GameMode.MVM, MatchType.TIME, 1, 2,
                illusionChar, pushChar, null, null,
                new OffensiveAIController(), new ExpertAIController());
        engine.start();
        for (int i = 0; i < 1500; i++) {
            engine.update(16);
        }
        check(!engine.isOver(), "partido de 2 minutos no debe terminar en 24s (1500*16ms)");
        check(!Double.isNaN(engine.getBall().getPosX()), "posición del balón válida tras 1500 cuadros MVM");

        // Verificar timeout del tiro recto directamente:
        GameEngine shotEngine = new GameEngine(
                GameMode.PVP, MatchType.GOALS, 10, 1,
                pushChar, illusionChar, null, null, null, null);
        shotEngine.start();
        Player s1 = shotEngine.getPlayer(1);
        Player s2 = shotEngine.getPlayer(2);
        s1.addPowerCharge(Player.POWER_MAX);
        // Poner balón frente a J1 (200) y J2 lejos en 700, J1 con fuerza de tiro hacia derecha y luego J1 dispara
        shotEngine.getBall().setPosition(s1.getPosX() + 20, GameEngine.FLOOR_Y - 16);
        shotEngine.getBall().setVelocity(0, 0);
        HumanController h1 = shotEngine.getHumanController(1);
        h1.requestPower();
        h1.setKick(true);
        // Poner a J2 en el aire arriba para que el balón no lo choque
        s2.setVelocityY(-30);
        shotEngine.update(16);
        h1.setKick(false);
        check(shotEngine.getShotType() == PowerType.PUSH, "Push debe quedar como shotType activo en vuelo");
        check(shotEngine.getBall().isStraight(), "balón debe viajar recto durante el tiro de poder");

        // Esperar > 2500 ms manteniendo a J2 fuera de trayectoria
        for (int i = 0; i < 160; i++) { // 2560 ms
            s2.setVelocityY(-10);
            shotEngine.update(16);
        }
        check(shotEngine.getShotType() == null, "shotType debe expirar tras 2500 ms sin golpear rival");
        check(!shotEngine.getBall().isStraight(), "balón debe perder modo recto tras expirar el tiro");
        check(s2.getEffect() == null, "J2 no debe recibir efecto tras expirar el tiro");

        // 3) Pausa absoluta: nada cambia mientras está PAUSED
        shotEngine.pause();
        double bx = shotEngine.getBall().getPosX();
        double by = shotEngine.getBall().getPosY();
        double p1x = s1.getPosX();
        double charge = s1.getPowerCharge();
        for (int i = 0; i < 50; i++) {
            shotEngine.update(500);
        }
        checkNear(shotEngine.getBall().getPosX(), bx, 0.0001, "pausa congela balón X");
        checkNear(shotEngine.getBall().getPosY(), by, 0.0001, "pausa congela balón Y");
        checkNear(s1.getPosX(), p1x, 0.0001, "pausa congela jugador");
        checkNear(s1.getPowerCharge(), charge, 0.0001, "pausa congela barra de poder");

        passed++;
        System.out.println("[OK] Prueba 5: GameEngine MVM (Ilusión 7 falsos, timeout tiro Push, congelamiento en pausa)");
    }

    /**
     * PRUEBA 6 (PlayerStats + PlayerProgress + ProgressStore):
     * - Curva exponencial de costos hasta nivel 10 (500..128000) y bloqueo en máximo.
     * - Atomicidad si faltan puntos (no descuenta nada ni sube nivel).
     * - Aislamiento de copia en GameEngine.
     * - Case-insensitivity, find() sin fantasmas, y recuperación con backup .bak si el archivo está corrupto.
     */
    private static void test6_ProgressStoreStatsExponentialCostAndCorruptionRecovery() throws Exception {
        PlayerProgress prog = new PlayerProgress("  Camila  ");
        check(prog.getName().equals("Camila"), "nombre debe hacer trim");

        // Subir SPEED de 1 a 10 verificando cada costo: 500 * 2^(level-1)
        int totalSpent = 0;
        for (int level = 1; level < PlayerStats.MAX; level++) {
            int expectedCost = 500 * (1 << (level - 1));
            check(prog.getStats().upgradeCost(PlayerStats.Stat.SPEED) == expectedCost,
                    "costo nivel " + level + " debe ser " + expectedCost);

            // Faltando 1 punto debe fallar atómicamente
            prog.addPoints(expectedCost - 1 - prog.getPoints());
            int pointsBefore = prog.getPoints();
            expectException(() -> prog.buy(PlayerStats.Stat.SPEED), "Puntos insuficientes", "compra con 1 punto menos");
            check(prog.getPoints() == pointsBefore && prog.getStats().getSpeed() == level,
                    "fallo de compra no debe alterar puntos ni nivel");

            // Con el último punto alcanza exacto
            prog.addPoints(1);
            prog.buy(PlayerStats.Stat.SPEED);
            totalSpent += expectedCost;
            check(prog.getPoints() == 0, "debe gastar exacto quedando en 0");
            check(prog.getStats().getSpeed() == level + 1, "debe subir a nivel " + (level + 1));
        }
        check(totalSpent == 255_500, "suma de 500..128000 debe ser 255500");
        checkNear(prog.getStats().getSpeedMultiplier(), 1.9, 0.0001, "nivel 10 debe dar multiplicador 1.9");

        // Al llegar a 10 no permite comprar ni saber costo
        prog.addPoints(1_000_000);
        expectException(() -> prog.buy(PlayerStats.Stat.SPEED), "máximo", "compra sobre nivel 10");

        // Aislamiento de stats dentro de GameEngine
        List<CharacterProfile> chars = CharacterCatalog.all();
        GameEngine isolated = new GameEngine(GameMode.PVP, MatchType.GOALS, 3, 1,
                chars.get(0), chars.get(1), prog.getStats(), null, null, null);
        checkNear(isolated.getPlayer(1).getMaxLife(), 100.0, 0.001, "survival aún en 1 -> 100 de vida");
        prog.buy(PlayerStats.Stat.SURVIVAL);
        checkNear(prog.getStats().getMaxLife(), 110.0, 0.001, "progreso subió a 110 de vida");
        checkNear(isolated.getPlayer(1).getMaxLife(), 100.0, 0.001, "partido en curso no debe mutar sus stats");

        // ProgressStore: persistencia, búsqueda sin fantasmas y corrupción
        File tmpDir = Files.createTempDirectory("hs-progress-test").toFile();
        File storeFile = new File(tmpDir, "progress.dat");
        ProgressStore store = new ProgressStore(storeFile);
        check(store.find("nadie") == null, "find no debe crear usuarios");
        expectException(() -> store.get("   "), "vacío", "usuario en blanco");

        PlayerProgress u1 = store.get("  Ana  ");
        u1.addPoints(600);
        u1.buy(PlayerStats.Stat.KICK);
        check(store.get("ANA") == u1, "búsqueda case-insensitive debe devolver mismo objeto");
        store.save();

        ProgressStore reloaded = new ProgressStore(storeFile);
        check(reloaded.getLoadWarning() == null, "carga limpia no debe tener advertencia");
        check(reloaded.find("ana") != null && reloaded.find("ana").getPoints() == 100
                && reloaded.find("ana").getStats().getKick() == 2, "datos persistidos exactos");

        // Corromper archivo y verificar backup .bak
        try (FileOutputStream fos = new FileOutputStream(storeFile)) {
            fos.write(new byte[] { 1, 2, 3, 4, 5, 6, 7 });
        }
        ProgressStore corrupted = new ProgressStore(storeFile);
        check(corrupted.getLoadWarning() != null, "archivo dañado debe reportar loadWarning");
        check(corrupted.find("ana") == null, "progreso dañado debe iniciar limpio");
        check(new File(storeFile.getPath() + ".bak").isFile(), "debe conservar respaldo .bak del archivo dañado");

        passed++;
        System.out.println("[OK] Prueba 6: Stats + ProgressStore (costos 2^n, atomicidad, aislamiento, recuperación .bak)");
    }

    /**
     * PRUEBA 7 (GameStorage + SavedGame + PowerType.readResolve):
     * - Serialización en caliente de un partido pausado con efectos activos, 7 fakeBalls,
     *   ronda de supervivencia > 1 y marcador parcial.
     * - Verificación de identidad == de PowerType tras deserializar (readResolve) y continuación jugable.
     * - Manejo seguro de archivos inexistentes, vacíos y con objetos inválidos.
     */
    private static void test7_GameStorageDeepRoundTripReadResolveAndBadFiles() throws Exception {
        CharacterProfile jake = CharacterCatalog.byCountry("Estados Unidos");
        CharacterProfile santiago = CharacterCatalog.byCountry("Colombia");

        PlayerStats s1 = new PlayerStats(4, 3, 2, 5);
        GameEngine engine = new GameEngine(
                GameMode.PVM, MatchType.SURVIVAL, 1, 1,
                jake, santiago, s1, null,
                new ExpertAIController(), new ExpertAIController());
        engine.start();

        // Avanzar a ronda 2 en Supervivencia
        for (int g = 0; g < HeadSoccer.SURVIVAL_BALLS; g++) {
            engine.getBall().setPosition(GameEngine.FIELD_WIDTH - GameEngine.GOAL_WIDTH + 30,
                    GameEngine.FLOOR_Y - 40);
            engine.getBall().setVelocity(0, 0);
            engine.update(16);
        }
        check(engine.getSurvivalRound() == 2, "debe haber llegado a ronda 2 antes de guardar");

        // Anotar 1 gol del rival en ronda 2 y aplicar efectos activos + fakeBalls
        engine.getBall().setPosition(30, GameEngine.FLOOR_Y - 40);
        engine.getBall().setVelocity(0, 0);
        engine.update(16);

        Player p1 = engine.getPlayer(1);
        Player p2 = engine.getPlayer(2);
        p1.applyEffect(PowerType.SHRINK);
        p2.applyEffect(PowerType.ILLUSION);
        engine.spawnFakeBalls(p2, PowerType.ILLUSION, 7);
        engine.pause();

        File tmpDir = Files.createTempDirectory("hs-save-test").toFile();
        File saveFile = new File(tmpDir, "match.doposoccer");
        GameStorage.save(engine, "JugadorUno", null, saveFile);

        SavedGame loaded = GameStorage.open(saveFile);
        check("JugadorUno".equals(loaded.getUser1()) && loaded.getUser2() == null, "usuarios guardados exactos");
        GameEngine re = loaded.getEngine();
        check(re.isPaused(), "partido abierto debe seguir pausado");
        check(re.getSurvivalRound() == 2, "ronda de supervivencia preservada");
        check(re.getMatch().getScore(2) == 1 && re.getMatch().getBalls(1) == 2, "marcador y balones preservados");
        check(re.getFakeBalls().size() == 7, "fakeBalls preservados tras serializar");

        // Identidad por referencia == garantizada por PowerType.readResolve()
        check(re.getPlayer(1).getEffect() == PowerType.SHRINK,
                "PowerType.readResolve debe preservar identidad == para SHRINK");
        check(re.getPlayer(2).getEffect() == PowerType.ILLUSION,
                "PowerType.readResolve debe preservar identidad == para ILLUSION");

        // Reanudar y simular para confirmar que sigue funcional después de deserializar
        re.resume();
        for (int i = 0; i < 350; i++) { // > 5000 ms para que expiren efectos
            re.update(16);
        }
        check(re.getPlayer(1).getEffect() == null && re.getPlayer(2).getEffect() == null,
                "efectos heredados deben expirar normalmente tras reanudar");
        check(re.getFakeBalls().isEmpty(), "fakeBalls heredados deben limpiarse al expirar el efecto");

        // Archivos inválidos / corruptos
        expectException(() -> GameStorage.save(null, "a", "b", saveFile), "No hay partida", "save con motor null");
        expectException(() -> GameStorage.open(new File(tmpDir, "no_existe.doposoccer")), "No existe", "archivo inexistente");

        File emptyFile = new File(tmpDir, "vacio.doposoccer");
        emptyFile.createNewFile();
        expectException(() -> GameStorage.open(emptyFile), "dañado", "archivo vacío");

        File wrongTypeFile = new File(tmpDir, "otro.doposoccer");
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(wrongTypeFile))) {
            oos.writeObject("NoSoySavedGame");
        }
        expectException(() -> GameStorage.open(wrongTypeFile), "partida válida", "objeto distinto de SavedGame");

        passed++;
        System.out.println("[OK] Prueba 7: GameStorage (serialización profunda, readResolve ==, reanudación y archivos dañados)");
    }
}
