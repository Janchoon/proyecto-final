package domain;

import java.util.Random;

/**
 * Máquina: persigue el balón, salta si está arriba, patea al tocarlo y usa el
 * poder en cuanto la barra se llena. El nivel (1 a 5) controla qué tan seguido
 * "piensa": a mayor nivel, reacciona más rápido.
 */
public class AIController implements Controller {

    private final int level;
    private final Random random = new Random();
    private PlayerInput last = new PlayerInput();

    public AIController(int level) {
        this.level = Math.max(1, Math.min(5, level));
    }

    @Override
    public PlayerInput read(Player self, Player opponent, Ball ball) {
        if (random.nextDouble() > 0.45 + 0.11 * level) {
            return last;                      // este cuadro no reacciona
        }
        PlayerInput in = new PlayerInput();
        double dx = ball.getPosX() - self.getPosX();
        // balón lejos, en la mitad rival: espera en su posición de guardia
        double ahead = (ball.getPosX() - self.getStartX()) * self.getFacing();
        boolean ballFar = ahead > 330;
        // tiro en camino a su arco: vuelve a taparlo en lugar de perseguirlo
        boolean incoming = ball.getVelociX() * self.getFacing() < -3 && ahead > 0;
        if (ballFar || incoming) {
            dx = self.getStartX() - self.getPosX();
        }
        if (Math.abs(dx) > 12) {
            in.left = dx < 0;
            in.right = dx > 0;
        }
        boolean ballAbove = ball.getPosY() < self.getPosY() - 5;
        // balón a su espalda (hacia su propio arco): salta por encima para no empujarlo
        boolean ballBehind = dx * self.getFacing() < 0;
        if ((ballAbove && Math.abs(dx) < 80) || (ballBehind && Math.abs(dx) < 90)) {
            in.jump = true;
        }
        if (ballFar) {
            in.jump = false;
        }
        in.kick = true;                        // patea apenas lo alcance
        in.power = self.isPowerReady();
        last = in;
        return in;
    }
}