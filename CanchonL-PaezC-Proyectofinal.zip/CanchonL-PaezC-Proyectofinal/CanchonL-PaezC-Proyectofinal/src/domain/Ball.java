package domain;

/**
 * Balón del partido. Coordenadas de pantalla: X crece hacia la derecha
 * y Y crece hacia ABAJO. Está afectado por la gravedad y rebota en el
 * suelo, en el techo y en los bordes de la cancha.
 */
public class Ball {

    public static final double GRAVITY = 0.6;       // aceleración por cuadro
    public static final double BOUNCE_DAMPING = 0.75; // energía que conserva al rebotar
    public static final double FLOOR_FRICTION = 0.98; // frena en X al rodar
    public static final double REST_THRESHOLD = 1.0;  // bajo esto, deja de rebotar

    private double posX;
    private double posY;
    private double velociX;
    private double velociY;
    private final int radius;

    // posición inicial (para reiniciar tras un gol)
    private final double startX;
    private final double startY;

    // límites de la cancha
    private final int fieldWidth;
    private final int floorY;

    public Ball(int posX, int posY, int radius, int fieldWidth, int floorY) {
        this.posX = posX;
        this.posY = posY;
        this.startX = posX;
        this.startY = posY;
        this.radius = radius;
        this.fieldWidth = fieldWidth;
        this.floorY = floorY;
        this.velociX = 0;
        this.velociY = 0;
    }

    /** Avanza un cuadro: gravedad, movimiento y rebotes. */
    public void update() {
        velociY += GRAVITY;
        posX += velociX;
        posY += velociY;

        bounceOffFloor();
        bounceOffCeiling();
        bounceOffWalls();
    }

    private void bounceOffFloor() {
        if (posY + radius >= floorY) {
            posY = floorY - radius;
            if (Math.abs(velociY) < REST_THRESHOLD) {
                velociY = 0;                          // quedó rodando
            } else {
                velociY = -velociY * BOUNCE_DAMPING;  // rebota
            }
            velociX *= FLOOR_FRICTION;
        }
    }

    private void bounceOffCeiling() {
        if (posY - radius <= 0) {
            posY = radius;
            velociY = -velociY * BOUNCE_DAMPING;
        }
    }

    private void bounceOffWalls() {
        if (posX - radius <= 0) {
            posX = radius;
            velociX = -velociX * BOUNCE_DAMPING;
        } else if (posX + radius >= fieldWidth) {
            posX = fieldWidth - radius;
            velociX = -velociX * BOUNCE_DAMPING;
        }
    }

    /** Cambia la velocidad del balón (lo usan las patadas y los poderes). */
    public void setVelocity(double velociX, double velociY) {
        this.velociX = velociX;
        this.velociY = velociY;
    }

    /** Vuelve al punto inicial, quieto: cae desde el centro. */
    public void reset() {
        posX = startX;
        posY = startY;
        velociX = 0;
        velociY = 0;
    }
    public void setPosition(double posX, double posY){
        this.posX = posX;
        this.posY = posY;
    }

    public double getPosX() { return posX; }
    public double getPosY() { return posY; }
    public double getVelociX() { return velociX; }
    public double getVelociY() { return velociY; }
    public int getRadius() { return radius; }
}