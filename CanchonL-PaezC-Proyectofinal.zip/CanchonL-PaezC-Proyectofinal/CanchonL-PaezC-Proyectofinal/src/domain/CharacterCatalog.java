package domain;

import java.util.Collections;
import java.util.List;
import java.util.ArrayList;

/** Personajes disponibles. El poder depende del país. */
public final class CharacterCatalog {

    private static final List<CharacterProfile> ALL = new ArrayList<>();

    static {
        ALL.add(new CharacterProfile("Logan",    "Canadá",   3, 3, 4, PowerType.FREEZE));
        ALL.add(new CharacterProfile("Santiago", "Colombia", 4, 4, 2, PowerType.SHRINK));
        ALL.add(new CharacterProfile("Rafael",   "Brasil",   4, 3, 3, PowerType.CONFUSION));
        ALL.add(new CharacterProfile("Haruto",   "Japón",    2, 5, 3, PowerType.SLOW));
    }

    private CharacterCatalog() { }

    public static List<CharacterProfile> all() {
        return Collections.unmodifiableList(ALL);
    }

    public static CharacterProfile byCountry(String country) throws POOBSoccerException {
        for (CharacterProfile p : ALL) {
            if (p.getCountry().equalsIgnoreCase(country)) {
                return p;
            }
        }
        throw new POOBSoccerException(POOBSoccerException.INVALID_SETUP);
    }
}