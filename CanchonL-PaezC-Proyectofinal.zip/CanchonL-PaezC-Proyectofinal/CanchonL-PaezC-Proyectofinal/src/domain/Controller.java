package domain;

public interface Controller {
    PlayerInput read(Player self, Player opponent, Ball ball);
}