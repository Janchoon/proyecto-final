package domain;

public enum GameMode {
    PVP,  // Jugador vs Jugador
    PVM,  // Jugador vs Máquina
    MVM   // Máquina vs Máquina
}