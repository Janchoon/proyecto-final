package domain;

/**
 * Arco de un jugador. Es un rectángulo pegado al borde de la cancha.
 * Hay gol cuando el balón entra COMPLETAMENTE en el rectángulo.
 * Coordenadas de pantalla: Y crece hacia abajo.
 */
public class Goal {

    private final int owner;      // jugador que defiende este arco (1 o 2)
    private final int posX;       // esquina superior izquierda
    private final int posY;
    private final int width;
    private final int height;

    public Goal(int owner, int posX, int posY, int width, int height)
            throws POOBSoccerException {
        if (owner != 1 && owner != 2) {
            throw new POOBSoccerException(POOBSoccerException.INVALID_PLAYER);
        }
        this.owner = owner;
        this.posX = posX;
        this.posY = posY;
        this.width = width;
        this.height = height;
    }

    /** true si el balón está completamente dentro del arco. */
    public boolean isGoal(Ball ball) {
        double r = ball.getRadius();
        return ball.getPosX() - r >= posX
            && ball.getPosX() + r <= posX + width
            && ball.getPosY() - r >= posY
            && ball.getPosY() + r <= posY + height;
    }

    public int getOwner() { return owner; }
    public int getPosX() { return posX; }
    public int getPosY() { return posY; }
    public int getWidth() { return width; }
    public int getHeight() { return height; }
}