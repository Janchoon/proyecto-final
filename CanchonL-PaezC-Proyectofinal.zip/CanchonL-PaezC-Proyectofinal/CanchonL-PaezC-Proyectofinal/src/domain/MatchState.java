package domain;

public enum MatchState {
    NOT_STARTED,
    RUNNING,
    PAUSED,
    FINISHED
}