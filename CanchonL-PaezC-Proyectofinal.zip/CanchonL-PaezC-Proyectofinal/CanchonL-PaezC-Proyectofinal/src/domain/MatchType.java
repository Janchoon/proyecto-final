package domain;

public enum MatchType {
    TIME,      // 60 segundos; si hay empate, gol de oro
    GOALS,     // gana el primero en llegar a 3, 5 o 7 goles
    SURVIVAL   // solo PvsM; se juega con balones en lugar de goles
}