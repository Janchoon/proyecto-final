package domain;

/**
 * Excepción del dominio de POOBSoccer.
 */
public class POOBSoccerException extends Exception {

    public static final String SURVIVAL_ONLY_PVM = "El modo supervivencia solo está disponible en Jugador vs Máquina.";
    public static final String INVALID_GOAL_TARGET = "La meta de goles debe ser 3, 5 o 7.";
    public static final String INVALID_PLAYER = "El jugador debe ser 1 o 2.";
    public static final String INVALID_STAT = "Las estadísticas deben estar entre 1 y 5.";
    public static final String INVALID_STATE = "Esa acción no es válida en el estado actual del partido.";
    public static final String INVALID_SETUP = "La configuración del partido está incompleta o no existe el personaje.";

    public POOBSoccerException(String message) {
        super(message);
    }
}