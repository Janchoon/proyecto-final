package domain;

import domain.PowerType;

/**
 * Personaje controlado por un jugador (humano o máquina).
 * Es un rectángulo: posX es el centro horizontal y posY el borde superior del
 * cuerpo. Coordenadas de pantalla: Y crece hacia abajo.
 * Las estadísticas (velocidad, salto, fuerza) van de 1 a 5.
 * La lógica avanza por cuadros, igual que Ball.
 */
public class Player {

    public static final int WIDTH = 40;
    public static final int HEIGHT = 70;
    public static final double POWER_MAX = 100;
    public static final long POWER_FULL_MILLIS = 10000; // tiempo en llenar la barra
    public static final long STUN_MILLIS = 3000;        // aturdimiento
    public static final long KICK_COOLDOWN_MILLIS = 300;
    public static final int KICK_REACH = 15;            // alcance extra de la patada
    public static final double SHRINK_SCALE = 0.5;

    private final String name;
    private final String country;
    private final int speed;
    private final int jump;
    private final int strength;
    private final PowerType power;
    private final int facing;       // +1 mira a la derecha, -1 a la izquierda

    private final int fieldWidth;
    private final int floorY;
    private final double startX;

    private double posX;            // centro horizontal del cuerpo
    private double posY;            // borde superior del cuerpo
    private double veloY;
    private int moveDir;            // -1 izquierda, 0 quieto, +1 derecha

    private double powerCharge;     // 0 a POWER_MAX
    private boolean powerArmed;     // se pidió usar el poder; sale al golpear el balón
    private boolean powerFired;     // el poder se disparó en la última patada
    private long stunMillis;
    private long kickCooldown;

    private PowerType effect; // efecto que sufre (null = ninguno)
    private long effectMillis;

    public Player(String name, String country, int speed, int jump, int strength,
                  int startX, int fieldWidth, int floorY, int facing)
            throws POOBSoccerException {
        this(name, country, speed, jump, strength, null,
                startX, fieldWidth, floorY, facing);
    }

    public Player(String name, String country, int speed, int jump, int strength,
                 PowerType power, int startX, int fieldWidth, int floorY, int facing)
            throws POOBSoccerException {
        validateStat(speed);
        validateStat(jump);
        validateStat(strength);
        this.name = name;
        this.country = country;
        this.speed = speed;
        this.jump = jump;
        this.strength = strength;
        this.power = power;
        this.facing = (facing >= 0) ? 1 : -1;
        this.fieldWidth = fieldWidth;
        this.floorY = floorY;
        this.startX = startX;
        resetPosition();
        this.powerCharge = 0;
    }

    private static void validateStat(int value) throws POOBSoccerException {
        if (value < 1 || value > 5) {
            throw new POOBSoccerException(POOBSoccerException.INVALID_STAT);
        }
    }

    //Acciones del jugador 

    public void moveLeft(){
        if (!isStunned()) moveDir = (effect == PowerType.CONFUSION) ? 1 : -1;
    }
    public void moveRight(){
        if (!isStunned()) moveDir = (effect == PowerType.CONFUSION) ? -1 : 1;
    }
    public void stopMoving() { moveDir = 0; }

    public void jump() {
        if (!isStunned() && isOnGround()) {
            veloY = -(10 + 1.5 * jump);
        }
    }
    
    /**
     * Patea el balón si está al alcance. Devuelve true si lo golpeó.
     * Si el poder estaba listo y pedido, se dispara con este golpe.
     */
    public boolean kick(Ball ball) {
        if (isStunned() || kickCooldown > 0 ||!isTouching(ball)) {
            return false;
        }
        double force = 3 + 1.5 * strength;
        ball.setVelocity(facing * force, -force * 0.8);
        kickCooldown = KICK_COOLDOWN_MILLIS;
        if (powerArmed) {
            powerArmed = false;
            powerCharge = 0;
            powerFired = true;
        }
        return true;
    }

    /** Pide usar el poder: solo funciona con la barra llena. */
    public boolean usePower() {
        if (power != null && isPowerReady() && !isStunned()) {
            powerArmed = true;
            return true;
        }
        return false;
    }

    /** Aturde al jugador: no puede moverse, saltar ni patear 3 segundos. */
    public void stun() {
        stunMillis = STUN_MILLIS;
        moveDir = 0;
    }

    public void applyEffect(PowerType type){
        if (type == null){return;}
        boolean grounded = isOnGround();
        effect = type;
        effectMillis = type.getDurationMillis();
        if (type == PowerType.FREEZE){
            moveDir = 0;
        }
        snapToFloor(grounded);
    }
    //Actualización por cuadro

    public void update(long elapsedMillis) {
        if (stunMillis > 0) {
            stunMillis = Math.max(0, stunMillis - elapsedMillis);
        }
        if (kickCooldown > 0) {
            kickCooldown = Math.max(0, kickCooldown - elapsedMillis);
        }
        if (effect != null) {
            effectMillis -= elapsedMillis;
            if (effectMillis <= 0) {
                boolean grounded = isOnGround();
                effect = null;
                effectMillis = 0;
                snapToFloor(grounded);
            }
        }
        if (isStunned()) {
            moveDir = 0;
        }
        powerCharge = Math.min(POWER_MAX,
                powerCharge + POWER_MAX * elapsedMillis / POWER_FULL_MILLIS);

        posX += moveDir * moveSpeed();
        double half = getWidth() / 2.0;
        posX = Math.max(half, Math.min(fieldWidth - half, posX));

        veloY += Ball.GRAVITY;
        posY += veloY;
        if (posY + getHeight() >= floorY) {
            posY = floorY - getHeight();
            veloY = 0;
        }
    }

    /** Vuelve a su posición inicial (después de un gol). */
    public void resetPosition() {
        effect = null;
        effectMillis = 0;
        posX = startX;
        posY = floorY - getHeight();
        veloY = 0;
        moveDir = 0;
        stunMillis = 0;
        kickCooldown = 0;
        powerArmed = false;
    }

    //Consultas
    private double moveSpeed(){
        double s = 2 + speed;
        return (effect == PowerType.SLOW) ? s * 0.5 : s;
    }
    private void snapToFloor(boolean wasGrounded){
        if (wasGrounded){
            posY = floorY - getHeight();
            veloY = 0;
        }
    }
    private boolean isOnGround() {
        return posY + getHeight() >= floorY;
    }

    private boolean isTouching(Ball ball) {
        double left = posX - getWidth() / 2.0;
        double nearX = Math.max(left, Math.min(ball.getPosX(), left + getWidth()));
        double nearY = Math.max(posY, Math.min(ball.getPosY(), posY + getHeight()));
        double dist = Math.hypot(ball.getPosX() - nearX, ball.getPosY() - nearY);
        return dist <= ball.getRadius() + KICK_REACH;
    }

    /** Devuelve true una sola vez si el poder se disparó en la última patada. */
    public boolean consumePowerFired() {
        boolean fired = powerFired;
        powerFired = false;
        return fired;
    }

    public boolean isPowerReady() { return powerCharge >= POWER_MAX; }
    public boolean isPowerArmed() { return powerArmed; }
    public boolean isFrozen() {return effect == PowerType.FREEZE;}
    public boolean isStunned() { return stunMillis > 0 || isFrozen();}

    public PowerType getactivePower() {return powerArmed ? power : null;}
    public PowerType getPower() {return power;}
    public PowerType getEffect() {return effect;}
    public long getEffectMillisLeft() { return effectMillis; }

    public int getWidth() {
        return (effect == PowerType.SHRINK) ? (int) (WIDTH * SHRINK_SCALE) : WIDTH;
    }

    public int getHeight() {
        return (effect == PowerType.SHRINK) ? (int) (HEIGHT * SHRINK_SCALE) : HEIGHT;
    }
    public double getVeloX() { return isStunned() ? 0 : moveDir * moveSpeed(); }
    public String getName() { return name; }
    public String getCountry() { return country; }
    public int getSpeed() { return speed; }
    public int getJump() { return jump; }
    public int getStrength() { return strength; }
    public int getFacing() { return facing; }
    public double getPosX() { return posX; }
    public double getPosY() { return posY; }
    public double getPowerCharge() { return powerCharge; }
    public double getStartX() { return startX; }

    /** Poder que tiene activo (pedido, esperando salir con la patada); null si ninguno. */
    public PowerType getActivePower() { return powerArmed ? power : null; }
}