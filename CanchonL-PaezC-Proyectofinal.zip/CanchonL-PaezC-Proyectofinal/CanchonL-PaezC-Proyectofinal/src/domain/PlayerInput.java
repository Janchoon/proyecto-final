package domain;

/** Acciones que un controlador pide para un cuadro. */
public class PlayerInput {
    public boolean left;
    public boolean right;
    public boolean jump;
    public boolean kick;
    public boolean power;
}