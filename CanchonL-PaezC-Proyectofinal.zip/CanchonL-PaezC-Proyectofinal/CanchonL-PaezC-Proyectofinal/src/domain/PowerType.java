package domain;

/**
 * Poderes especiales. Todos afectan al OPONENTE cuando el dueño del poder
 * golpea el balón con la barra de poder llena.
 */
public enum PowerType {
    FREEZE("Congelación", "Congelado", 3000,
            "congela al oponente en un bloque de hielo"),
    SHRINK("Reducción", "Reducido", 5000,
            "encoge al oponente a un tamaño diminuto"),
    CONFUSION("Confusión", "Confundido", 5000,
            "invierte los controles de movimiento del oponente"),
    SLOW("Lentitud", "Ralentizado", 5000,
            "reduce a la mitad la velocidad del oponente");

    private final String label;
    private final String effectLabel;
    private final long durationMillis;
    private final String description;

    PowerType(String label, String effectLabel, long durationMillis, String description) {
        this.label = label;
        this.effectLabel = effectLabel;
        this.durationMillis = durationMillis;
        this.description = description;
    }

    public String getLabel() { return label; }
    public String getEffectLabel() { return effectLabel; }
    public long getDurationMillis() { return durationMillis; }
    public String getDescription() { return description; }

    @Override
    public String toString() { return label; }
}