package presentation;


import domain.Ball;
import domain.GameEngine;
import domain.Goal;
import domain.MatchState;
import domain.MatchType;
import domain.Player;
import domain.PowerType;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import javax.swing.JPanel;

/** Dibuja la cancha, los arcos, los jugadores y el balon que expone el motor. */
public class GameBoardPanel extends JPanel {

    private static final Color GRASS_A = new Color(24, 138, 24);
    private static final Color GRASS_B = new Color(30, 150, 30);
    private static final Color[] SHIRT = { new Color(43, 108, 176), new Color(221, 107, 32) };

    private GameEngine engine;

    public GameBoardPanel() {
        setPreferredSize(new Dimension(GameEngine.FIELD_WIDTH, GameEngine.FIELD_HEIGHT));
        setBackground(new Color(18, 18, 20));
    }

    public void setEngine(GameEngine engine) {
        this.engine = engine;
        repaint();
    }

    public void updateView() {
        repaint();
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        Graphics2D g2 = (Graphics2D) g.create();
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        g2.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
        drawField(g2);
        if (engine != null) {
            drawGoal(g2, engine.getGoal(1));
            drawGoal(g2, engine.getGoal(2));
            drawPlayer(g2, engine.getPlayer(1), 0);
            drawPlayer(g2, engine.getPlayer(2), 1);
            drawBall(g2, engine.getBall());
            drawOverlay(g2);
        }
        g2.dispose();
    }

    private void drawField(Graphics2D g2) {
        int w = GameEngine.FIELD_WIDTH;
        int floor = GameEngine.FLOOR_Y;
        for (int i = 0; i < 10; i++) {                       // franjas de pasto
            g2.setColor(i % 2 == 0 ? GRASS_A : GRASS_B);
            g2.fillRect(i * w / 10, 0, w / 10 + 1, floor);
        }
        g2.setColor(new Color(14, 100, 14));                 // suelo
        g2.fillRect(0, floor, w, GameEngine.FIELD_HEIGHT - floor);
        g2.setColor(Color.WHITE);
        g2.setStroke(new BasicStroke(3f));
        g2.drawLine(0, floor, w, floor);
        g2.drawLine(w / 2, 0, w / 2, floor);
        g2.drawOval(w / 2 - 70, floor - 70, 140, 140);
    }

    private void drawGoal(Graphics2D g2, Goal goal) {
        g2.setColor(new Color(255, 255, 255, 235));
        g2.fillRoundRect(goal.getPosX(), goal.getPosY(), goal.getWidth(), goal.getHeight(), 8, 8);
        g2.setColor(new Color(170, 170, 170));
        g2.setStroke(new BasicStroke(1f));
        for (int x = goal.getPosX() + 10; x < goal.getPosX() + goal.getWidth(); x += 12) {
            g2.drawLine(x, goal.getPosY(), x, goal.getPosY() + goal.getHeight());
        }
        for (int y = goal.getPosY() + 10; y < goal.getPosY() + goal.getHeight(); y += 12) {
            g2.drawLine(goal.getPosX(), y, goal.getPosX() + goal.getWidth(), y);
        }
    }

    private void drawBall(Graphics2D g2, Ball b) {
        int r = b.getRadius();
        int x = (int) b.getPosX() - r;
        int y = (int) b.getPosY() - r;
        g2.setColor(new Color(0, 0, 0, 60));                 // sombra
        g2.fillOval(x + 2, GameEngine.FLOOR_Y - 5, 2 * r - 4, 8);
        g2.setColor(new Color(230, 50, 40));
        g2.fillOval(x, y, 2 * r, 2 * r);
        g2.setColor(Color.WHITE);
        g2.setStroke(new BasicStroke(2f));
        g2.drawOval(x, y, 2 * r, 2 * r);
        g2.drawLine(x + r, y + 3, x + r, y + 2 * r - 3);
        g2.drawLine(x + 3, y + r, x + 2 * r - 3, y + r);
    }

    private void drawPlayer(Graphics2D g2, Player p, int idx) {
        int w = p.getWidth();
        int h = p.getHeight();
        int left = (int) p.getPosX() - w / 2;
        int top = (int) p.getPosY();
        int head = w;                                         // diámetro de la cabeza
        int bodyTop = top + (int) (head * 0.85);

        // poder listo / activo: halo
        if (p.getActivePower() != null || p.isPowerReady()) {
            g2.setColor(p.getActivePower() != null ? new Color(255, 215, 0, 140) : new Color(80, 220, 120, 90));
            g2.fillOval(left - 8, top - 8, w + 16, h + 16);
        }
        g2.setColor(SHIRT[idx]);                              // cuerpo
        g2.fillRoundRect(left + w / 6, bodyTop, w - w / 3, h - (bodyTop - top) - h / 5, 8, 8);
        g2.setColor(new Color(30, 30, 30));                   // piernas
        int legW = Math.max(3, w / 5);
        g2.fillRect(left + w / 4, top + h - h / 5, legW, h / 5);
        g2.fillRect(left + w - w / 4 - legW, top + h - h / 5, legW, h / 5);
        g2.setColor(new Color(241, 194, 125));                // cabeza
        g2.fillOval(left, top, head, head);
        g2.setColor(new Color(40, 30, 20));                   // pelo
        g2.fillArc(left, top, head, head, 0, 180);
        g2.setColor(Color.BLACK);                             // ojo hacia donde mira
        int eyeX = left + head / 2 + p.getFacing() * head / 5 - 2;
        g2.fillOval(eyeX, top + head / 2 - 2, 4, 4);

        g2.setColor(Color.WHITE);                             // nombre sobre la cabeza
        g2.setFont(new Font("SansSerif", Font.BOLD, 11));
        FontMetrics fm = g2.getFontMetrics();
        g2.drawString(p.getName(), (int) p.getPosX() - fm.stringWidth(p.getName()) / 2, top - 6);

        PowerType e = p.getEffect();
        if (e == PowerType.FREEZE) {                          // bloque de hielo
            g2.setColor(new Color(150, 220, 255, 150));
            g2.fillRoundRect(left - 6, top - 6, w + 12, h + 12, 10, 10);
            g2.setColor(new Color(220, 245, 255));
            g2.setStroke(new BasicStroke(2f));
            g2.drawRoundRect(left - 6, top - 6, w + 12, h + 12, 10, 10);
        } else if (e == PowerType.CONFUSION) {
            g2.setColor(new Color(255, 230, 0));
            g2.setFont(new Font("SansSerif", Font.BOLD, 20));
            g2.drawString("?", (int) p.getPosX() - 6, top - 18);
        } else if (e == PowerType.SLOW) {
            g2.setColor(new Color(160, 120, 255));
            g2.setFont(new Font("SansSerif", Font.BOLD, 16));
            g2.drawString("zZ", (int) p.getPosX() - 8, top - 18);
        } else if (p.isStunned()) {
            g2.setColor(new Color(255, 230, 0));
            g2.setFont(new Font("SansSerif", Font.BOLD, 16));
            g2.drawString("* * *", (int) p.getPosX() - 18, top - 18);
        }
    }

    private void drawOverlay(Graphics2D g2) {
        int w = GameEngine.FIELD_WIDTH;
        String event = engine.getEventText();
        if (!event.isEmpty() && !engine.isOver()) {
            g2.setFont(new Font("SansSerif", Font.BOLD, 26));
            shadowCentered(g2, event, w / 2, 90, Color.WHITE);
        }
        if (engine.isPaused()) {
            dim(g2);
            g2.setFont(new Font("SansSerif", Font.BOLD, 48));
            shadowCentered(g2, "PAUSA", w / 2, 230, new Color(255, 200, 0));
            g2.setFont(new Font("SansSerif", Font.PLAIN, 16));
            shadowCentered(g2, "P / Esc: continuar     M: volver al menú", w / 2, 270, Color.WHITE);
        } else if (engine.isOver()) {
            dim(g2);
            g2.setFont(new Font("SansSerif", Font.BOLD, 40));
            shadowCentered(g2, resultText(), w / 2, 220, new Color(255, 200, 0));
            g2.setFont(new Font("SansSerif", Font.PLAIN, 16));
            shadowCentered(g2, "ENTER: volver al menú", w / 2, 270, Color.WHITE);
        } else if (engine.getMatch().getState() == MatchState.NOT_STARTED) {
            dim(g2);
        }
    }

    private String resultText() {
        if (engine.getType() == MatchType.SURVIVAL) {
            int won = engine.getSurvivalRound() - 1;
            return "Fin de la serie: " + won + (won == 1 ? " ronda ganada" : " rondas ganadas");
        }
        Player winner = engine.getPlayer(engine.getWinner());
        return "¡Gana " + winner.getName() + " (" + winner.getCountry() + ")!";
    }

    private void dim(Graphics2D g2) {
        g2.setColor(new Color(0, 0, 0, 120));
        g2.fillRect(0, 0, getWidth(), getHeight());
    }

    private void shadowCentered(Graphics2D g2, String s, int cx, int y, Color c) {
        FontMetrics fm = g2.getFontMetrics();
        int x = cx - fm.stringWidth(s) / 2;
        g2.setColor(new Color(0, 0, 0, 160));
        g2.drawString(s, x + 2, y + 2);
        g2.setColor(c);
        g2.drawString(s, x, y);
    }
}
