package presentation;

import domain.GameEngine;
import domain.HumanController;

import java.awt.BorderLayout;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import javax.swing.JPanel;
import javax.swing.SwingUtilities;
import javax.swing.Timer;

/**
 * Pantalla de juego: marcador arriba, cancha al centro. Lee el teclado
 * (J1: A D W S Q — J2: flechas y Ctrl derecho) y avanza el motor cada 16 ms.
 * P / Esc pausan, M vuelve al menú desde la pausa y Enter al terminar.
 */
public class GamePanel extends JPanel {

    private static final int FRAME_MILLIS = 16;

    private final ScoreBoardPanel scoreBoard = new ScoreBoardPanel();
    private final GameBoardPanel gameBoard = new GameBoardPanel();
    private final Timer timer;
    private final Runnable onExit;
    private GameEngine engine;

    public GamePanel(Runnable onExit) {
        this.onExit = onExit;
        setLayout(new BorderLayout());
        add(scoreBoard, BorderLayout.NORTH);
        add(gameBoard, BorderLayout.CENTER);
        setFocusable(true);
        timer = new Timer(FRAME_MILLIS, e -> tick());
        addKeyListener(new KeyAdapter() {
            @Override
            public void keyPressed(KeyEvent e) {
                handleKey(e, true);
            }

            @Override
            public void keyReleased(KeyEvent e) {
                handleKey(e, false);
            }
        });
    }

    public void startMatch(GameEngine newEngine) {
        this.engine = newEngine;
        scoreBoard.setEngine(newEngine);
        gameBoard.setEngine(newEngine);
        newEngine.start();
        timer.start();
        SwingUtilities.invokeLater(this::requestFocusInWindow);
    }

    public void stop() {
        timer.stop();
    }

    private void tick() {
        engine.update(FRAME_MILLIS);
        scoreBoard.updateView();
        gameBoard.updateView();
        if (engine.isOver()) {
            timer.stop();                    // ultimo cuadro ya dibujado
        }
    }

    private void handleKey(KeyEvent e, boolean down) {
        if (engine == null) {
            return;
        }
        HumanController h1 = engine.getHumanController(1);
        HumanController h2 = engine.getHumanController(2);
        switch (e.getKeyCode()) {
            case KeyEvent.VK_A:     if (h1 != null) h1.setLeft(down);  break;
            case KeyEvent.VK_D:     if (h1 != null) h1.setRight(down); break;
            case KeyEvent.VK_W:     if (h1 != null) h1.setJump(down);  break;
            case KeyEvent.VK_S:     if (h1 != null) h1.setKick(down);  break;
            case KeyEvent.VK_Q:     if (h1 != null && down) h1.requestPower(); break;
            case KeyEvent.VK_LEFT:  if (h2 != null) h2.setLeft(down);  break;
            case KeyEvent.VK_RIGHT: if (h2 != null) h2.setRight(down); break;
            case KeyEvent.VK_UP:    if (h2 != null) h2.setJump(down);  break;
            case KeyEvent.VK_DOWN:  if (h2 != null) h2.setKick(down);  break;
            case KeyEvent.VK_CONTROL:
                if (h2 != null && down && e.getKeyLocation() == KeyEvent.KEY_LOCATION_RIGHT) {
                    h2.requestPower();
                }
                break;
            case KeyEvent.VK_P:
            case KeyEvent.VK_ESCAPE:
                if (!down && !engine.isOver()) {
                    engine.togglePause();
                    gameBoard.updateView();
                    scoreBoard.updateView();
                }
                break;
            case KeyEvent.VK_M:
                if (!down && engine.isPaused()) {
                    onExit.run();
                }
                break;
            case KeyEvent.VK_ENTER:
                if (!down && engine.isOver()) {
                    onExit.run();
                }
                break;
            default:
                break;
        }
    }
}
