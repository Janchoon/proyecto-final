package presentation;


import domain.GameEngine;

import java.awt.CardLayout;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.SwingUtilities;

/** Ventana principal: alterna entre el menu y la pantalla de juego. */
public class HeadSoccerGUI extends JFrame {

    private static final String MENU = "menu";
    private static final String GAME = "game";

    private final CardLayout cards = new CardLayout();
    private final JPanel root = new JPanel(cards);
    private final MenuPanel menu;
    private final GamePanel game;

    public HeadSoccerGUI() {
        setTitle("POOBSoccer");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setResizable(false);

        menu = new MenuPanel(this::showGame);
        game = new GamePanel(this::showMenu);
        root.add(menu, MENU);
        root.add(game, GAME);
        add(root);
        pack();
        setLocationRelativeTo(null);
    }

    private void showGame(GameEngine engine) {
        cards.show(root, GAME);
        game.startMatch(engine);
    }

    private void showMenu() {
        game.stop();
        cards.show(root, MENU);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new HeadSoccerGUI().setVisible(true));
    }
}
