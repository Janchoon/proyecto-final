package presentation;

import domain.CharacterCatalog;
import domain.CharacterProfile;
import domain.GameEngine;
import domain.GameMode;
import domain.MatchType;
import domain.POOBSoccerException;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.util.function.Consumer;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.SwingConstants;

/** Menú: modalidad, tipo de partido, meta de goles y personaje de cada jugador. */
public class MenuPanel extends JPanel {

    private static final Color BG = new Color(18, 18, 20);

    private final Consumer<GameEngine> onStart;

    private final JComboBox<String> modeBox = new JComboBox<>(new String[] {
        "Jugador vs Jugador", "Jugador vs Máquina", "Máquina vs Máquina" });
    private final JComboBox<String> typeBox = new JComboBox<>();
    private final JComboBox<Integer> goalsBox = new JComboBox<>(new Integer[] { 3, 5, 7 });
    private final JComboBox<CharacterProfile> char1 = new JComboBox<>();
    private final JComboBox<CharacterProfile> char2 = new JComboBox<>();
    private final JLabel info1 = label("", 13, Color.LIGHT_GRAY);
    private final JLabel info2 = label("", 13, Color.LIGHT_GRAY);

    public MenuPanel(Consumer<GameEngine> onStart) {
        this.onStart = onStart;
        setBackground(BG);
        setPreferredSize(new Dimension(GameEngine.FIELD_WIDTH,
                GameEngine.FIELD_HEIGHT + ScoreBoardPanel.HEIGHT));
        setLayout(new GridBagLayout());

        for (CharacterProfile c : CharacterCatalog.all()) {
            char1.addItem(c);
            char2.addItem(c);
        }
        char2.setSelectedIndex(1);
        refreshTypes();
        Dimension boxSize = new Dimension(260, 28);
        modeBox.setPreferredSize(boxSize);
        typeBox.setPreferredSize(boxSize);
        goalsBox.setPreferredSize(boxSize);
        char1.setPreferredSize(boxSize);
        char2.setPreferredSize(boxSize);

        GridBagConstraints c = new GridBagConstraints();
        c.insets = new Insets(8, 10, 8, 10);
        c.fill = GridBagConstraints.HORIZONTAL;

        c.gridx = 0; c.gridy = 0; c.gridwidth = 2;
        add(label("POOBSoccer", 40, new Color(255, 200, 0)), c);
        c.gridy = 1;
        add(label("Partidos 1 contra 1 con poderes especiales", 15, Color.LIGHT_GRAY), c);

        c.gridwidth = 1;
        row(c, 2, "Modalidad", modeBox);
        row(c, 3, "Tipo de partido", typeBox);
        row(c, 4, "Meta de goles", goalsBox);
        row(c, 5, "Jugador 1", char1);
        c.gridx = 1; c.gridy = 6; add(info1, c);
        row(c, 7, "Jugador 2 / Máquina", char2);
        c.gridx = 1; c.gridy = 8; add(info2, c);

        JButton play = new JButton("Jugar");
        play.setFont(new Font("SansSerif", Font.BOLD, 20));
        c.gridx = 0; c.gridy = 9; c.gridwidth = 2;
        add(play, c);

        c.gridy = 10;
        add(label("<html><center>J1: A / D mover · W saltar · S patear · Q poder<br>"
                + "J2: ← / → mover · ↑ saltar · ↓ patear · Ctrl derecho poder<br>"
                + "P o Esc: pausa. En Jugador vs Máquina juegas con los controles del J1."
                + "</center></html>", 12, Color.GRAY), c);

        modeBox.addActionListener(e -> refreshTypes());
        typeBox.addActionListener(e -> goalsBox.setEnabled(typeBox.getSelectedIndex() == 1));
        char1.addActionListener(e -> refreshInfo());
        char2.addActionListener(e -> refreshInfo());
        play.addActionListener(e -> startMatch());
        refreshInfo();
    }

    private void row(GridBagConstraints c, int y, String text, java.awt.Component field) {
        c.gridy = y;
        c.gridx = 0;
        add(label(text, 15, Color.WHITE), c);
        c.gridx = 1;
        add(field, c);
    }

    private static JLabel label(String text, int size, Color color) {
        JLabel l = new JLabel(text, SwingConstants.CENTER);
        l.setForeground(color);
        l.setFont(new Font("SansSerif", size > 20 ? Font.BOLD : Font.PLAIN, size));
        return l;
    }

    /** Supervivencia solo existe en Jugador vs Máquina. */
    private void refreshTypes() {
        int previous = Math.max(0, typeBox.getSelectedIndex());
        boolean pvm = modeBox.getSelectedIndex() == 1;
        DefaultComboBoxModel<String> model = new DefaultComboBoxModel<>();
        model.addElement("Por tiempo (60 s)");
        model.addElement("Por goles");
        if (pvm) {
            model.addElement("Supervivencia (serie de partidos)");
        }
        typeBox.setModel(model);
        typeBox.setSelectedIndex(Math.min(previous, model.getSize() - 1));
        goalsBox.setEnabled(typeBox.getSelectedIndex() == 1);
    }

    private void refreshInfo() {
        info1.setText(describe((CharacterProfile) char1.getSelectedItem()));
        info2.setText(describe((CharacterProfile) char2.getSelectedItem()));
    }

    private static String describe(CharacterProfile p) {
        if (p == null) {
            return "";
        }
        return "Vel " + p.getSpeed() + " · Salto " + p.getJump() + " · Fuerza " + p.getStrength()
                + " · Poder: " + p.getPower().getLabel();
    }

    private void startMatch() {
        try {
            GameMode mode = GameMode.values()[modeBox.getSelectedIndex()];
            MatchType type = MatchType.values()[typeBox.getSelectedIndex()];
            int goals = (Integer) goalsBox.getSelectedItem();
            GameEngine engine = new GameEngine(mode, type, goals,
                    (CharacterProfile) char1.getSelectedItem(),
                    (CharacterProfile) char2.getSelectedItem());
            onStart.accept(engine);
        } catch (POOBSoccerException ex) {
            JOptionPane.showMessageDialog(this, ex.getMessage(), "POOBSoccer",
                    JOptionPane.WARNING_MESSAGE);
        }
    }
}
