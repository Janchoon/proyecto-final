package domain;

import java.util.Random;

/**
 * Máquina: persigue el balón, salta si está arriba, patea al tocarlo y usa el
 * poder en cuanto la barra se llena. El nivel (1 a 5) controla qué tan seguido
 * "piensa": a mayor nivel, reacciona más rápido.
 *
 * El perfil (AIProfile) decide su estilo:
 *  - Torpe: movimientos al azar.
 *  - Ofensiva: siempre va por el balón, nunca se queda a esperar.
 *  - Defensiva: se queda cerca de su arco y solo sale si el balón se acerca.
 *  - Experta: elige entre atacar, defender o equilibrar según el marcador y el tiempo.
 */
public class AIController implements Controller {

    private static final long serialVersionUID = 1L;

    private static final double BALANCED_GUARD = 330; // distancia a la que espera en guardia
    private static final double OFFENSIVE_GUARD = 1e9; // nunca espera
    private static final double DEFENSIVE_GUARD = 230; // solo sale si el balón está en su mitad
    private static final double DEFENSIVE_HOME_SHIFT = 90; // espera más cerca de su arco
    private static final int CLUMSY_HOLD_FRAMES = 18;

    private final AIProfile profile;
    private final int level;
    private final Random random = new Random();
    private PlayerInput last = new PlayerInput();

    private HeadSoccer match; // para el perfil Experta (marcador y tiempo)
    private int number; // 1 o 2: qué jugador controla
    private int clumsyFrames;

    /** Máquina Experta con el nivel indicado (comportamiento por defecto). */
    public AIController(int level) {
        this(AIProfile.EXPERTA, level);
    }

    public AIController(AIProfile profile, int level) {
        this.profile = (profile == null) ? AIProfile.EXPERTA : profile;
        this.level = Math.max(1, Math.min(5, level));
    }

    /** El motor le da el partido y su número de jugador (lo usa el perfil Experta). */
    public void setContext(HeadSoccer match, int number) {
        this.match = match;
        this.number = number;
    }

    public AIProfile getProfile() { return profile; }

    @Override
    public PlayerInput read(Player self, Player opponent, Ball ball) {
        if (profile == AIProfile.TORPE) {
            return readClumsy(self);
        }
        if (random.nextDouble() > 0.45 + 0.11 * level) {
            return last;                      // este cuadro no reacciona
        }
        switch (profile) {
            case OFENSIVA: last = chase(self, ball, OFFENSIVE_GUARD, false, 0); break;
            case DEFENSIVA: last = chase(self, ball, DEFENSIVE_GUARD, true, DEFENSIVE_HOME_SHIFT); break;
            default:        last = readExpert(self, ball); break;
        }
        return last;
    }

    /** Torpe: cada cierto tiempo escoge al azar qué hacer y lo mantiene un rato. */
    private PlayerInput readClumsy(Player self) {
        if (clumsyFrames > 0) {
            clumsyFrames--;
            return last;
        }
        clumsyFrames = CLUMSY_HOLD_FRAMES;
        PlayerInput in = new PlayerInput();
        int dir = random.nextInt(3); // 0 quieto, 1 izquierda, 2 derecha
        in.left = dir == 1;
        in.right = dir == 2;
        in.jump = random.nextInt(5) == 0;
        in.kick = random.nextBoolean();
        in.power = self.isPowerReady() && random.nextInt(4) == 0;
        last = in;
        return in;
    }

    /** Experta: ataca si va perdiendo o se acaba el tiempo, defiende si va ganando. */
    private PlayerInput readExpert(Player self, Ball ball) {
        double guard = BALANCED_GUARD;
        boolean retreat = true;
        double homeShift = 0;
        if (match != null && (number == 1 || number == 2)) {
            int mine = match.getScore(number);
            int theirs = match.getScore(number == 1 ? 2 : 1);
            boolean timed = match.getType() == MatchType.TIME;
            int secondsLeft = match.getRemainingSeconds();
            boolean lastSeconds = timed && !match.isGoldenGoal() && secondsLeft <= 15;
            if (match.isGoldenGoal() || mine < theirs) {
                guard = OFFENSIVE_GUARD; // necesita anotar
                retreat = false;
            } else if (mine > theirs && (lastSeconds || mine - theirs >= 2)) {
                guard = DEFENSIVE_GUARD; // protege la ventaja
                homeShift = DEFENSIVE_HOME_SHIFT;
            } else if (lastSeconds && mine == theirs) {
                guard = OFFENSIVE_GUARD; // empate sobre la hora: arriesga
                retreat = false;
            }
        }
        return chase(self, ball, guard, retreat, homeShift);
    }

    /**
     * Comportamiento base: persigue el balón, vuelve a guardia si está lejos
     * (a más de guardDistance de su posición inicial hacia el rival) o si hay
     * un tiro en camino a su arco (solo si retreat es true). Su puesto de espera es
     * su posición inicial desplazada homeShift px hacia su arco.
     */
    private PlayerInput chase(Player self, Ball ball, double guardDistance, boolean retreat, double homeShift) {
        PlayerInput in = new PlayerInput();
        double dx = ball.getPosX() - self.getPosX();
        // balón lejos, en la mitad rival: espera en su posición de guardia
        double ahead = (ball.getPosX() - self.getStartX()) * self.getFacing();
        boolean ballFar = ahead > guardDistance;
        // tiro en camino a su arco: vuelve a taparlo en lugar de perseguirlo
        boolean incoming = retreat && ball.getVelociX() * self.getFacing() < -3 && ahead > 0;
        if (ballFar || incoming) {
            // vuelve a su puesto (homeShift lo acerca a su propio arco)
            dx = (self.getStartX() - self.getFacing() * homeShift) - self.getPosX();
        }
        if (Math.abs(dx) > 12) {
            in.left = dx < 0;
            in.right = dx > 0;
        }
        boolean ballAbove = ball.getPosY() < self.getPosY() - 5;
        // balón a su espalda (hacia su propio arco): salta por encima para no empujarlo
        boolean ballBehind = dx * self.getFacing() < 0;
        if ((ballAbove && Math.abs(dx) < 80) || (ballBehind && Math.abs(dx) < 90)) {
            in.jump = true;
        }
        if (ballFar) {
            in.jump = false;
        }
        in.kick = true; // patea apenas lo alcance
        in.power = self.isPowerReady();
        return in;
    }
}