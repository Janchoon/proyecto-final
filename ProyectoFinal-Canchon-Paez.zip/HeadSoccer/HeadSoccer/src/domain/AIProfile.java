package domain;

/** Perfiles de las máquinas: Torpe, Ofensiva, Defensiva y Experta. */
public enum AIProfile {
    TORPE,
    OFENSIVA,
    DEFENSIVA,
    EXPERTA
}
