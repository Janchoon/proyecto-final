package domain;

/**
 * Ficha de un personaje: nombre, país (equipo), estadísticas de 1 a 5 y poder.
 * Sirve de molde para crear el Player que entra a la cancha.
 */
public class CharacterProfile implements java.io.Serializable {

    private static final long serialVersionUID = 1L;

    private final String name;
    private final String country;
    private final int speed;
    private final int jump;
    private final int strength;
    private final PowerType power;

    public CharacterProfile(String name, String country, int speed, int jump,
                            int strength, PowerType power) {
        this.name = name;
        this.country = country;
        this.speed = speed;
        this.jump = jump;
        this.strength = strength;
        this.power = power;
    }

    public Player createPlayer(int startX, int fieldWidth, int floorY, int facing)
            throws POOBSoccerException {
        return new Player(name, country, speed, jump, strength, power, startX, fieldWidth, floorY, facing);
    }

    /** Crea el jugador aplicando las estadísticas (mejoras) de su usuario. */
    public Player createPlayer(int startX, int fieldWidth, int floorY, int facing, PlayerStats stats) throws POOBSoccerException {
        return new Player(name, country, speed, jump, strength, power, startX, fieldWidth, floorY, facing, stats);
    }

    public String getName() { return name; }
    public String getCountry() { return country; }
    public int getSpeed() { return speed; }
    public int getJump() { return jump; }
    public int getStrength() { return strength; }
    public PowerType getPower() { return power; }

    /** Dos fichas son la misma si tienen el mismo nombre y país (importa al abrir partidas guardadas). */
    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (!(o instanceof CharacterProfile)) {
            return false;
        }
        CharacterProfile other = (CharacterProfile) o;
        return name.equals(other.name) && country.equals(other.country);
    }

    @Override
    public int hashCode() { return 31 * name.hashCode() + country.hashCode(); }

    @Override
    public String toString() { return name + " (" + country + ")"; }
}