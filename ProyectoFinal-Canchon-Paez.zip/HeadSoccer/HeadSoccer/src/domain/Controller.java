package domain;

public interface Controller extends java.io.Serializable {
    PlayerInput read(Player self, Player opponent, Ball ball);
}