package domain;

import java.io.IOException;
import java.util.logging.FileHandler;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.logging.SimpleFormatter;

/**
 * Registro de errores para los programadores. Escribe en doposoccer-errors.log
 * (carpeta desde la que se ejecuta el juego). Si no se puede escribir el
 * archivo, el error sale por la consola y el juego sigue funcionando.
 */
public final class ErrorLog {

    public static final String FILE_NAME = "doposoccer-errors.log";
    private static final Logger LOGGER = Logger.getLogger("DOPOSoccer");

    static {
        LOGGER.setUseParentHandlers(false);
        try {
            FileHandler handler = new FileHandler(FILE_NAME, true);
            handler.setFormatter(new SimpleFormatter());
            LOGGER.addHandler(handler);
        } catch (IOException | SecurityException e) {
            LOGGER.setUseParentHandlers(true);   // consola como respaldo
        }
    }

    private ErrorLog() { }

    public static void log(String message, Throwable cause) {
        LOGGER.log(Level.SEVERE, message, cause);
    }
}
