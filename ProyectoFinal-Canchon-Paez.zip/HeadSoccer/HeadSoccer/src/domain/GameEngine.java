package domain;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

/**
 * Motor del partido: junta las reglas (HeadSoccer) con la física (Ball, Player,
 * Goal) y los controladores (humano o máquina). La GUI solo llama a update()
 * en cada cuadro y dibuja lo que el motor expone.
 *
 * En supervivencia se juega una serie de partidos seguidos contra la máquina:
 * si el jugador 1 gana, empieza otro partido contra un rival más difícil; la
 * serie termina cuando pierde.
 *
 * Reglas de combate: la patada al rival quita vida (10 × multiplicadorKick) y
 * un tiro de poder solo hace daño y efecto si golpea al rival. Con la vida en
 * cero el jugador queda aturdido 3 s y luego recupera su vida máxima.
 */
public class GameEngine implements java.io.Serializable {

    private static final long serialVersionUID = 1L;

    public static final int FIELD_WIDTH = 900;
    public static final int FIELD_HEIGHT = 500;
    public static final int FLOOR_Y = 440;
    public static final int GOAL_WIDTH = 60;
    public static final int GOAL_HEIGHT = 150;
    public static final int BALL_RADIUS = 16;

    private static final int PLAYER_MARGIN = 200;
    private static final long EVENT_MILLIS = 1500;
    private static final long SHOT_MAX_MILLIS = 2500; // un tiro de poder sin dar en nada se descarta
    private static final int ILLUSION_FAKE_BALLS = 7; // 7 falsos + el real = 8 balones

    private final GameMode mode;
    private final MatchType type;
    private final int goalTarget;
    private final int minutes;
    private final CharacterProfile profile1;
    private CharacterProfile profile2;
    private final PlayerStats stats1;
    private final PlayerStats stats2;
    private final AIProfile aiProfile1;
    private final AIProfile aiProfile2;

    private HeadSoccer match;
    private Player player1;
    private Player player2;
    private Ball ball;
    private Goal goal1;
    private Goal goal2;

    private final HumanController human1;
    private final HumanController human2;
    private Controller controller1;
    private Controller controller2;

    private int survivalRound = 1;
    private boolean seriesOver;

    private String eventText = "";
    private long eventMillis;
    private int lastKicker;
    private long sinceKick = Long.MAX_VALUE / 2;

    // tiro de poder en vuelo (solo hace efecto si golpea al rival)
    private int shotOwner; // 0 = ninguno
    private PowerType shotType;
    private long shotMillis;

    // Ilusión: balones falsos que ve el rival (idénticos al real)
    private final List<Ball> fakeBalls = new ArrayList<>();
    private int illusionVictim;
    private final Random random = new Random();

    public GameEngine(GameMode mode, MatchType type, int goalTarget, CharacterProfile profile1, CharacterProfile profile2) throws POOBSoccerException {
        this(mode, type, goalTarget, 1, profile1, profile2, null, null, AIProfile.EXPERTA, AIProfile.EXPERTA);
    }

    /**
     * Partido completo. goalTarget se usa en partidos por goles y minutes en los
     * de tiempo. stats1/stats2 son las mejoras de cada usuario (null = todas en 1);
     * aiProfile1/aiProfile2 solo importan para los jugadores que sean máquina.
     */
    public GameEngine(GameMode mode, MatchType type, int goalTarget, int minutes,
                      CharacterProfile profile1, CharacterProfile profile2,
                      PlayerStats stats1, PlayerStats stats2,
                      AIProfile aiProfile1, AIProfile aiProfile2)
            throws POOBSoccerException {
        if (mode == null || type == null || profile1 == null || profile2 == null) {
            throw new POOBSoccerException(POOBSoccerException.INVALID_SETUP);
        }
        this.mode = mode;
        this.type = type;
        this.goalTarget = goalTarget;
        this.minutes = minutes;
        this.profile1 = profile1;
        this.profile2 = profile2;
        this.stats1 = (stats1 == null) ? new PlayerStats() : new PlayerStats(stats1);
        this.stats2 = (stats2 == null) ? new PlayerStats() : new PlayerStats(stats2);
        this.aiProfile1 = (aiProfile1 == null) ? AIProfile.EXPERTA : aiProfile1;
        this.aiProfile2 = (aiProfile2 == null) ? AIProfile.EXPERTA : aiProfile2;
        this.match = newMatch(); // valida meta de goles y supervivencia
        this.human1 = (mode == GameMode.MVM) ? null : new HumanController();
        this.human2 = (mode == GameMode.PVP) ? new HumanController() : null;
        buildRound();
    }

    //Contruccion de cada ronda

    private HeadSoccer newMatch() throws POOBSoccerException {
        switch (type) {
            case TIME:  return HeadSoccer.byTime(mode, minutes);
            case GOALS: return HeadSoccer.byGoals(mode, goalTarget);
            default:    return HeadSoccer.survival(mode);
        }
    }

    private void buildRound() throws POOBSoccerException {
        player1 = profile1.createPlayer(PLAYER_MARGIN, FIELD_WIDTH, FLOOR_Y, 1, stats1);
        player2 = profile2.createPlayer(FIELD_WIDTH - PLAYER_MARGIN, FIELD_WIDTH, FLOOR_Y, -1, stats2);
        ball = new Ball(FIELD_WIDTH / 2, 120, BALL_RADIUS, FIELD_WIDTH, FLOOR_Y);
        goal1 = new Goal(1, 0, FLOOR_Y - GOAL_HEIGHT, GOAL_WIDTH, GOAL_HEIGHT);
        goal2 = new Goal(2, FIELD_WIDTH - GOAL_WIDTH, FLOOR_Y - GOAL_HEIGHT, GOAL_WIDTH, GOAL_HEIGHT);
        controller1 = (human1 != null) ? human1 : newAI(aiProfile1, 1);
        controller2 = (human2 != null) ? human2 : newAI(aiProfile2, 2);
        lastKicker = 0;
        endShot();
    }

    private AIController newAI(AIProfile profile, int number) {
        AIController ai = new AIController(profile, aiLevel());
        ai.setContext(match, number);
        return ai;
    }

    private int aiLevel() {
        return (type == MatchType.SURVIVAL) ? Math.min(5, 1 + survivalRound) : 3;
    }

    //Control del partido

    public void start() throws POOBSoccerException {match.start();}

    public void pause() {
        if (match.getState() == MatchState.RUNNING) {
            try { match.pause(); } catch (POOBSoccerException e) { /* estado ya validado */ }
        }
    }

    public void resume() {
        if (match.getState() == MatchState.PAUSED) {
            try { match.resume(); } catch (POOBSoccerException e) { /* estado ya validado */ }
        }
    }

    public void togglePause() {
        if (isPaused()) resume(); else pause();
    }

    /** Avanza un cuadro de juego. No hace nada si el partido no está corriendo. */
    public void update(long elapsedMillis) throws POOBSoccerException{
        if (match.getState() != MatchState.RUNNING) {
            return;
        }
        if (eventMillis > 0) {
            eventMillis = Math.max(0, eventMillis - elapsedMillis);
        }
        if (sinceKick < Long.MAX_VALUE / 4) {
            sinceKick += elapsedMillis;
        }

        act(1, player1, player2, controller1);
        act(2, player2, player1, controller2);

        player1.update(elapsedMillis);
        player2.update(elapsedMillis);
        ball.update();
        updateShot(elapsedMillis);
        updateFakeBalls();

        bounceOnCrossbar(goal1);
        bounceOnCrossbar(goal2);
        collide(1, player1);
        collide(2, player2);

        checkGoals();
        match.tick(elapsedMillis);
        checkSeries();
    }

    //Pasos de cada cuadro

    private void act(int index, Player self, Player opponent, Controller controller) {
        PlayerInput in = controller.read(self, opponent, ball);
        if (in.left && !in.right) {
            self.moveLeft();
        } else if (in.right && !in.left) {
            self.moveRight();
        } else {
            self.stopMoving();
        }
        if (in.jump) {
            self.jump();
        }
        if (in.power) {
            self.usePower();
        }
        if (in.kick) {
            if (self.kick(ball)) {
                lastKicker = index;
                sinceKick = 0;
                if (self.consumePowerFired()) {          // sale el tiro de poder
                    shotOwner = index;
                    shotType = self.getPower();
                    shotMillis = 0;
                    setEvent("¡" + shotType.getLabel() + "!");
                } else {
                    endShot();                           // un balonazo normal cancela el tiro
                }
            } else {
                boolean wasUp = !opponent.isKnockedOut();
                if (self.kickPlayer(opponent) && wasUp && opponent.isKnockedOut()) {
                    setEvent("¡" + opponent.getName() + " aturdido!");
                }
            }
        }
    }

    //Tiros de poder

    /** El tiro golpeó al rival: daño (DañoTiro × multiplicadorKick) y efecto. */
    private void powerShotHit(Player victim, Player owner) {
        PowerType power = shotType;
        double damage = power.getDamage() * owner.getKickMultiplier();
        boolean wasUp = !victim.isKnockedOut();
        victim.takeDamage(damage);
        victim.applyEffect(power); // reemplaza cualquier efecto anterior
        if (power == PowerType.ILLUSION) {
            spawnFakeBalls(victim == player1 ? 1 : 2);
        }
        String text = "¡" + power.getLabel() + "! " + victim.getName() + " queda "
                + power.getEffectLabel().toLowerCase();
        if (damage > 0) {
            text += " (-" + Math.round(damage) + ")";
        }
        if (wasUp && victim.isKnockedOut()) {
            text += " y aturdido";
        }
        setEvent(text);
        endShot();
    }

    private void updateShot(long elapsedMillis) {
        if (shotOwner != 0) {
            shotMillis += elapsedMillis;
            if (shotMillis >= SHOT_MAX_MILLIS) {
                endShot();
            }
        }
    }

    /** El tiro termina (golpeó, entró a un arco, se agotó o hubo saque): el balón vuelve a la normalidad. */
    private void endShot() {
        shotOwner = 0;
        shotType = null;
        shotMillis = 0;
        if (ball != null) {
            ball.setStraight(false);
        }
    }

    private void spawnFakeBalls(int victimNumber) {
        fakeBalls.clear();
        illusionVictim = victimNumber;
        for (int i = 0; i < ILLUSION_FAKE_BALLS; i++) {
            Ball fake = new Ball((int) ball.getPosX(), (int) ball.getPosY(), BALL_RADIUS,
                    FIELD_WIDTH, FLOOR_Y);
            fake.setVelocity((random.nextDouble() - 0.5) * 16, -2 - random.nextDouble() * 9);
            fakeBalls.add(fake);
        }
    }

    /** Los balones falsos viven mientras dure el efecto Ilusión sobre el rival. */
    private void updateFakeBalls() {
        if (fakeBalls.isEmpty()) {
            return;
        }
        if (getPlayer(illusionVictim).getEffect() != PowerType.ILLUSION) {
            fakeBalls.clear();
            return;
        }
        for (Ball fake : fakeBalls) {
            fake.update();
        }
    }

    /** El balón rebota arriba de cada arco (el travesaño). */
    private void bounceOnCrossbar(Goal goal) {
        double r = ball.getRadius();
        double top = goal.getPosY();
        boolean overGoal = ball.getPosX() + r > goal.getPosX()
                && ball.getPosX() - r < goal.getPosX() + goal.getWidth();
        double vy = ball.getVelociY();
        boolean cameFromAbove = ball.getPosY() - vy + r <= top + 1;
        if (overGoal && vy > 0 && ball.getPosY() + r >= top && cameFromAbove) {
            double newVy = -vy * Ball.BOUNCE_DAMPING;
            double vx = ball.getVelociX();
            if (Math.abs(newVy) < Ball.REST_THRESHOLD) {
                newVy = 0;
                vx += (goal.getOwner() == 1) ? 1.5 : -1.5;   // no se queda sobre el arco
            }
            ball.setPosition(ball.getPosX(), top - r);
            ball.setVelocity(vx, newVy);
        }
    }

    /** Choque del balón con el cuerpo de un jugador; si es un tiro de poder del rival, hace daño y efecto. */
    private void collide(int index, Player pl) {
        if (lastKicker == index && sinceKick < 200) {
            return;                         // no choca con su propia patada
        }
        double w = pl.getWidth();
        double h = pl.getHeight();
        double left = pl.getPosX() - w / 2.0;
        double top = pl.getPosY();
        double bx = ball.getPosX();
        double by = ball.getPosY();
        double r = ball.getRadius();
        double nx = Math.max(left, Math.min(bx, left + w));
        double ny = Math.max(top, Math.min(by, top + h));
        double dx = bx - nx;
        double dy = by - ny;
        double dist = Math.hypot(dx, dy);
        if (dist >= r) {
            return;
        }
        double ux;
        double uy;
        if (dist == 0) {                    // centro dentro del cuerpo: sale por arriba
            ux = 0;
            uy = -1;
            ball.setPosition(bx, top - r);
        } else {
            ux = dx / dist;
            uy = dy / dist;
            ball.setPosition(nx + ux * r, ny + uy * r);
        }
        double vx = ball.getVelociX();
        double vy = ball.getVelociY();
        double vn = vx * ux + vy * uy;
        if (vn < 0) {
            vx -= 1.6 * vn * ux;
            vy -= 1.6 * vn * uy;
        }
        vx += pl.getVeloX() * 0.5;
        ball.setVelocity(vx, vy);

        int other = (index == 1) ? 2 : 1;
        if (shotOwner == other) { // el tiro de poder del rival me golpeó
            powerShotHit(pl, getPlayer(other));
        }
    }

    private void checkGoals() throws POOBSoccerException{
        int owner = 0; // dueño del arco donde entró el balón
        if (goal1.isGoal(ball)) {
            owner = 1;
        } else if (goal2.isGoal(ball)) {
            owner = 2;
        }
        if (owner == 0) {
            return;
        }
        int scorer = (owner == 1) ? 2 : 1;
        boolean ownGoal = (lastKicker == owner);
        match.ballEnteredGoal(owner);
        Player scorerPlayer = (scorer == 1) ? player1 : player2;
        Player conceded = (owner == 1) ? player1 : player2;
        conceded.addPowerCharge(Player.POWER_MAX / 4);   // recibir un gol da un cuarto de barra
        setEvent(ownGoal ? "¡Autogol! Punto para " + scorerPlayer.getName()
                         : "¡GOL de " + scorerPlayer.getName() + "!");
        if (!match.isFinished()) {
            restartPositions();
        }
    }

    /** Después de un gol: todos a su lugar y el balón cae desde el centro. */
    private void restartPositions() {
        player1.resetPosition();
        player2.resetPosition();
        ball.reset();
        lastKicker = 0;
        endShot();
        fakeBalls.clear();
    }

    /** Supervivencia: gana el jugador 1 → siguiente rival; si pierde, termina la serie. */
    private void checkSeries() throws POOBSoccerException{
        if (type != MatchType.SURVIVAL || !match.isFinished() || seriesOver) {
            return;
        }
        if (match.getWinner() != 1) {
            seriesOver = true;
            return;
        }
        List<CharacterProfile> all = CharacterCatalog.all();
        int next = (all.indexOf(profile2) + 1) % all.size();
        profile2 = all.get(next);
        survivalRound++;
        match = newMatch();
        match.start();
        buildRound();
        setEvent("Ronda " + survivalRound + ": " + profile2.getName() + " (" + profile2.getCountry() + ")");
    }

    private void setEvent(String text) {
        eventText = text;
        eventMillis = EVENT_MILLIS;
    }

    //Consultas GUI

    /** El partido (o, en supervivencia, toda la serie) terminó. */
    public boolean isOver() {
        return match.isFinished() && (type != MatchType.SURVIVAL || seriesOver);
    }

    public boolean isPaused() { return match.getState() == MatchState.PAUSED; }

    /** Texto del último evento (gol, poder, aturdimiento); vacío si ya pasó. */
    public String getEventText() { return eventMillis > 0 ? eventText : ""; }

    public Player getPlayer(int number) { return (number == 1) ? player1 : player2; }
    public Goal getGoal(int number) { return (number == 1) ? goal1 : goal2; }
    public Ball getBall() { return ball; }
    /** Balones falsos de la Ilusión (vacío si no hay efecto). Se dibujan igual que el real. */
    public List<Ball> getFakeBalls() { return java.util.Collections.unmodifiableList(fakeBalls); }
    /** Tipo del tiro de poder en vuelo (null si no hay). */
    public PowerType getShotType() { return shotType; }
    public AIProfile getAIProfile(int number) { return (number == 1) ? aiProfile1 : aiProfile2; }
    public PlayerStats getStats(int number) { return (number == 1) ? stats1 : stats2; }
    public int getMinutes() { return minutes; }

    /**
     * Puntos que gana el jugador al terminar: 100 el ganador y 25 el perdedor.
     * En supervivencia: 100 por cada ronda ganada y 25 por la serie. Solo suman
     * los jugadores humanos; antes de terminar vale 0.
     */
    public int getPointsEarned(int number) {
        if (!isOver() || getHumanController(number) == null) {
            return 0;
        }
        if (type == MatchType.SURVIVAL) {
            return PlayerProgress.WIN_POINTS * (survivalRound - 1) + PlayerProgress.LOSS_POINTS;
        }
        return (match.getWinner() == number) ? PlayerProgress.WIN_POINTS : PlayerProgress.LOSS_POINTS;
    }
    public HeadSoccer getMatch() { return match; }
    public GameMode getMode() { return mode; }
    public MatchType getType() { return type; }
    public int getSurvivalRound() { return survivalRound; }
    public int getWinner() { return match.getWinner(); }

    /** Controlador humano del jugador (null si lo maneja la máquina). */
    public HumanController getHumanController(int number) {
        return (number == 1) ? human1 : human2;
    }
}
