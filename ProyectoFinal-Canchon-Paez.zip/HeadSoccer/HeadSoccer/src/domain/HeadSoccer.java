package domain;

public class HeadSoccer implements java.io.Serializable {

    private static final long serialVersionUID = 1L;

    public static final int MATCH_SECONDS = 60;
    public static final int SURVIVAL_BALLS = 3;
    public static final int MAX_MINUTES = 60;
    public static final int MAX_GOALS = 99;

    private final GameMode mode;
    private final MatchType type;
    private final int goalTarget;      // solo aplica a GOALS
    private final int minutes;         // solo aplica a TIME

    private int scorePlayer1;
    private int scorePlayer2;
    private int ballsPlayer1;          // solo aplica a SURVIVAL
    private int ballsPlayer2;
    private long remainingMillis;      // solo aplica a TIME
    private boolean goldenGoal;
    private MatchState state;
    private int winner;

    private HeadSoccer(GameMode mode, MatchType type, int goalTarget, int minutes) {
        this.mode = mode;
        this.minutes = minutes;
        this.type = type;
        this.goalTarget = goalTarget;
        this.scorePlayer1 = 0;
        this.scorePlayer2 = 0;
        this.ballsPlayer1 = (type == MatchType.SURVIVAL) ? SURVIVAL_BALLS : 0;
        this.ballsPlayer2 = (type == MatchType.SURVIVAL) ? SURVIVAL_BALLS : 0;
        this.remainingMillis = (type == MatchType.TIME) ? minutes * 60000L : 0;
        this.goldenGoal = false;
        this.state = MatchState.NOT_STARTED;
        this.winner = 0;
    }

    /** Partido por tiempo de 1 minuto (MATCH_SECONDS). */
    public static HeadSoccer byTime(GameMode mode) {
        return new HeadSoccer(mode, MatchType.TIME, 0, MATCH_SECONDS / 60);
    }

    /** Partido por tiempo de la duración elegida (1 a 60 minutos). */
    public static HeadSoccer byTime(GameMode mode, int minutes) throws POOBSoccerException {
        if (minutes < 1 || minutes > MAX_MINUTES) {
            throw new POOBSoccerException(POOBSoccerException.INVALID_MINUTES);
        }
        return new HeadSoccer(mode, MatchType.TIME, 0, minutes);
    }

    public static HeadSoccer byGoals(GameMode mode, int target) throws POOBSoccerException {
        if (target < 1 || target > MAX_GOALS) {
            throw new POOBSoccerException(POOBSoccerException.INVALID_GOAL_TARGET);
        }
        return new HeadSoccer(mode, MatchType.GOALS, target, 0);
    }

    public static HeadSoccer survival(GameMode mode) throws POOBSoccerException {
        if (mode != GameMode.PVM) {
            throw new POOBSoccerException(POOBSoccerException.SURVIVAL_ONLY_PVM);
        }
        return new HeadSoccer(mode, MatchType.SURVIVAL, 0, 0);
    }

    // Control del partido 

    public void start() throws POOBSoccerException {
        if (state != MatchState.NOT_STARTED) {
            throw new POOBSoccerException(POOBSoccerException.INVALID_STATE);
        }
        state = MatchState.RUNNING;
    }

    public void pause() throws POOBSoccerException {
        if (state != MatchState.RUNNING) {
            throw new POOBSoccerException(POOBSoccerException.INVALID_STATE);
        }
        state = MatchState.PAUSED;
    }

    public void resume() throws POOBSoccerException {
        if (state != MatchState.PAUSED) {
            throw new POOBSoccerException(POOBSoccerException.INVALID_STATE);
        }
        state = MatchState.RUNNING;
    }

    public void tick(long elapsedMillis) {
        if (state != MatchState.RUNNING || type != MatchType.TIME || goldenGoal) {
            return;
        }
        remainingMillis -= elapsedMillis;
        if (remainingMillis <= 0) {
            remainingMillis = 0;
            if (scorePlayer1 == scorePlayer2) {
                goldenGoal = true;          // el primero que anote gana
            } else {
                finish(scorePlayer1 > scorePlayer2 ? 1 : 2);
            }
        }
    }

    public void ballEnteredGoal(int goalOwner) throws POOBSoccerException {
        if (goalOwner != 1 && goalOwner != 2) {
            throw new POOBSoccerException(POOBSoccerException.INVALID_PLAYER);
        }
        if (state != MatchState.RUNNING) {
            return;
        }
        int scorer = (goalOwner == 1) ? 2 : 1;

        if (scorer == 1) {
            scorePlayer1++;
        } else {
            scorePlayer2++;
        }

        switch (type) {
            case TIME:
                if (goldenGoal) {
                    finish(scorer);
                }
                break;
            case GOALS:
                if (getScore(scorer) >= goalTarget) {
                    finish(scorer);
                }
                break;
            case SURVIVAL:
                loseBall(goalOwner);
                if (getBalls(goalOwner) == 0) {
                    finish(scorer);
                }
                break;
        }
    }

    //Internos

    private void finish(int winningPlayer) {
        winner = winningPlayer;
        state = MatchState.FINISHED;
    }

    private void loseBall(int player) {
        if (player == 1) {
            ballsPlayer1--;
        } else {
            ballsPlayer2--;
        }
    }

    //Consultas

    public int getScore(int player) {
        return (player == 1) ? scorePlayer1 : scorePlayer2;
    }

    public int getBalls(int player) {
        return (player == 1) ? ballsPlayer1 : ballsPlayer2;
    }

    public int getRemainingSeconds() {
        return (int) Math.ceil(remainingMillis / 1000.0);
    }

    public GameMode getMode() { return mode; }
    public MatchType getType() { return type; }
    public int getGoalTarget() { return goalTarget; }
    public int getMinutes() { return minutes; }
    public MatchState getState() { return state; }
    public boolean isGoldenGoal() { return goldenGoal; }
    public boolean isFinished() { return state == MatchState.FINISHED; }
    public int getWinner() { return winner; }
}
