package domain;

/** Controlador que se alimenta desde el teclado (la GUI cambia las banderas). */
public class HumanController implements Controller {

    private static final long serialVersionUID = 1L;

    private boolean left;
    private boolean right;
    private boolean jump;
    private boolean kick;
    private boolean powerRequested;

    public void setLeft(boolean pressed){left = pressed;}
    public void setRight(boolean pressed){right = pressed;}
    public void setJump(boolean pressed){jump = pressed;}
    public void setKick(boolean pressed){kick = pressed;}
    public void requestPower(){powerRequested = true;}

    @Override
    public PlayerInput read(Player self, Player opponent, Ball ball) {
        PlayerInput in = new PlayerInput();
        in.left = left;
        in.right = right;
        in.jump = jump;
        in.kick = kick;
        in.power = powerRequested;
        powerRequested = false;
        return in;
    }
}