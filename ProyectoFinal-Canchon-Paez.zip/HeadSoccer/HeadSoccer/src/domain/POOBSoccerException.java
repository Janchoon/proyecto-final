package domain;

/**
 * Excepción del dominio de POOBSoccer.
 */
public class POOBSoccerException extends Exception {

    public static final String SURVIVAL_ONLY_PVM = "El modo supervivencia solo está disponible en Jugador vs Máquina.";
    public static final String INVALID_GOAL_TARGET = "La meta de goles debe estar entre 1 y 99.";
    public static final String INVALID_MINUTES = "Los minutos del partido deben estar entre 1 y 60.";
    public static final String INVALID_PLAYER = "El jugador debe ser 1 o 2.";
    public static final String INVALID_STAT = "Las estadísticas base del personaje deben estar entre 1 y 5.";
    public static final String INVALID_STAT_LEVEL = "Las estadísticas del jugador deben estar entre 1 y 10.";
    public static final String STAT_AT_MAX = "Esa estadística ya está en el máximo (10).";
    public static final String INVALID_USER_NAME = "El nombre de usuario no puede estar vacío.";
    public static final String INVALID_STATE = "Esa acción no es válida en el estado actual del partido.";
    public static final String INVALID_SETUP = "La configuración del partido está incompleta o no existe el personaje.";

    public POOBSoccerException(String message) {
        super(message);
    }

    public POOBSoccerException(String message, Throwable cause) {
        super(message, cause);
        ErrorLog.log(message, this);
    }
}