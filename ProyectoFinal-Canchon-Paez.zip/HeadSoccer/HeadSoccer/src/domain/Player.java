package domain;

import domain.PowerType;

/**
 * Personaje controlado por un jugador (humano o máquina).
 * Es un rectángulo: posX es el centro horizontal y posY el borde superior del
 * cuerpo. Coordenadas de pantalla: Y crece hacia abajo.
 * Las estadísticas base del personaje (velocidad, salto, fuerza) van de 1 a 5;
 * las del usuario (PlayerStats: speed, kick, jump, survival, de 1 a 10) las mejoran.
 * La lógica avanza por cuadros, igual que Ball.
 */
public class Player implements java.io.Serializable {

    private static final long serialVersionUID = 1L;

    public static final int WIDTH = 40;
    public static final int HEIGHT = 70;
    public static final double POWER_MAX = 100;
    public static final long POWER_FULL_MILLIS = 10000; // tiempo en llenar la barra
    public static final long STUN_MILLIS = 3000; // aturdimiento
    public static final long KICK_COOLDOWN_MILLIS = 300;
    public static final int KICK_REACH = 15; // alcance extra de la patada
    public static final double SHRINK_SCALE = 0.5;
    public static final double KICK_DAMAGE = 10; // daño base de una patada al rival
    public static final long PLAYER_KICK_COOLDOWN_MILLIS = 600;
    public static final double PUSH_SPEED = 9; // empuje del Aura Azul (px por cuadro)
    public static final double TORNADO_LAUNCH = 16; // impulso hacia arriba del Tornado

    private final String name;
    private final String country;
    private final int speed;
    private final int jump;
    private final int strength;
    private final PowerType power;
    private final int facing;       // +1 mira a la derecha, -1 a la izquierda
    private final PlayerStats stats;
    private final double maxLife;
    private double life;

    private final int fieldWidth;
    private final int floorY;
    private final double startX;

    private double posX; // centro horizontal del cuerpo
    private double posY; // borde superior del cuerpo
    private double veloY;
    private int moveDir; // -1 izquierda, 0 quieto, +1 derecha

    private double powerCharge; // 0 a POWER_MAX
    private boolean powerArmed; // se pidió usar el poder; sale al golpear el balón
    private boolean powerFired; // el poder se disparó en la última patada
    private long stunMillis;
    private long kickCooldown;

    private PowerType effect; // efecto que sufre (null = ninguno)
    private long effectMillis;

    public Player(String name, String country, int speed, int jump, int strength, int startX, int fieldWidth, int floorY, int facing)
            throws POOBSoccerException {
        this(name, country, speed, jump, strength, null, startX, fieldWidth, floorY, facing);
    }

    public Player(String name, String country, int speed, int jump, int strength, PowerType power, int startX, int fieldWidth, int floorY, int facing)
            throws POOBSoccerException {
        this(name, country, speed, jump, strength, power, startX, fieldWidth, floorY, facing, new PlayerStats());
    }

    public Player(String name, String country, int speed, int jump, int strength,
                 PowerType power, int startX, int fieldWidth, int floorY, int facing,
                 PlayerStats stats)
            throws POOBSoccerException {
        validateStat(speed);
        validateStat(jump);
        validateStat(strength);
        this.name = name;
        this.country = country;
        this.speed = speed;
        this.jump = jump;
        this.strength = strength;
        this.power = power;
        this.stats = new PlayerStats(stats == null ? new PlayerStats() : stats);
        this.maxLife = this.stats.getMaxLife();
        this.life = maxLife;
        this.facing = (facing >= 0) ? 1 : -1;
        this.fieldWidth = fieldWidth;
        this.floorY = floorY;
        this.startX = startX;
        resetPosition();
        this.powerCharge = 0;
    }

    private static void validateStat(int value) throws POOBSoccerException {
        if (value < 1 || value > 5) {
            throw new POOBSoccerException(POOBSoccerException.INVALID_STAT);
        }
    }

    //Acciones del jugador 

    public void moveLeft(){
        if (!isStunned() && effect != PowerType.PUSH) moveDir = (effect == PowerType.CONFUSION) ? 1 : -1;
    }
    public void moveRight(){
        if (!isStunned() && effect != PowerType.PUSH) moveDir = (effect == PowerType.CONFUSION) ? -1 : 1;
    }
    public void stopMoving() { moveDir = 0; }

    public void jump() {
        if (!isStunned() && effect != PowerType.LIGHTNING && isOnGround()) {
            veloY = -(10 + 1.5 * jump) * stats.getJumpMultiplier();
        }
    }
    
    /**
     * Patea el balón si está al alcance. Devuelve true si lo golpeó.
     * Si el poder estaba activo (aura), el golpe lanza el tiro de poder: sale
     * recto y rápido, la barra ya se había vaciado al activarlo y el aura desaparece.
     * La patada solo impulsa el balón; el Kick no cambia su fuerza.
     */
    public boolean kick(Ball ball) {
        if (isStunned() || kickCooldown > 0 ||!isTouching(ball)) {
            return false;
        }
        kickCooldown = KICK_COOLDOWN_MILLIS;
        if (powerArmed) {
            powerArmed = false;
            powerFired = true;
            ball.setStraight(true);
            ball.setVelocity(facing * power.getShotSpeed(), 0);
            if (power == PowerType.TORNADO) {                 // a ras de suelo
                ball.setPosition(ball.getPosX(), floorY - ball.getRadius());
            }
        } else {
            double force = 3 + 1.5 * strength;
            ball.setStraight(false);
            ball.setVelocity(facing * force, -force * 0.8);
        }
        return true;
    }

    /**
     * Patada al rival: solo hace daño si está dentro del alcance del pie
     * (delante del jugador). Daño = 10 × multiplicadorKick.
     */
    public boolean kickPlayer(Player rival) {
        if (isStunned() || kickCooldown > 0 || rival == null || rival.isKnockedOut() || !canReach(rival)) {
            return false;
        }
        kickCooldown = PLAYER_KICK_COOLDOWN_MILLIS;
        rival.takeDamage(KICK_DAMAGE * getKickMultiplier());
        return true;
    }

    private boolean canReach(Player r) {
        double myLeft = posX - getWidth() / 2.0;
        double myRight = myLeft + getWidth();
        double rLeft = r.posX - r.getWidth() / 2.0;
        double rRight = rLeft + r.getWidth();
        boolean inFront = (facing > 0)
                ? (rLeft <= myRight + KICK_REACH && rRight >= myLeft)
                : (rRight >= myLeft - KICK_REACH && rLeft <= myRight);
        boolean sameHeight = r.posY < posY + getHeight() && r.posY + r.getHeight() > posY;
        return inFront && sameHeight;
    }

    /** Resta vida (nunca baja de 0). Al llegar a 0 el jugador queda aturdido. */
    public void takeDamage(double amount) {
        if (amount <= 0 || life <= 0) {
            return;
        }
        life = Math.max(0, life - amount);
        if (life == 0) {
            stun();
        }
    }

    /** Pide usar el poder: barra llena y sin otro poder activo (aura). */
    public boolean usePower() {
        if (power != null && isPowerReady() && !powerArmed && !isStunned()) {
            powerArmed = true;
            powerCharge = 0; // la barra se vacía y ya empieza a recargarse
            return true;
        }
        return false;
    }

    /** Aturde al jugador: no puede moverse, saltar ni patear 3 segundos. */
    public void stun() {
        stunMillis = STUN_MILLIS;
        moveDir = 0;
    }

    public void applyEffect(PowerType type){
        if (type == null){return;}
        boolean grounded = isOnGround();
        effect = type;
        effectMillis = type.getDurationMillis();
        if (type == PowerType.FREEZE || type == PowerType.PUSH || type == PowerType.TORNADO){
            moveDir = 0;
        }
        snapToFloor(grounded);
        if (type == PowerType.TORNADO) {
            veloY = -TORNADO_LAUNCH; // sale volando
        }
    }

    /** Suma carga a la barra de poder (un gol recibido da un cuarto). */
    public void addPowerCharge(double amount) {
        powerCharge = Math.max(0, Math.min(POWER_MAX, powerCharge + amount));
    }
    //Actualización por cuadro

    public void update(long elapsedMillis) {
        if (stunMillis > 0) {
            stunMillis = Math.max(0, stunMillis - elapsedMillis);
            if (stunMillis == 0 && life <= 0) {
                life = maxLife; // termina el aturdimiento: vida completa
            }
        }
        if (kickCooldown > 0) {
            kickCooldown = Math.max(0, kickCooldown - elapsedMillis);
        }
        if (effect != null) {
            effectMillis -= elapsedMillis;
            if (effectMillis <= 0) {
                boolean grounded = isOnGround();
                effect = null;
                effectMillis = 0;
                snapToFloor(grounded);
            }
        }
        if (isStunned()) {
            moveDir = 0;
        }
        powerCharge = Math.min(POWER_MAX, powerCharge + POWER_MAX * elapsedMillis / POWER_FULL_MILLIS);

        posX += moveDir * moveSpeed();
        if (effect == PowerType.PUSH) {
            posX += -facing * PUSH_SPEED; // lanzado hacia su propio arco
        }
        double half = getWidth() / 2.0;
        posX = Math.max(half, Math.min(fieldWidth - half, posX));

        veloY += Ball.GRAVITY;
        posY += veloY;
        if (posY + getHeight() >= floorY) {
            posY = floorY - getHeight();
            veloY = 0;
        }
    }

    /** Vuelve a su posición inicial (después de un gol). */
    public void resetPosition() {
        effect = null;
        effectMillis = 0;
        posX = startX;
        posY = floorY - getHeight();
        veloY = 0;
        moveDir = 0;
        stunMillis = 0;
        if (life <= 0) {
            life = maxLife;
        }
        kickCooldown = 0;
        powerArmed = false;
    }

    //Consultas
    private double moveSpeed(){
        double s = (2 + speed) * stats.getSpeedMultiplier();
        return (effect == PowerType.SLOW || effect == PowerType.LIGHTNING) ? s * 0.5 : s;
    }
    private void snapToFloor(boolean wasGrounded){
        if (wasGrounded){
            posY = floorY - getHeight();
            veloY = 0;
        }
    }
    private boolean isOnGround() {
        return posY + getHeight() >= floorY;
    }

    private boolean isTouching(Ball ball) {
        double left = posX - getWidth() / 2.0;
        double nearX = Math.max(left, Math.min(ball.getPosX(), left + getWidth()));
        double nearY = Math.max(posY, Math.min(ball.getPosY(), posY + getHeight()));
        double dist = Math.hypot(ball.getPosX() - nearX, ball.getPosY() - nearY);
        return dist <= ball.getRadius() + KICK_REACH;
    }

    /** Devuelve true una sola vez si el poder se disparó en la última patada. */
    public boolean consumePowerFired() {
        boolean fired = powerFired;
        powerFired = false;
        return fired;
    }

    public boolean isPowerReady() { return powerCharge >= POWER_MAX; }
    public boolean isPowerArmed() { return powerArmed; }
    public boolean isFrozen() {return effect == PowerType.FREEZE;}
    public boolean isStunned() { return stunMillis > 0 || isFrozen() || effect == PowerType.TORNADO;}
    public boolean isKnockedOut() { return life <= 0; }

    public PowerType getactivePower() {return powerArmed ? power : null;}
    public PowerType getPower() {return power;}
    public PowerType getEffect() {return effect;}
    public long getEffectMillisLeft() { return effectMillis; }

    public int getWidth() {
        return (effect == PowerType.SHRINK) ? (int) (WIDTH * SHRINK_SCALE) : WIDTH;
    }

    public int getHeight() {
        return (effect == PowerType.SHRINK) ? (int) (HEIGHT * SHRINK_SCALE) : HEIGHT;
    }
    public double getVeloX() { return isStunned() ? 0 : moveDir * moveSpeed(); }
    public String getName() { return name; }
    public String getCountry() { return country; }
    public int getSpeed() { return speed; }
    public int getJump() { return jump; }
    public int getStrength() { return strength; }
    public int getFacing() { return facing; }
    public double getPosX() { return posX; }
    public double getPosY() { return posY; }
    public double getPowerCharge() { return powerCharge; }
    public double getLife() { return life; }
    public double getMaxLife() { return maxLife; }
    public PlayerStats getStats() { return stats; }
    public double getKickMultiplier() { return stats.getKickMultiplier(); }
    public double getStartX() { return startX; }

    /** Poder que tiene activo (pedido, esperando salir con la patada); null si ninguno. */
    public PowerType getActivePower() { return powerArmed ? power : null; }
}