package domain;

import java.io.Serializable;

/** Progreso de un jugador (usuario): puntos acumulados y estadísticas compradas. */
public class PlayerProgress implements Serializable {

    private static final long serialVersionUID = 1L;

    public static final int WIN_POINTS = 100;
    public static final int LOSS_POINTS = 25;

    private final String name;
    private int points;
    private final PlayerStats stats = new PlayerStats();

    public PlayerProgress(String name) throws POOBSoccerException {
        if (name == null || name.trim().isEmpty()) {
            throw new POOBSoccerException(POOBSoccerException.INVALID_USER_NAME);
        }
        this.name = name.trim();
    }

    public void addPoints(int amount) {
        if (amount > 0) {
            points += amount;
        }
    }

    /** Compra un punto de mejora; falla si no alcanzan los puntos o ya está en 10. */
    public void buy(PlayerStats.Stat stat) throws POOBSoccerException {
        int cost = stats.upgradeCost(stat);
        if (points < cost) {
            throw new POOBSoccerException("Puntos insuficientes: mejorar " + stat.getLabel() + " cuesta " + cost + " y " + name + " tiene " + points + ".");
        }
        stats.raise(stat);
        points -= cost;
    }

    public String getName() { return name; }
    public int getPoints() { return points; }
    public PlayerStats getStats() { return stats; }
}
