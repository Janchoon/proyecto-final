package domain;

import java.io.Serializable;

/**
 * Estadísticas de un jugador (aplican a todos sus personajes). Todas empiezan
 * en 1 y suben hasta 10. Cada punto por encima de 1 suma un 10 % sobre el
 * valor base:  multiplicador = 1 + 0,10 × (nivel − 1).
 */
public class PlayerStats implements Serializable {

    private static final long serialVersionUID = 1L;

    public static final int MIN = 1;
    public static final int MAX = 10;
    public static final double STEP = 0.10;
    public static final int BASE_LIFE = 100;
    public static final int BASE_UPGRADE_COST = 500;

    /** Estadísticas que se pueden mejorar. */
    public enum Stat {
        SPEED("Velocidad"), KICK("Patada"), JUMP("Salto"), SURVIVAL("Vida");

        private final String label;
        Stat(String label) { this.label = label; }
        public String getLabel() { return label; }
        @Override public String toString() { return label; }
    }

    private int speed = MIN;
    private int kick = MIN;
    private int jump = MIN;
    private int survival = MIN;

    public PlayerStats() { }

    public PlayerStats(int speed, int kick, int jump, int survival) throws POOBSoccerException {
        this.speed = check(speed);
        this.kick = check(kick);
        this.jump = check(jump);
        this.survival = check(survival);
    }

    /** Copia (para que mejorar estadísticas no altere un partido en curso). */
    public PlayerStats(PlayerStats other) {
        this.speed = other.speed;
        this.kick = other.kick;
        this.jump = other.jump;
        this.survival = other.survival;
    }

    private static int check(int v) throws POOBSoccerException {
        if (v < MIN || v > MAX) {
            throw new POOBSoccerException(POOBSoccerException.INVALID_STAT_LEVEL);
        }
        return v;
    }

    public int get(Stat stat) {
        switch (stat) {
            case SPEED:return speed;
            case KICK:return kick;
            case JUMP:return jump;
            default:return survival;
        }
    }

    /** Precio de subir la estadística un punto: 500, 1000, 2000... (por estadística). */
    public int upgradeCost(Stat stat) throws POOBSoccerException {
        int level = get(stat);
        if (level >= MAX) {
            throw new POOBSoccerException(POOBSoccerException.STAT_AT_MAX);
        }
        return BASE_UPGRADE_COST * (1 << (level - 1));
    }

    /** Sube un punto la estadística (el cobro lo hace PlayerProgress). */
    void raise(Stat stat) throws POOBSoccerException {
        if (get(stat) >= MAX) {
            throw new POOBSoccerException(POOBSoccerException.STAT_AT_MAX);
        }
        switch (stat) {
            case SPEED:speed++; break;
            case KICK:kick++; break;
            case JUMP:jump++; break;
            default:survival++; break;
        }
    }

    private static double multiplier(int level) { return 1 + STEP * (level - 1); }

    public double getSpeedMultiplier() { return multiplier(speed); }
    public double getJumpMultiplier() { return multiplier(jump); }
    /** multiplicadorKick = 1 + 0,10 × (Kick − 1). */
    public double getKickMultiplier() { return multiplier(kick); }
    /** vidaMax = 100 × (1 + 0,10 × (Survival − 1)). */
    public double getMaxLife() { return BASE_LIFE * multiplier(survival); }

    public int getSpeed() { return speed; }
    public int getKick() { return kick; }
    public int getJump() { return jump; }
    public int getSurvival() { return survival; }
}