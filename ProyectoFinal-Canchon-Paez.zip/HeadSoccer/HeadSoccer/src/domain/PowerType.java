package domain;

/**
 * Poderes especiales. Todos afectan al OPONENTE, pero solo si el tiro de poder
 * lo golpea (si entra al arco sin tocarlo, el gol cuenta y no hay daño ni efecto).
 *
 * damage = DañoTiro del Anexo 1 (ya multiplicado por 5); el daño final es
 * damage × multiplicadorKick del dueño del poder.
 * shotSpeed = velocidad horizontal (px por cuadro) del tiro de poder.
 */
public enum PowerType {
    // Poderes originales del proyecto (extras, no hacen daño)
    FREEZE("Congelación", "Congelado", 3000, 0, 14,
            "congela al oponente en un bloque de hielo"),
    SHRINK("Reducción", "Reducido", 5000, 0, 14,
            "encoge al oponente a un tamaño diminuto"),
    CONFUSION("Confusión", "Confundido", 5000, 0, 14,
            "invierte los controles de movimiento del oponente"),
    SLOW("Lentitud", "Ralentizado", 5000, 0, 14,
            "reduce a la mitad la velocidad del oponente"),

    // Anexo 1
    PUSH("Aura Azul", "Empujado", 1500, 40, 20,
            "tiro recto a alta velocidad: el rival es lanzado hacia su propio arco"),
    LIGHTNING("Rayo", "Electrocutado", 3000, 60, 17,
            "tiro recto con electricidad: el rival no salta y se mueve al 50 %"),
    TORNADO("Tornado", "Inconsciente", 3000, 40, 15,
            "remolino a ras de suelo: el rival sale volando y no puede moverse, saltar ni patear"),
    ILLUSION("Ilusión", "Confundido", 2500, 30, 15,
            "el balón se divide en 8 idénticos: el rival no sabe cuál es el real");

    private final String label;
    private final String effectLabel;
    private final long durationMillis;
    private final int damage;
    private final double shotSpeed;
    private final String description;

    PowerType(String label, String effectLabel, long durationMillis, int damage, double shotSpeed, String description) {
        this.label = label;
        this.effectLabel = effectLabel;
        this.durationMillis = durationMillis;
        this.damage = damage;
        this.shotSpeed = shotSpeed;
        this.description = description;
    }

    public String getLabel() { return label; }
    public String getEffectLabel() { return effectLabel; }
    public long getDurationMillis() { return durationMillis; }
    public int getDamage() { return damage; }
    public double getShotSpeed() { return shotSpeed; }
    public String getDescription() { return description; }

    @Override
    public String toString() { return label; }
}