package persistence;

import domain.GameEngine;

import java.io.Serializable;

/** Contenido de un archivo de partida: el motor y los usuarios que jugaban (null = máquina). */
public class SavedGame implements Serializable {

    private static final long serialVersionUID = 1L;
    static final String MAGIC = "DOPOSoccer-save-1";

    private final String magic = MAGIC;
    private final GameEngine engine;
    private final String user1;
    private final String user2;

    public SavedGame(GameEngine engine, String user1, String user2) {
        this.engine = engine;
        this.user1 = user1;
        this.user2 = user2;
    }

    boolean isValid() { return MAGIC.equals(magic) && engine != null; }

    public GameEngine getEngine() { return engine; }
    public String getUser1() { return user1; }
    public String getUser2() { return user2; }
}
