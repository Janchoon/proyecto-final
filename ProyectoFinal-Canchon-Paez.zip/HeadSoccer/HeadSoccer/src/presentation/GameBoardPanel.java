package presentation;


import domain.Ball;
import domain.GameEngine;
import domain.Goal;
import domain.MatchState;
import domain.MatchType;
import domain.Player;
import domain.PowerType;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Polygon;
import java.awt.RenderingHints;
import java.awt.geom.AffineTransform;
import java.awt.image.BufferedImage;
import javax.swing.JPanel;

/** Dibuja la cancha, los arcos, los jugadores y el balon que expone el motor. */
public class GameBoardPanel extends JPanel {

    private static final Color GRASS_A = new Color(24, 138, 24);
    private static final Color GRASS_B = new Color(30, 150, 30);
    private static final Color[] SHIRT = { new Color(43, 108, 176), new Color(221, 107, 32) };

    /** 1.0 = el sprite ocupa exactamente la caja de colisión (40x70). Súbelo si tu arte es más grande. */
    private static final double PLAYER_SPRITE_SCALE = 1.0;

    /** Tamaño de la cabeza-sprite respecto al ancho de la hitbox (solo visual). */
    private static final double HEAD_SPRITE_SCALE = 1.5;

    private GameEngine engine;
    private double scale = 1.0;               // resolución: 1.0 = 900 x 500
    private String user1;
    private String user2;

    public GameBoardPanel() {
        setPreferredSize(new Dimension(GameEngine.FIELD_WIDTH, GameEngine.FIELD_HEIGHT));
        setBackground(new Color(18, 18, 20));
    }

    /** Resolución de la cancha: la lógica sigue en 900 x 500 y solo se escala el dibujo. */
    public void setScale(double scale) {
        this.scale = scale;
        setPreferredSize(new Dimension((int) Math.round(GameEngine.FIELD_WIDTH * scale),
                (int) Math.round(GameEngine.FIELD_HEIGHT * scale)));
        revalidate();
        repaint();
    }

    /** Usuarios que juegan (null = máquina); se usan en el mensaje de puntos. */
    public void setUsers(String user1, String user2) {
        this.user1 = user1;
        this.user2 = user2;
    }

    public void setEngine(GameEngine engine) {
        this.engine = engine;
        repaint();
    }

    public void updateView() {
        repaint();
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        Graphics2D g2 = (Graphics2D) g.create();
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        g2.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
        g2.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_BILINEAR);
        g2.scale(scale, scale);
        drawField(g2);
        if (engine != null) {
            drawGoal(g2, engine.getGoal(1));
            drawGoal(g2, engine.getGoal(2));
            drawPlayer(g2, engine.getPlayer(1), 0);
            drawPlayer(g2, engine.getPlayer(2), 1);
            for (Ball fake : engine.getFakeBalls()) {         // Ilusión: se ven igual que el real
                drawBall(g2, fake);
            }
            drawShotGlow(g2, engine.getBall());
            drawBall(g2, engine.getBall());
            drawOverlay(g2);
        }
        g2.dispose();
    }

    private void drawField(Graphics2D g2) {
        BufferedImage bg = Sprites.get("background");
        BufferedImage field = Sprites.get("field");
        if (bg != null || field != null) {                   // sprites: fondo + cancha
            if (bg != null) {
                g2.drawImage(bg, 0, 0, GameEngine.FIELD_WIDTH, GameEngine.FIELD_HEIGHT, null);
            }
            if (field != null) {
                g2.drawImage(field, 0, 0, GameEngine.FIELD_WIDTH, GameEngine.FIELD_HEIGHT, null);
            }
            return;
        }
        int w = GameEngine.FIELD_WIDTH;
        int floor = GameEngine.FLOOR_Y;
        for (int i = 0; i < 10; i++) {                       // franjas de pasto
            g2.setColor(i % 2 == 0 ? GRASS_A : GRASS_B);
            g2.fillRect(i * w / 10, 0, w / 10 + 1, floor);
        }
        g2.setColor(new Color(14, 100, 14));                 // suelo
        g2.fillRect(0, floor, w, GameEngine.FIELD_HEIGHT - floor);
        g2.setColor(Color.WHITE);
        g2.setStroke(new BasicStroke(3f));
        g2.drawLine(0, floor, w, floor);
        g2.drawLine(w / 2, 0, w / 2, floor);
        g2.drawOval(w / 2 - 70, floor - 70, 140, 140);
    }

    private void drawGoal(Graphics2D g2, Goal goal) {
        boolean left = goal.getOwner() == 1;
        BufferedImage img = Sprites.get(left ? "goal_left" : "goal_right");
        boolean mirror = false;
        if (img == null) {                                   // un solo sprite "goal" (mira a la derecha)
            img = Sprites.get("goal");
            mirror = !left;
        }
        if (img == null && Sprites.get("background") != null) {
            return;                                          // el fondo ya trae los arcos dibujados
        }
        if (img != null) {
            int x = goal.getPosX();
            int w = goal.getWidth();
            if (mirror) {
                x += w;
                w = -w;
            }
            g2.drawImage(img, x, goal.getPosY(), w, goal.getHeight(), null);
            return;
        }
        g2.setColor(new Color(255, 255, 255, 235));
        g2.fillRoundRect(goal.getPosX(), goal.getPosY(), goal.getWidth(), goal.getHeight(), 8, 8);
        g2.setColor(new Color(170, 170, 170));
        g2.setStroke(new BasicStroke(1f));
        for (int x = goal.getPosX() + 10; x < goal.getPosX() + goal.getWidth(); x += 12) {
            g2.drawLine(x, goal.getPosY(), x, goal.getPosY() + goal.getHeight());
        }
        for (int y = goal.getPosY() + 10; y < goal.getPosY() + goal.getHeight(); y += 12) {
            g2.drawLine(goal.getPosX(), y, goal.getPosX() + goal.getWidth(), y);
        }
    }

    /** Estela de color detrás de un tiro de poder en vuelo. */
    private void drawShotGlow(Graphics2D g2, Ball b) {
        if (!b.isStraight()) {
            return;
        }
        PowerType t = engine.getShotType();
        Color c;
        if (t == PowerType.PUSH) {
            c = new Color(60, 140, 255);
        } else if (t == PowerType.LIGHTNING) {
            c = new Color(255, 230, 0);
        } else if (t == PowerType.TORNADO) {
            c = new Color(190, 170, 220);
        } else if (t == PowerType.ILLUSION) {
            c = new Color(230, 100, 255);
        } else {
            c = new Color(120, 220, 255);
        }
        int r = b.getRadius();
        int dir = b.getVelociX() >= 0 ? -1 : 1;                  // la estela queda detrás
        for (int i = 4; i >= 1; i--) {
            g2.setColor(new Color(c.getRed(), c.getGreen(), c.getBlue(), 40 + 25 * (5 - i)));
            int rr = r + 4 + (5 - i) * 2;
            g2.fillOval((int) b.getPosX() - rr + dir * i * 14, (int) b.getPosY() - rr, 2 * rr, 2 * rr);
        }
        g2.setColor(new Color(c.getRed(), c.getGreen(), c.getBlue(), 150));
        g2.fillOval((int) b.getPosX() - r - 6, (int) b.getPosY() - r - 6, 2 * r + 12, 2 * r + 12);
    }

    private void drawBall(Graphics2D g2, Ball b) {
        int r = b.getRadius();
        int x = (int) b.getPosX() - r;
        int y = (int) b.getPosY() - r;
        g2.setColor(new Color(0, 0, 0, 60));                 // sombra
        g2.fillOval(x + 2, GameEngine.FLOOR_Y - 5, 2 * r - 4, 8);
        BufferedImage img = Sprites.get("ball");
        if (img != null) {                                   // sprite girando según avanza en X
            AffineTransform old = g2.getTransform();
            g2.rotate(b.getPosX() / r, b.getPosX(), b.getPosY());
            g2.drawImage(img, x, y, 2 * r, 2 * r, null);
            g2.setTransform(old);
            return;
        }
        g2.setColor(new Color(230, 50, 40));
        g2.fillOval(x, y, 2 * r, 2 * r);
        g2.setColor(Color.WHITE);
        g2.setStroke(new BasicStroke(2f));
        g2.drawOval(x, y, 2 * r, 2 * r);
        g2.drawLine(x + r, y + 3, x + r, y + 2 * r - 3);
        g2.drawLine(x + 3, y + r, x + 2 * r - 3, y + r);
    }

    private void drawPlayer(Graphics2D g2, Player p, int idx) {
        int w = p.getWidth();
        int h = p.getHeight();
        int left = (int) p.getPosX() - w / 2;
        int top = (int) p.getPosY();
        
        BufferedImage sprite = playerSprite(p);
        // poder listo / activo: halo
        if (p.getActivePower() != null || p.isPowerReady()) {
            BufferedImage halo = Sprites.get(p.getActivePower() != null ? "halo_active" : "halo_ready");
            if (halo != null) {
                g2.drawImage(halo, left - 8, top - 8, w + 16, h + 16, null);
            } else {
                g2.setColor(p.getActivePower() != null ? new Color(255, 215, 0, 140) : new Color(80, 220, 120, 90));
                g2.fillOval(left - 8, top - 8, w + 16, h + 16);
            }
        }
        int labelLift = 0;
        if (sprite != null) {                                 // sprite del personaje de cuerpo completo
            int sw = (int) (w * PLAYER_SPRITE_SCALE);
            int sh = (int) (h * PLAYER_SPRITE_SCALE);
            int sx = (int) p.getPosX() - sw / 2;              // centrado en X, apoyado en los pies
            int sy = top + h - sh;
            if (p.getFacing() < 0) {
                g2.drawImage(sprite, sx + sw, sy, -sw, sh, null);
            } else {
                g2.drawImage(sprite, sx, sy, sw, sh, null);
            }
        } else {
            BufferedImage headImg = Sprites.get("players/" + spriteName(p) + "_head");
            drawVectorPlayer(g2, p, idx, left, top, w, h, headImg == null);   // cuerpo original
            if (headImg != null) {                            // cabeza como sprite (mira a la derecha)
                int hs = (int) (w * HEAD_SPRITE_SCALE);
                int hx = (int) p.getPosX() - hs / 2;
                int hy = top + w / 2 - hs / 2;
                if (p.getFacing() < 0) {
                    g2.drawImage(headImg, hx + hs, hy, -hs, hs, null);
                } else {
                    g2.drawImage(headImg, hx, hy, hs, hs, null);
                }
                labelLift = (hs - w) / 2;
            }
        }

        g2.setColor(Color.WHITE);                             // nombre sobre la cabeza
        g2.setFont(new Font("SansSerif", Font.BOLD, 11));
        FontMetrics fm = g2.getFontMetrics();
        g2.drawString(p.getName(), (int) p.getPosX() - fm.stringWidth(p.getName()) / 2, top - 6 - labelLift);

        PowerType e = p.getEffect();
        BufferedImage fx = e != null ? Sprites.get("effect_" + e.name().toLowerCase())
                : (p.isStunned() ? Sprites.get("effect_stun") : null);
        if (fx != null) {                                     // sprite de efecto sobre el jugador
            if (e == PowerType.FREEZE) {
                g2.drawImage(fx, left - 6, top - 6, w + 12, h + 12, null);
            } else if (e == PowerType.SHRINK) {
                // sin icono: el jugador ya se ve más pequeño
            } else {
                g2.drawImage(fx, (int) p.getPosX() - 16, top - 66, 32, 32, null);
            }
        } else if (e == PowerType.FREEZE) {                          // bloque de hielo
            g2.setColor(new Color(150, 220, 255, 150));
            g2.fillRoundRect(left - 6, top - 6, w + 12, h + 12, 10, 10);
            g2.setColor(new Color(220, 245, 255));
            g2.setStroke(new BasicStroke(2f));
            g2.drawRoundRect(left - 6, top - 6, w + 12, h + 12, 10, 10);
        } else if (e == PowerType.CONFUSION) {
            g2.setColor(new Color(255, 230, 0));
            g2.setFont(new Font("SansSerif", Font.BOLD, 20));
            g2.drawString("?", (int) p.getPosX() - 6, top - 18);
        } else if (e == PowerType.SLOW) {
            g2.setColor(new Color(160, 120, 255));
            g2.setFont(new Font("SansSerif", Font.BOLD, 16));
            g2.drawString("zZ", (int) p.getPosX() - 8, top - 18);
        } else if (e == PowerType.PUSH) {                     // empujado hacia su arco
            g2.setColor(new Color(80, 160, 255));
            g2.setFont(new Font("SansSerif", Font.BOLD, 20));
            String arrows = p.getFacing() > 0 ? "<<" : ">>";
            g2.drawString(arrows, (int) p.getPosX() - 12, top - 34);
        } else if (e == PowerType.LIGHTNING) {                // electrocutado: rayo sobre la cabeza
            int cx = (int) p.getPosX();
            Polygon bolt = new Polygon(
                    new int[] { cx + 3, cx - 7, cx - 1, cx - 5, cx + 7, cx + 1 },
                    new int[] { top - 64, top - 46, top - 46, top - 30, top - 50, top - 50 }, 6);
            g2.setColor(new Color(255, 230, 0));
            g2.fillPolygon(bolt);
        } else if (e == PowerType.TORNADO) {                  // inconsciente: remolino
            int cx = (int) p.getPosX();
            g2.setColor(new Color(190, 170, 220));
            g2.setStroke(new BasicStroke(2f));
            for (int i = 0; i < 3; i++) {
                int ow = 28 - i * 8;
                g2.drawOval(cx - ow / 2, top - 32 - i * 8, ow, 7);
            }
        } else if (e == PowerType.ILLUSION) {                 // confundido por la ilusión
            g2.setColor(new Color(230, 100, 255));
            g2.setFont(new Font("SansSerif", Font.BOLD, 20));
            g2.drawString("¿?", (int) p.getPosX() - 10, top - 34);
        } else if (p.isStunned()) {
            g2.setColor(new Color(255, 230, 0));
            g2.setFont(new Font("SansSerif", Font.BOLD, 16));
            g2.drawString("* * *", (int) p.getPosX() - 18, top - 18);
        }
    }

    /** Dibujo original (sin sprites), usado cuando no existe la imagen del personaje. */
    private void drawVectorPlayer(Graphics2D g2, Player p, int idx, int left, int top, int w, int h,
                                  boolean withHead) {
        int head = w;
        int bodyTop = top + (int) (head * 0.85);
        g2.setColor(SHIRT[idx]);                              // cuerpo
        g2.fillRoundRect(left + w / 6, bodyTop, w - w / 3, h - (bodyTop - top) - h / 5, 8, 8);
        g2.setColor(new Color(30, 30, 30));                   // piernas
        int legW = Math.max(3, w / 5);
        g2.fillRect(left + w / 4, top + h - h / 5, legW, h / 5);
        g2.fillRect(left + w - w / 4 - legW, top + h - h / 5, legW, h / 5);
        if (!withHead) {
            return;                                           // la cabeza la pone un sprite
        }
        g2.setColor(new Color(241, 194, 125));                // cabeza
        g2.fillOval(left, top, head, head);
        g2.setColor(new Color(40, 30, 20));                   // pelo
        g2.fillArc(left, top, head, head, 0, 180);
        g2.setColor(Color.BLACK);                             // ojo hacia donde mira
        int eyeX = left + head / 2 + p.getFacing() * head / 5 - 2;
        g2.fillOval(eyeX, top + head / 2 - 2, 4, 4);

    }

    private static String spriteName(Player p) {
        return java.text.Normalizer.normalize(p.getName(), java.text.Normalizer.Form.NFD)
                .replaceAll("\\p{M}", "").toLowerCase().replace(' ', '_');
    }

    /** Cuerpo completo opcional: sprites/players/<nombre>.png (si no hay, se usa <nombre>_head.png). */
    private BufferedImage playerSprite(Player p) {
        return Sprites.get("players/" + spriteName(p));
    }

    private void drawOverlay(Graphics2D g2) {
        int w = GameEngine.FIELD_WIDTH;
        String event = engine.getEventText();
        if (!event.isEmpty() && !engine.isOver()) {
            g2.setFont(new Font("SansSerif", Font.BOLD, 26));
            shadowCentered(g2, event, w / 2, 90, Color.WHITE);
        }
        if (engine.isPaused()) {
            dim(g2);
            g2.setFont(new Font("SansSerif", Font.BOLD, 48));
            shadowCentered(g2, "PAUSA", w / 2, 230, new Color(255, 200, 0));
            g2.setFont(new Font("SansSerif", Font.PLAIN, 16));
            shadowCentered(g2, "P / Esc: continuar     G: guardar partida     M: terminar y volver al menú",
                    w / 2, 270, Color.WHITE);
        } else if (engine.isOver()) {
            dim(g2);
            g2.setFont(new Font("SansSerif", Font.BOLD, 40));
            shadowCentered(g2, resultText(), w / 2, 220, new Color(255, 200, 0));
            g2.setFont(new Font("SansSerif", Font.PLAIN, 18));
            shadowCentered(g2, pointsText(), w / 2, 270, new Color(120, 220, 255));
            g2.setFont(new Font("SansSerif", Font.PLAIN, 16));
            shadowCentered(g2, "ENTER: volver al menú", w / 2, 310, Color.WHITE);
        } else if (engine.getMatch().getState() == MatchState.NOT_STARTED) {
            dim(g2);
        }
    }

    /** "Ana +100 puntos · Luis +25 puntos" (solo jugadores humanos). */
    private String pointsText() {
        StringBuilder sb = new StringBuilder();
        for (int n = 1; n <= 2; n++) {
            int pts = engine.getPointsEarned(n);
            if (pts > 0) {
                String who = (n == 1 ? user1 : user2);
                if (who == null) {
                    who = engine.getPlayer(n).getName();
                }
                if (sb.length() > 0) {
                    sb.append("  ·  ");
                }
                sb.append(who).append(" +").append(pts).append(" puntos");
            }
        }
        return sb.length() == 0 ? "Sin puntos para jugadores humanos" : sb.toString();
    }

    private String resultText() {
        if (engine.getType() == MatchType.SURVIVAL) {
            int won = engine.getSurvivalRound() - 1;
            return "Fin de la serie: " + won + (won == 1 ? " ronda ganada" : " rondas ganadas");
        }
        Player winner = engine.getPlayer(engine.getWinner());
        return "¡Gana " + winner.getName() + " (" + winner.getCountry() + ")!";
    }

    private void dim(Graphics2D g2) {
        g2.setColor(new Color(0, 0, 0, 120));
        g2.fillRect(0, 0, GameEngine.FIELD_WIDTH, GameEngine.FIELD_HEIGHT);
    }

    private void shadowCentered(Graphics2D g2, String s, int cx, int y, Color c) {
        FontMetrics fm = g2.getFontMetrics();
        int x = cx - fm.stringWidth(s) / 2;
        g2.setColor(new Color(0, 0, 0, 160));
        g2.drawString(s, x + 2, y + 2);
        g2.setColor(c);
        g2.drawString(s, x, y);
    }
}
