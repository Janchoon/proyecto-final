package presentation;

import domain.GameEngine;
import domain.HumanController;
import domain.MatchState;
import domain.POOBSoccerException;
import domain.PlayerProgress;
import domain.ErrorLog;
import persistence.GameStorage;
import persistence.ProgressStore;

import java.awt.BorderLayout;
import java.io.File;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import javax.swing.JFileChooser;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.SwingUtilities;
import javax.swing.filechooser.FileNameExtensionFilter;
import javax.swing.Timer;

/**
 * Pantalla de juego: marcador arriba, cancha al centro. Lee el teclado
 * (J1: A D W S Q — J2: flechas y Ctrl derecho) y avanza el motor cada 16 ms.
 * P / Esc pausan, G guarda la partida (en pausa), M vuelve al menú desde la
 * pausa y Enter al terminar. Al terminar suma los puntos al progreso de cada usuario.
 */
public class GamePanel extends JPanel {

    private static final int FRAME_MILLIS = 16;

    private final ScoreBoardPanel scoreBoard = new ScoreBoardPanel();
    private final GameBoardPanel gameBoard = new GameBoardPanel();
    private final Timer timer;
    private final Runnable onExit;
    private GameEngine engine;
    private ProgressStore store;
    private PlayerProgress progress1;       // null = máquina
    private PlayerProgress progress2;
    private boolean pointsApplied;

    public GamePanel(Runnable onExit) {
        this(onExit, null);
    }

    public GamePanel(Runnable onExit, ProgressStore store) {
        this.onExit = onExit;
        this.store = store;
        setLayout(new BorderLayout());
        add(scoreBoard, BorderLayout.NORTH);
        add(gameBoard, BorderLayout.CENTER);
        setFocusable(true);
        timer = new Timer(FRAME_MILLIS, e -> tick());
        addKeyListener(new KeyAdapter() {
            @Override
            public void keyPressed(KeyEvent e) {
                handleKey(e, true);
            }

            @Override
            public void keyReleased(KeyEvent e) {
                handleKey(e, false);
            }
        });
    }

    public void startMatch(GameEngine newEngine) {
        startMatch(newEngine, null, null, 1.0);
    }

    /**
     * Empieza (o continúa, si la partida se abrió de un archivo) un partido.
     * p1 y p2 son el progreso de los usuarios (null = máquina); scale es la resolución.
     */
    public void startMatch(GameEngine newEngine, PlayerProgress p1, PlayerProgress p2, double scale) {
        this.engine = newEngine;
        this.progress1 = p1;
        this.progress2 = p2;
        this.pointsApplied = false;
        scoreBoard.setScale(scale);
        gameBoard.setScale(scale);
        scoreBoard.setUsers(p1, p2);
        gameBoard.setUsers(p1 == null ? null : p1.getName(), p2 == null ? null : p2.getName());
        scoreBoard.setEngine(newEngine);
        gameBoard.setEngine(newEngine);
        if (newEngine.getMatch().getState() == MatchState.NOT_STARTED) {
            try{
                newEngine.start();
            } catch (POOBSoccerException ex){
                ErrorLog.log("No se pudo iniciar el partido", ex);
                showError(ex);
                onExit.run();
                return;
            }
        }
        timer.start();
        SwingUtilities.invokeLater(this::requestFocusInWindow);
    }

    public void stop() {
        timer.stop();
    }

    private void tick() {
        try{
            engine.update(FRAME_MILLIS);
        } catch (POOBSoccerException ex){
            timer.stop();
            ErrorLog.log("Error en el motor del juego", ex);
            showError(ex);
            onExit.run();
            return;
        }
        scoreBoard.updateView();
        gameBoard.updateView();
        if (engine.isOver()) {
            timer.stop(); // ultimo cuadro ya dibujado
            applyPoints();
        }
    }

    /** Suma los puntos del partido (100 ganador, 25 perdedor) al progreso de cada usuario. */
    private void applyPoints() {
        if (pointsApplied) {
            return;
        }
        pointsApplied = true;
        PlayerProgress[] all = { progress1, progress2 };
        for (int i = 0; i < 2; i++) {
            if (all[i] != null) {
                all[i].addPoints(engine.getPointsEarned(i + 1));
            }
        }
        if (store != null) {
            try {
                store.save();
            } catch (POOBSoccerException ex) {
                showError(ex);
            }
        }
        scoreBoard.updateView();
        gameBoard.updateView();
    }

    /** Guarda el partido en pausa en el archivo que elija el usuario. */
    private void saveMatch() {
        JFileChooser chooser = new JFileChooser();
        chooser.setDialogTitle("Guardar partida");
        chooser.setFileFilter(new FileNameExtensionFilter("Partida DOPOSoccer (*."
                + GameStorage.EXTENSION + ")", GameStorage.EXTENSION));
        if (chooser.showSaveDialog(this) != JFileChooser.APPROVE_OPTION) {
            return;
        }
        File file = chooser.getSelectedFile();
        if (!file.getName().toLowerCase().endsWith("." + GameStorage.EXTENSION)) {
            file = new File(file.getPath() + "." + GameStorage.EXTENSION);
        }
        try {
            GameStorage.save(engine, progress1 == null ? null : progress1.getName(),
                    progress2 == null ? null : progress2.getName(), file);
            JOptionPane.showMessageDialog(this, "Partida guardada en " + file.getName(),
                    "DOPOSoccer", JOptionPane.INFORMATION_MESSAGE);
        } catch (POOBSoccerException ex) {
            showError(ex);
        }
    }

    private void showError(POOBSoccerException ex) {
        JOptionPane.showMessageDialog(this, ex.getMessage(), "DOPOSoccer", JOptionPane.ERROR_MESSAGE);
    }

    private void handleKey(KeyEvent e, boolean down) {
        if (engine == null) {
            return;
        }
        HumanController h1 = engine.getHumanController(1);
        HumanController h2 = engine.getHumanController(2);
        switch (e.getKeyCode()) {
            case KeyEvent.VK_A:     if (h1 != null) h1.setLeft(down);  break;
            case KeyEvent.VK_D:     if (h1 != null) h1.setRight(down); break;
            case KeyEvent.VK_W:     if (h1 != null) h1.setJump(down);  break;
            case KeyEvent.VK_S:     if (h1 != null) h1.setKick(down);  break;
            case KeyEvent.VK_Q:     if (h1 != null && down) h1.requestPower(); break;
            case KeyEvent.VK_LEFT:  if (h2 != null) h2.setLeft(down);  break;
            case KeyEvent.VK_RIGHT: if (h2 != null) h2.setRight(down); break;
            case KeyEvent.VK_UP:    if (h2 != null) h2.setJump(down);  break;
            case KeyEvent.VK_DOWN:  if (h2 != null) h2.setKick(down);  break;
            case KeyEvent.VK_CONTROL:
                if (h2 != null && down && e.getKeyLocation() == KeyEvent.KEY_LOCATION_RIGHT) {
                    h2.requestPower();
                }
                break;
            case KeyEvent.VK_P:
            case KeyEvent.VK_ESCAPE:
                if (!down && !engine.isOver()) {
                    engine.togglePause();
                    gameBoard.updateView();
                    scoreBoard.updateView();
                }
                break;
            case KeyEvent.VK_G:
                if (!down && engine.isPaused()) {
                    saveMatch();
                }
                break;
            case KeyEvent.VK_M:
                if (!down && engine.isPaused()) {
                    onExit.run();
                }
                break;
            case KeyEvent.VK_ENTER:
                if (!down && engine.isOver()) {
                    onExit.run();
                }
                break;
            default:
                break;
        }
    }
}
