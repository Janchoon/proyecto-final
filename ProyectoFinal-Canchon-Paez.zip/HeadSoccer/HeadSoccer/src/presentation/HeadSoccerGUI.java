package presentation;


import domain.GameEngine;
import domain.PlayerProgress;
import persistence.ProgressStore;

import java.awt.CardLayout;
import java.awt.Component;
import java.awt.Dimension;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.SwingUtilities;

/** Ventana principal: alterna entre el menu y la pantalla de juego. */
public class HeadSoccerGUI extends JFrame {

    private static final String MENU = "menu";
    private static final String GAME = "game";

    private final CardLayout cards = new CardLayout();
    // la ventana toma el tamaño de la pantalla visible (la cancha cambia con la resolución)
    private final JPanel root = new JPanel(cards) {
        @Override
        public Dimension getPreferredSize() {
            for (Component c : getComponents()) {
                if (c.isVisible()) {
                    return c.getPreferredSize();
                }
            }
            return super.getPreferredSize();
        }
    };
    private final ProgressStore store = new ProgressStore();
    private final MenuPanel menu;
    private final GamePanel game;

    public HeadSoccerGUI() {
        setTitle("DOPOSoccer");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setResizable(false);

        menu = new MenuPanel(this::showGame, store);
        game = new GamePanel(this::showMenu, store);
        root.add(menu, MENU);
        root.add(game, GAME);
        add(root);
        pack();
        setLocationRelativeTo(null);
    }

    private void showGame(GameEngine engine, PlayerProgress p1, PlayerProgress p2, double scale) {
        game.startMatch(engine, p1, p2, scale);
        cards.show(root, GAME);
        pack();
        setLocationRelativeTo(null);
        game.requestFocusInWindow();
    }

    private void showMenu() {
        game.stop();
        menu.refresh();
        cards.show(root, MENU);
        pack();
        setLocationRelativeTo(null);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new HeadSoccerGUI().setVisible(true));
    }
}
