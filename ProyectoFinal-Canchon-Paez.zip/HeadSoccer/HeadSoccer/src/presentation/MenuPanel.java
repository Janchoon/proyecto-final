package presentation;

import domain.AIProfile;
import domain.CharacterCatalog;
import domain.CharacterProfile;
import domain.GameEngine;
import domain.GameMode;
import domain.HeadSoccer;
import domain.MatchType;
import domain.POOBSoccerException;
import domain.PlayerProgress;
import domain.PlayerStats;
import persistence.GameStorage;
import persistence.ProgressStore;
import persistence.SavedGame;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.GridLayout;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.Insets;
import java.awt.image.BufferedImage;
import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.function.Consumer;
import javax.swing.DefaultComboBoxModel;
import javax.swing.DefaultListCellRenderer;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFileChooser;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JSpinner;
import javax.swing.JTextField;
import javax.swing.SpinnerNumberModel;
import javax.swing.SwingConstants;
import javax.swing.SwingUtilities;
import javax.swing.filechooser.FileNameExtensionFilter;

/**
 * Menú: modalidad, tipo de partido (con minutos o goles), resolución de la
 * cancha, y por cada jugador su usuario (progreso), personaje y, si es máquina,
 * su perfil. También mejora estadísticas y abre partidas guardadas.
 */
public class MenuPanel extends JPanel {

    private static final Color BG = new Color(18, 18, 20);

    /** Quién arranca un partido: motor, progreso de cada usuario (null = máquina) y resolución. */
    public interface MatchLauncher {
        void launch(GameEngine engine, PlayerProgress p1, PlayerProgress p2, double scale);
    }

    private static final String[] RESOLUTION_NAMES = {
        "Pequeña (720 x 400)", "Mediana (900 x 500)", "Grande (1125 x 625)" };
    private static final double[] RESOLUTION_SCALES = { 0.8, 1.0, 1.25 };

    private final MatchLauncher launcher;
    private final ProgressStore store;

    private final JComboBox<String> modeBox = new JComboBox<>(new String[] {
        "Jugador vs Jugador", "Jugador vs Máquina", "Máquina vs Máquina" });
    private final JComboBox<String> typeBox = new JComboBox<>();
    private final JLabel valueLabel = label("Minutos del partido", 15, Color.WHITE);
    private final JSpinner valueSpinner = new JSpinner(new SpinnerNumberModel(1, 1, HeadSoccer.MAX_MINUTES, 1));
    private final JComboBox<String> resolutionBox = new JComboBox<>(RESOLUTION_NAMES);
    private final JTextField user1 = new JTextField("Jugador1");
    private final JTextField user2 = new JTextField("Jugador2");
    private final JComboBox<CharacterProfile> char1 = new JComboBox<>();
    private final JComboBox<CharacterProfile> char2 = new JComboBox<>();
    private final JComboBox<AIProfile> profile1 = new JComboBox<>(AIProfile.values());
    private final JComboBox<AIProfile> profile2 = new JComboBox<>(AIProfile.values());
    private final JLabel info1 = label("", 12, Color.LIGHT_GRAY);
    private final JLabel info2 = label("", 12, Color.LIGHT_GRAY);

    private int minutesValue = 1;      // se recuerda lo elegido para cada tipo de partido
    private int goalsValue = 3;
    private boolean updatingSpinner;

    /** Constructor original: sin progreso guardado ni resolución (la ventana usa solo el motor). */
    public MenuPanel(Consumer<GameEngine> onStart) {
        this((engine, p1, p2, scale) -> onStart.accept(engine), new ProgressStore());
    }

    public MenuPanel(MatchLauncher launcher, ProgressStore store) {
        this.launcher = launcher;
        this.store = store;
        setBackground(BG);
        setPreferredSize(new Dimension(GameEngine.FIELD_WIDTH,
                GameEngine.FIELD_HEIGHT + ScoreBoardPanel.HEIGHT));
        setLayout(new GridBagLayout());

        for (CharacterProfile c : CharacterCatalog.all()) {
            char1.addItem(c);
            char2.addItem(c);
        }
        char2.setSelectedIndex(1);
        setCharacterRenderer(char1); // retratos en las listas (opcional)
        setCharacterRenderer(char2);
        profile1.setSelectedItem(AIProfile.EXPERTA);
        profile2.setSelectedItem(AIProfile.EXPERTA);
        resolutionBox.setSelectedIndex(1);
        refreshTypes();

        Dimension boxSize = new Dimension(560, 28);
        modeBox.setPreferredSize(boxSize);
        typeBox.setPreferredSize(boxSize);
        valueSpinner.setPreferredSize(boxSize);
        resolutionBox.setPreferredSize(boxSize);

        GridBagConstraints c = new GridBagConstraints();
        c.insets = new Insets(4, 10, 4, 10);
        c.fill = GridBagConstraints.HORIZONTAL;

        c.gridx = 0; c.gridy = 0; c.gridwidth = 2;
        add(label("DOPOSoccer", 40, new Color(255, 200, 0)), c);
        c.gridy = 1;
        add(label("Partidos 1 contra 1 con poderes especiales", 15, Color.LIGHT_GRAY), c);

        c.gridwidth = 1;
        row(c, 2, label("Modalidad", 15, Color.WHITE), modeBox);
        row(c, 3, label("Tipo de partido", 15, Color.WHITE), typeBox);
        row(c, 4, valueLabel, valueSpinner);
        row(c, 5, label("Resolución de la cancha", 15, Color.WHITE), resolutionBox);

        row(c, 6, label("", 12, Color.GRAY), trio(
                label("Usuario (progreso)", 12, Color.GRAY),
                label("Personaje", 12, Color.GRAY),
                label("Perfil si es máquina", 12, Color.GRAY)));
        row(c, 7, label("Jugador 1", 15, Color.WHITE), trio(user1, char1, profile1));
        c.gridx = 1; c.gridy = 8; add(info1, c);
        row(c, 9, label("Jugador 2 / Máquina", 15, Color.WHITE), trio(user2, char2, profile2));
        c.gridx = 1; c.gridy = 10; add(info2, c);

        JButton play = new JButton("Jugar");
        play.setFont(new Font("SansSerif", Font.BOLD, 20));
        JButton stats = new JButton("Mejorar estadísticas");
        JButton open = new JButton("Abrir partida");
        JPanel buttons = new JPanel(new GridLayout(1, 3, 10, 0));
        buttons.setOpaque(false);
        buttons.add(play);
        buttons.add(stats);
        buttons.add(open);
        c.gridx = 0; c.gridy = 11; c.gridwidth = 2;
        add(buttons, c);

        c.gridy = 12;
        add(label("<html><center>J1: A / D mover · W saltar · S patear · Q poder<br>"
                + "J2: ← / → mover · ↑ saltar · ↓ patear · Ctrl derecho poder<br>"
                + "P o Esc: pausa (G guarda la partida, M termina). En Jugador vs Máquina juegas con los controles del J1."
                + "</center></html>", 12, Color.GRAY), c);

        modeBox.addActionListener(e -> {
            refreshTypes();
            refreshEnabled();
            refreshInfo();
        });
        typeBox.addActionListener(e -> refreshValue());
        valueSpinner.addChangeListener(e -> rememberValue());
        char1.addActionListener(e -> refreshInfo());
        char2.addActionListener(e -> refreshInfo());
        for (JTextField f : new JTextField[] { user1, user2 }) {
            f.getDocument().addDocumentListener(new javax.swing.event.DocumentListener() {
                @Override public void insertUpdate(javax.swing.event.DocumentEvent e) { refreshInfo(); }
                @Override public void removeUpdate(javax.swing.event.DocumentEvent e) { refreshInfo(); }
                @Override public void changedUpdate(javax.swing.event.DocumentEvent e) { refreshInfo(); }
            });
        }
        play.addActionListener(e -> startMatch());
        stats.addActionListener(e -> openStats());
        open.addActionListener(e -> openMatch());
        refreshValue();
        refreshEnabled();
        refreshInfo();

        String warning = store.getLoadWarning();
        if (warning != null) {
            SwingUtilities.invokeLater(() -> JOptionPane.showMessageDialog(this, warning,
                    "DOPOSoccer", JOptionPane.WARNING_MESSAGE));
        }
    }

    /** Fondo del menú: sprites/menu_background.png (si no existe, queda el color liso). */
    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        BufferedImage bg = Sprites.get("menu_background");
        if (bg != null) {
            g.drawImage(bg, 0, 0, getWidth(), getHeight(), null);
        }
    }

    /** Muestra sprites/portraits/<nombre>.png junto al nombre del personaje, si existe. */
    private static void setCharacterRenderer(JComboBox<CharacterProfile> box) {
        box.setRenderer(new DefaultListCellRenderer() {
            @Override
            public java.awt.Component getListCellRendererComponent(JList<?> list, Object value,
                    int index, boolean selected, boolean focus) {
                JLabel l = (JLabel) super.getListCellRendererComponent(list, value, index, selected, focus);
                if (value instanceof CharacterProfile) {
                    String n = java.text.Normalizer.normalize(((CharacterProfile) value).getName(),
                            java.text.Normalizer.Form.NFD).replaceAll("\\p{M}", "").toLowerCase();
                    Image img = Sprites.scaled("portraits/" + n, 24, 24);
                    l.setIcon(img == null ? null : new ImageIcon(img));
                }
                return l;
            }
        });
    }

    private void row(GridBagConstraints c, int y, java.awt.Component name, java.awt.Component field) {
        c.gridy = y;
        c.gridx = 0;
        add(name, c);
        c.gridx = 1;
        add(field, c);
    }

    private static JPanel trio(java.awt.Component a, java.awt.Component b, java.awt.Component d) {
        JPanel p = new JPanel(new GridLayout(1, 3, 6, 0));
        p.setOpaque(false);
        p.add(a);
        p.add(b);
        p.add(d);
        return p;
    }

    private static JLabel label(String text, int size, Color color) {
        JLabel l = new JLabel(text, SwingConstants.CENTER);
        l.setForeground(color);
        l.setFont(new Font("SansSerif", size > 20 ? Font.BOLD : Font.PLAIN, size));
        return l;
    }

    // Quién es humano y quién máquina según la modalidad

    private boolean isHuman(int player) {
        int mode = modeBox.getSelectedIndex();
        return mode == 0 || (mode == 1 && player == 1);
    }

    private void refreshEnabled() {
        user1.setEnabled(isHuman(1));
        user2.setEnabled(isHuman(2));
        profile1.setEnabled(!isHuman(1));
        profile2.setEnabled(!isHuman(2));
    }

    /** Supervivencia solo existe en Jugador vs Máquina. */
    private void refreshTypes() {
        int previous = Math.max(0, typeBox.getSelectedIndex());
        boolean pvm = modeBox.getSelectedIndex() == 1;
        DefaultComboBoxModel<String> model = new DefaultComboBoxModel<>();
        model.addElement("Por tiempo");
        model.addElement("Por goles");
        if (pvm) {
            model.addElement("Supervivencia (serie de partidos)");
        }
        typeBox.setModel(model);
        typeBox.setSelectedIndex(Math.min(previous, model.getSize() - 1));
        refreshValue();
    }

    /** El campo de meta cambia según el tipo: minutos (tiempo) o goles (goles). */
    private void refreshValue() {
        updatingSpinner = true;
        int type = typeBox.getSelectedIndex();
        if (type == 0) {
            valueLabel.setText("Minutos del partido");
            valueSpinner.setModel(new SpinnerNumberModel(minutesValue, 1, HeadSoccer.MAX_MINUTES, 1));
            valueSpinner.setEnabled(true);
        } else if (type == 1) {
            valueLabel.setText("Goles para ganar");
            valueSpinner.setModel(new SpinnerNumberModel(goalsValue, 1, HeadSoccer.MAX_GOALS, 1));
            valueSpinner.setEnabled(true);
        } else {
            valueLabel.setText("Meta");
            valueSpinner.setModel(new SpinnerNumberModel(1, 1, 1, 1));
            valueSpinner.setEnabled(false);
        }
        updatingSpinner = false;
    }

    private void rememberValue() {
        if (updatingSpinner) {
            return;
        }
        int type = typeBox.getSelectedIndex();
        int v = (Integer) valueSpinner.getValue();
        if (type == 0) {
            minutesValue = v;
        } else if (type == 1) {
            goalsValue = v;
        }
    }

    private void refreshInfo() {
        info1.setText(describe(1, (CharacterProfile) char1.getSelectedItem(), user1));
        info2.setText(describe(2, (CharacterProfile) char2.getSelectedItem(), user2));
    }

    /** Estadísticas y puntos del usuario (si es humano) y datos del personaje. */
    private String describe(int player, CharacterProfile p, JTextField user) {
        if (p == null) {
            return "";
        }
        String text = "Vel " + p.getSpeed() + " · Salto " + p.getJump() + " · Fuerza " + p.getStrength()
                + " · Poder: " + p.getPower().getLabel()
                + (p.getPower().getDamage() > 0 ? " (daño " + p.getPower().getDamage() + ")" : "");
        if (isHuman(player) && !user.getText().trim().isEmpty()) {
            try {
                PlayerProgress prog = store.get(user.getText());
                PlayerStats s = prog.getStats();
                text = "<html><center>" + prog.getName() + ": " + prog.getPoints() + " puntos · Vel "
                        + s.getSpeed() + " · Patada " + s.getKick() + " · Salto " + s.getJump()
                        + " · Superv. " + s.getSurvival() + "<br>" + text + "</center></html>";
            } catch (POOBSoccerException ex) {
                // nombre vacío: ya se avisa al jugar
            }
        }
        return text;
    }

    /** Se llama al volver de una partida para mostrar los puntos nuevos. */
    public void refresh() {
        refreshInfo();
    }

    // Acciones

    private double selectedScale() {
        return RESOLUTION_SCALES[resolutionBox.getSelectedIndex()];
    }

    private void startMatch() {
        try {
            GameMode mode = GameMode.values()[modeBox.getSelectedIndex()];
            MatchType type = MatchType.values()[typeBox.getSelectedIndex()];
            PlayerProgress p1 = isHuman(1) ? store.get(user1.getText()) : null;
            PlayerProgress p2 = isHuman(2) ? store.get(user2.getText()) : null;
            if (p1 != null && p1 == p2) {
                throw new POOBSoccerException("Los dos jugadores no pueden usar el mismo usuario ("
                        + p1.getName() + "). Escribe un usuario distinto para cada uno.");
            }
            GameEngine engine = new GameEngine(mode, type, goalsValue, minutesValue,
                    (CharacterProfile) char1.getSelectedItem(),
                    (CharacterProfile) char2.getSelectedItem(),
                    p1 == null ? null : p1.getStats(), p2 == null ? null : p2.getStats(),
                    (AIProfile) profile1.getSelectedItem(), (AIProfile) profile2.getSelectedItem());
            launcher.launch(engine, p1, p2, selectedScale());
        } catch (POOBSoccerException ex) {
            showWarning(ex);
        }
    }

    private void openStats() {
        List<String> names = new ArrayList<>();
        try {
            for (int i = 1; i <= 2; i++) {
                JTextField f = (i == 1) ? user1 : user2;
                if (isHuman(i)) {
                    String name = store.get(f.getText()).getName();
                    if (!names.contains(name)) {
                        names.add(name);
                    }
                }
            }
        } catch (POOBSoccerException ex) {
            showWarning(ex);
            return;
        }
        if (names.isEmpty()) {
            JOptionPane.showMessageDialog(this, "En Máquina vs Máquina no hay usuarios que mejorar.",
                    "DOPOSoccer", JOptionPane.INFORMATION_MESSAGE);
            return;
        }
        new StatsDialog(SwingUtilities.getWindowAncestor(this), store, names).setVisible(true);
        refreshInfo();
    }

    private void openMatch() {
        JFileChooser chooser = new JFileChooser();
        chooser.setDialogTitle("Abrir partida");
        chooser.setFileFilter(new FileNameExtensionFilter("Partida DOPOSoccer (*."
                + GameStorage.EXTENSION + ")", GameStorage.EXTENSION));
        if (chooser.showOpenDialog(this) != JFileChooser.APPROVE_OPTION) {
            return;
        }
        File file = chooser.getSelectedFile();
        try {
            SavedGame saved = GameStorage.open(file);
            PlayerProgress p1 = saved.getUser1() == null ? null : store.get(saved.getUser1());
            PlayerProgress p2 = saved.getUser2() == null ? null : store.get(saved.getUser2());
            launcher.launch(saved.getEngine(), p1, p2, selectedScale());
        } catch (POOBSoccerException ex) {
            showWarning(ex);
        }
    }

    private void showWarning(POOBSoccerException ex) {
        JOptionPane.showMessageDialog(this, ex.getMessage(), "DOPOSoccer", JOptionPane.WARNING_MESSAGE);
    }
}
