package presentation;

import domain.POOBSoccerException;
import domain.PlayerProgress;
import domain.PlayerStats;
import persistence.ProgressStore;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.Window;
import java.util.EnumMap;
import java.util.List;
import java.util.Map;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.SwingConstants;

/**
 * Mejora de estadísticas: el usuario gasta sus puntos para subir speed, kick,
 * jump o survival (hasta 10). Cada punto cuesta el doble que el anterior de la
 * misma estadística: 500, 1000, 2000...
 */
public class StatsDialog extends JDialog {

    private static final Color BG = new Color(18, 18, 20);

    private final ProgressStore store;
    private final JComboBox<String> users;
    private final JLabel pointsLabel = new JLabel("", SwingConstants.CENTER);
    private final Map<PlayerStats.Stat, JLabel> levelLabels = new EnumMap<>(PlayerStats.Stat.class);
    private final Map<PlayerStats.Stat, JLabel> costLabels = new EnumMap<>(PlayerStats.Stat.class);
    private final Map<PlayerStats.Stat, JButton> buttons = new EnumMap<>(PlayerStats.Stat.class);

    public StatsDialog(Window owner, ProgressStore store, List<String> names) {
        super(owner, "Mejorar estadísticas", ModalityType.APPLICATION_MODAL);
        this.store = store;
        this.users = new JComboBox<>(names.toArray(new String[0]));

        JPanel root = new JPanel(new BorderLayout(10, 10));
        root.setBackground(BG);
        root.setBorder(BorderFactory.createEmptyBorder(14, 16, 14, 16));

        JPanel top = new JPanel(new GridLayout(2, 1, 0, 6));
        top.setOpaque(false);
        top.add(users);
        pointsLabel.setForeground(new Color(255, 200, 0));
        pointsLabel.setFont(new Font("SansSerif", Font.BOLD, 18));
        top.add(pointsLabel);
        root.add(top, BorderLayout.NORTH);

        JPanel grid = new JPanel(new GridLayout(PlayerStats.Stat.values().length + 1, 4, 10, 8));
        grid.setOpaque(false);
        grid.add(header("Estadística"));
        grid.add(header("Nivel"));
        grid.add(header("Costo"));
        grid.add(header(""));
        for (PlayerStats.Stat stat : PlayerStats.Stat.values()) {
            JLabel level = cell("");
            JLabel cost = cell("");
            JButton buy = new JButton("+1");
            buy.addActionListener(e -> buy(stat));
            levelLabels.put(stat, level);
            costLabels.put(stat, cost);
            buttons.put(stat, buy);
            grid.add(cell(stat.getLabel()));
            grid.add(level);
            grid.add(cost);
            grid.add(buy);
        }
        root.add(grid, BorderLayout.CENTER);

        JLabel help = new JLabel("<html><center>Cada punto de mejora suma un 10 % al valor base.<br>"
                + "Ganas 100 puntos por victoria y 25 por derrota.</center></html>", SwingConstants.CENTER);
        help.setForeground(Color.GRAY);
        root.add(help, BorderLayout.SOUTH);

        users.addActionListener(e -> refresh());
        setContentPane(root);
        refresh();
        pack();
        setMinimumSize(getSize());
        setLocationRelativeTo(owner);
    }

    private static JLabel header(String text) {
        JLabel l = new JLabel(text, SwingConstants.CENTER);
        l.setForeground(Color.LIGHT_GRAY);
        l.setFont(new Font("SansSerif", Font.BOLD, 12));
        return l;
    }

    private static JLabel cell(String text) {
        JLabel l = new JLabel(text, SwingConstants.CENTER);
        l.setForeground(Color.WHITE);
        l.setFont(new Font("SansSerif", Font.PLAIN, 14));
        return l;
    }

    private PlayerProgress current() throws POOBSoccerException {
        return store.get((String) users.getSelectedItem());
    }

    private void refresh() {
        try {
            PlayerProgress p = current();
            pointsLabel.setText(p.getName() + ": " + p.getPoints() + " puntos");
            for (PlayerStats.Stat stat : PlayerStats.Stat.values()) {
                int level = p.getStats().get(stat);
                levelLabels.get(stat).setText(level + " / " + PlayerStats.MAX);
                boolean max = level >= PlayerStats.MAX;
                costLabels.get(stat).setText(max ? "MAX" : String.valueOf(p.getStats().upgradeCost(stat)));
                buttons.get(stat).setEnabled(!max && p.getPoints() >= p.getStats().upgradeCost(stat));
            }
        } catch (POOBSoccerException ex) {
            showError(ex);
        }
    }

    private void buy(PlayerStats.Stat stat) {
        try {
            current().buy(stat);
            store.save();
        } catch (POOBSoccerException ex) {
            showError(ex);
        }
        refresh();
    }

    private void showError(POOBSoccerException ex) {
        JOptionPane.showMessageDialog(this, ex.getMessage(), "DOPOSoccer", JOptionPane.ERROR_MESSAGE);
    }
}
